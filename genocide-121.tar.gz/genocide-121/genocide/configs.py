# This file is placed in the Public Domain.
#
# pylint: disable=R,C0114,C0115


"configurations"


from .default import Default


class Config(Default):

    pass


Cfg = Config()
