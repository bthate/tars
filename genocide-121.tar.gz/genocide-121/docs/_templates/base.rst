.. _{{ fullname }}:

.. raw:: html

    <br>

.. title:: {{ fullname }}

.. raw:: html

    <center>
    <b>
    <span>

{{ fullname }}

.. raw:: html

    </span>
    </b>
    </center>

.. auto{{ objtype }}:: {{ fullname }}
    :members:
    :private-members:
    :undoc-members:

.. raw:: html

    <br><br>
