.. _guilty:

.. raw:: html

    <br>


.. title:: guilty

.. _informed:


**INFORMED**


.. image:: informed.jpg
    :width: 100%

.. raw:: html

    <br>

.. _chamber:

**CHAMBER**

.. image:: kamer.png


.. raw:: html

    <br>

.. _king:


**KING**


.. image:: bevestigd.jpg

.. raw:: html

  <br>
