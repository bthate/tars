.. _evidence:

.. title:: Evidence

.. _haldol:

.. raw:: html

  <br>

**HALDOL**


.. raw:: html

  <br>

.. image:: ECHAhaldol.png
    :width: 100%

.. raw:: html

  <br><br>

.. _clozapine:


**CLOZAPINE**


.. raw:: html

  <br>


.. image:: ECHAclozapine.png
    :width: 100%


.. raw:: html

  <br><br>

.. _zyprexa:


**ZYPREXA**


.. raw:: html

  <br>

.. image:: ECHAzyprexa.png
    :width: 100%

.. raw:: html

  <br><br>

.. _abilify:


**ABILIFY**


.. raw:: html

  <br>

.. image:: ECHAabilify.png
     :width: 100%

