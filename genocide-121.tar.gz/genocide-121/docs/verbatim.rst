.. _verabatim:

.. raw:: html

   <br>

.. title:: verbatim


**VERBATIM**


.. raw:: html

    <br>


.. image:: verbatim2.png
    :height: 15cm


.. raw:: html

    <br><br>
