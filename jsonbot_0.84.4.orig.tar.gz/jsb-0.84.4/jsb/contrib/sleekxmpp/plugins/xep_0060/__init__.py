from sleekxmpp.plugins.xep_0060.pubsub import xep_0060
from sleekxmpp.plugins.xep_0060 import stanza
