import sys, os
sys.path.append(os.sep.join(os.path.abspath(__file__).split(os.sep)[:-1]))