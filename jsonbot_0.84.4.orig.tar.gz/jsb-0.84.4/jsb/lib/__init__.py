# jsb package
#
#

""" jsb core package. """

__version__ = "0.84"

import warnings
warnings.simplefilter('ignore')
