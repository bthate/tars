# This file is in the Public Domain.

class ENOCLASS(Exception):

    pass

class ENOFILENAME(Exception):

    pass

class ENOMORE(Exception):

    pass

class ENOUSER(Exception):

    pass

class ENOTIMPLEMENTED(Exception):

    pass

class ENOTXT(Exception):

    pass
    