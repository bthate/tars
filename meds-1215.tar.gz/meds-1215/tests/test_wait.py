# test_wait.py
#
#

## IMPORTS

from meds.bots.result import Result
from meds.core import kernel
from meds.event import Event

import unittest

bot = Result()
bot.start()

## Test_Wait class

class Test_Wait(unittest.TestCase):

    def test_wait(self):
        e = Event()
        e.btype = "Result"
        e.txt = "test"
        e.origin = "user@bot"
        e.doresult = True
        bot.put(e)
        e.wait()
        self.assertEqual(e._result, ["hello user@bot",])
