# test_kernel.py
#
#

""" test for all command. """

from meds.core import cfg, kernel, launcher
from meds.bots.result import Result
from meds.event import Event

import readline
import unittest
import logging
import random
import string
import time
import os

ignore = ["parse_cli", "builtin", "os", "sys", "log", "functest", "hello", "getline", "cmndrun", "fetcher", "testcmnds", "test", "runkernel", "reboot", "real_reboot", "shutdown", "loglevel", "testline", "connect"]

bot = Result()
bot.start()

def randomarg():
    res = ""
    for x in range(random.randint(3,10)):
        res += random.choice(string.printable)
    return res

class Test_Cmnd(unittest.TestCase):

    def test_kernel(self):
        events = []
        for cmnd in kernel.list():
            if cmnd in ignore: continue
            e = Event()
            e.origin = "user@bot"
            e.txt = cmnd + " " + randomarg() 
            logging.warn("< %s" % e.txt)
            bot.put(e)
            events.append(e)
        for e in events:
            e.wait()
            if cfg.verbose:
                for txt in e._result:
                    print(txt)