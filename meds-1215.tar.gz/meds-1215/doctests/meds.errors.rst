meds.errors
===========

 possible exceptions thrown in the code. 

meds.errors.EARGUMENT:

None

meds.errors.EATTRIBUTE:

None

meds.errors.ECONNECT:

None

meds.errors.EDISCONNECT:

None

meds.errors.EDISPATCHER:

None

meds.errors.EFILE:

None

meds.errors.EFILENAME:

None

meds.errors.EFUNC:

None

meds.errors.EJSON:

None

meds.errors.ELOAD:

None

meds.errors.ENODATE:

 no date can be detected. 

meds.errors.ENODIR:

None

meds.errors.ENOFUNC:

None

meds.errors.ENOJSON:

None

meds.errors.ENOMETHOD:

None

meds.errors.ENOTIME:

None

meds.errors.ENOTIMPLEMENTED:

None

meds.errors.ENOTSET:

None

meds.errors.EOWNER:

None

meds.errors.EPASSWORD:

None

meds.errors.EREBOOT:

None

meds.errors.EREGISTER:

None

meds.errors.ERESERVED:

None

meds.errors.ESET:

None

meds.errors.ESIGNATURE:

None

meds.errors.ETYPE:

None

meds.errors.Error:

None

