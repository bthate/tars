meds.clock
==========

 timer, repeater and other clock based classes. 

meds.clock.Object:

 yooooo !! 

meds.clock.Repeater:

None

meds.clock.Timer:

None

meds.clock.get_exception:

None

meds.clock.name:

None

