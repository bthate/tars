meds.log
========

 log module to set standard format of logging. 

meds.log.Formatter:

None

meds.log.FormatterClean:

None

meds.log.cdir:

None

meds.log.j:

None

meds.log.log:

None

meds.log.loglevel:

None

