meds.bots.xmpp
==============

 module implementing an XMPP bot. 

meds.bots.xmpp.Bot:


        Bot(Scheduler)

        Base class for bot implementations. 

    

meds.bots.xmpp.Event:


        Event()

    

meds.bots.xmpp.XMPP:

 XMPP chat bot. 

    def announce(self, txt):

        """ announce text on all registered channels. """

    def connected(self, data):

        """ connect callback. """

    def connecting(self):

        """ connect to XMPP server. """

    def core(self):

        """ core XMPP client loop. """

    def disconnected(self, data):

        """ disconnect callback. """

    def event(self):

        """ block on _queue until data arrives. """

    def exception(self, data):

        """ log an exception. """

    def failedauth(self, data):

        """ log a failed authentication attempt. """

    def failure(self, data):

        """ log a failure. """

    def iqed(self, data):

        """ iq callback. """

    def makeclient(self, jid, password):

        """ create sleekxmpp client part. """

    def messaged(self, data):

        """ handle incoming messages. """

    def out(self, txt):

        """ lowlevel output function. """

    def presenced(self, data):

        """ handle presence notices. """

    def register(self, key, value):

        """ register a handler. """

    def say(self, jid, txt):

        """ output text to jid. """

    def session_start(self, data):

        """ session is started callback. """

    def stop(self):

        """ stop XMPP bot. """

meds.bots.xmpp.cfg:

 yooooo !! 

meds.bots.xmpp.get_exception:

None

meds.bots.xmpp.kernel:

None

meds.bots.xmpp.stripped:

None

