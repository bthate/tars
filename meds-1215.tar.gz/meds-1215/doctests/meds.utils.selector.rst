meds.utils.selector
===================

 functions used in code to select what objects to use. 

meds.utils.selector.notwanted:

None

meds.utils.selector.selector:

None

meds.utils.selector.wanted:

None

