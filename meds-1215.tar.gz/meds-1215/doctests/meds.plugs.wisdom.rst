meds.plugs.wisdom
=================

 wijsheid, wijs ! 

meds.plugs.wisdom.wisdom:

None

