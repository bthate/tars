meds.plugs.rm
=============

 set deleted flag on objects. 

meds.plugs.rm.Object:

 yooooo !! 

meds.plugs.rm.kernel:

None

meds.plugs.rm.rm:

None

