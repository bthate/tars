meds.plugs.stats
================

 show statistics on suicide. 

meds.plugs.stats.Event:


        Event()

    

meds.plugs.stats.Object:

 yooooo !! 

meds.plugs.stats.alarm:

 yooooo !! 

meds.plugs.stats.cfg:

 yooooo !! 

meds.plugs.stats.cijfers:

 yooooo !! 

meds.plugs.stats.dbc:

 yooooo !! 

meds.plugs.stats.demografie:

 yooooo !! 

meds.plugs.stats.drugs:

 yooooo !! 

meds.plugs.stats.elapsed:

None

meds.plugs.stats.halfwaarde:

 yooooo !! 

meds.plugs.stats.medicijnen:

 yooooo !! 

meds.plugs.stats.nr:

None

meds.plugs.stats.nrsec:

 yooooo !! 

meds.plugs.stats.omdat:

 yooooo !! 

meds.plugs.stats.omschrijving:

 yooooo !! 

meds.plugs.stats.oordeel:

 yooooo !! 

meds.plugs.stats.perdag:

 yooooo !! 

meds.plugs.stats.periode:

 yooooo !! 

meds.plugs.stats.recepten:

 yooooo !! 

meds.plugs.stats.rechter:

 yooooo !! 

meds.plugs.stats.seconds:

None

meds.plugs.stats.seh:

 yooooo !! 

meds.plugs.stats.soort:

 yooooo !! 

meds.plugs.stats.stats:

None

meds.plugs.stats.suicide:

 yooooo !! 

meds.plugs.stats.tags:

 yooooo !! 

meds.plugs.stats.times:

 yooooo !! 

meds.plugs.stats.to_time:

None

meds.plugs.stats.today:

None

meds.plugs.stats.urls:

 yooooo !! 

meds.plugs.stats.wanted:

 yooooo !! 

meds.plugs.stats.ziekenhuis:

 yooooo !! 

meds.plugs.stats.zorg:

 yooooo !! 

