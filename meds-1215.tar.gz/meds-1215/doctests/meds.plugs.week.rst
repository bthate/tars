meds.plugs.week
===============

 show objects entered in the last week. 

meds.plugs.week.day:

None

meds.plugs.week.kernel:

None

meds.plugs.week.to_day:

None

meds.plugs.week.week:

None

