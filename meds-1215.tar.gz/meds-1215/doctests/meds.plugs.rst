meds.plugs
==========

 plugins with commands to exec. 

