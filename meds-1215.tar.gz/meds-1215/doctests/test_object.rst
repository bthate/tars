test_object
===========

""" doctests file tests for the Object class. """

""" create an Object. """

>>> o = Object()
>>> o
<meds.object.Object at ...>

""" test whether initiated Object is empty. """

>>> o = Object()
>>> o == {}
True

""" make printable output of the object. """

>>> o = Object()
>>> o.txt = "version"
>>> o.nice()
'{\n    "txt": "version"\n}'


""" clear objects state. """

>>> o.clear()

""" check whether o._ready isSet. """

>>> o.isSet()
False

>>> o.ready()
>>> o.isSet()
True

""" create a json string for the object. """

>>> o = Object()
>>> o.json()
'{}'

""" set a attribute and show the json string. """

>>> o = Object()
>>> o.txt = "version"
>>> o.json()
'{"txt": "version"}'

""" load an object. """

>>> import os
>>> o = Object()
>>> o.txt = "version"
>>> path = o.save()
>>> obj = o.load(path)
>>> o.json(sort_keys=True)
'{"_path": "...", "saved": "...", "txt": "version"}'

""" prepare a json string to save to disk. """

>>> o = Object()
>>> o.prepare()
'{\n    "data": {\n        "saved": "..."\n    },\n    "signature": "...",\n    "type": "Object"\n}'

""" read saved object from disk. """

>>> o = Object()
>>> p = o.save()
>>> o.load()
<meds.object.Object at ...>

""" read from disk using non existing path. """

>>> o = Object()
>>> o.read("test")
Traceback (most recent call last):
     ...
FileNotFoundError: [Errno 2] No such file or directory: 'test'

""" signal the object as ready. """

>>> o = Object()
>>> o.ready()

""" save an object. """

>>> o = Object()
>>> o.txt = "test1"
>>> o.save()
'.../...'

""" search keys for already set attributes. """

>>> o = Object()
>>> o.txt = "test"
>>> keys = o.search("txt")
>>> list(keys)
['txt']

""" sync an object to disk. """

>>> o.sync()
'.../doctest.data/...'

""" wait max 5 seconds on object.ready()

>>> o.wait(1.0)
