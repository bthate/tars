meds.run.udp
============

 start the udp server, allowing for echoing through udp. 

meds.run.udp.UDP:

 UDP class to echo txt through the bot, use the meds-udp program to send. 

meds.run.udp.init:

None

meds.run.udp.kernel:

None

meds.run.udp.shutdown:

None

