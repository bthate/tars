meds.plugs.reboot
=================

 reboot the bot, allowing statefull reboot (keeping connections alive). 

meds.plugs.reboot.Event:


        Event()

    

meds.plugs.reboot.cfg:

 yooooo !! 

meds.plugs.reboot.kernel:

None

meds.plugs.reboot.real_reboot:

None

meds.plugs.reboot.reboot:

None

