meds.plugs.restore
==================

 restore previously deleted objects. 

meds.plugs.restore.Object:

 yooooo !! 

meds.plugs.restore.kernel:

None

meds.plugs.restore.restore:

None

