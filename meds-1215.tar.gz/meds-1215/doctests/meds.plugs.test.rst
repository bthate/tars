meds.plugs.test
===============

 plugin containing test commands and classes. 

meds.plugs.test.Event:


        Event()

    

meds.plugs.test.cfg:

 yooooo !! 

meds.plugs.test.cmndrun:

None

meds.plugs.test.deadline:

None

meds.plugs.test.exception:

None

meds.plugs.test.flood:

None

meds.plugs.test.forced:

None

meds.plugs.test.html:

None

meds.plugs.test.kernel:

None

meds.plugs.test.name:

None

meds.plugs.test.runkernel:

None

meds.plugs.test.stripped:

None

meds.plugs.test.test:

None

meds.plugs.test.unicode:

None

meds.plugs.test.workdir:

None

meds.plugs.test.wrongxml:

None

