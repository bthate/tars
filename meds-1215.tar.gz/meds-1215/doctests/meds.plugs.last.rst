meds.plugs.last
===============

 show last object matching the criteria. 

meds.plugs.last.ENODIR:

None

meds.plugs.last.kernel:

None

meds.plugs.last.last:

None

