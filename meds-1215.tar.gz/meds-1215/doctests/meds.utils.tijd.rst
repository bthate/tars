meds.utils.tijd
===============

 plugin with time related functions. 

meds.utils.tijd.ENODATE:

 no date can be detected. 

meds.utils.tijd.day:

None

meds.utils.tijd.elapsed:

None

meds.utils.tijd.extract_time:

None

meds.utils.tijd.file_time:

None

meds.utils.tijd.fn_time:

None

meds.utils.tijd.get_day:

None

meds.utils.tijd.get_hour:

None

meds.utils.tijd.hms:

None

meds.utils.tijd.parse_time:

None

meds.utils.tijd.rtime:

None

meds.utils.tijd.to_date:

None

meds.utils.tijd.to_day:

None

meds.utils.tijd.to_time:

None

meds.utils.tijd.today:

None

meds.utils.tijd.year:

None

