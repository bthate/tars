meds.utils.cli
==============

 function concerning the command line options of the bot. 

meds.utils.cli.Completer:

None

meds.utils.cli.enable_history:

None

meds.utils.cli.hello:

None

meds.utils.cli.list_eggs:

None

meds.utils.cli.make_opts:

None

meds.utils.cli.parse_cli:

None

meds.utils.cli.reboot:

None

meds.utils.cli.save_history:

None

meds.utils.cli.set_completer:

None

meds.utils.cli.show_eggs:

None

meds.utils.cli.shutdown:

None

meds.utils.cli.stop:

None

meds.utils.cli.touch:

None

