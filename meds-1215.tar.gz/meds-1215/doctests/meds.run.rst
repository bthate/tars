meds.run
========

 meds.run modules are run at service or bot startup time. 

