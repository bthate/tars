meds.cfg
========


    default config objects containing default values for various services and plugins.

    >>> from meds.cfg import xmpp,irc,main,udp,rest,stats,rss,cli

    xmpp config

    >>> print(xmpp)
    {
        "cfg": "xmpp",
        "channel": "#meds",
        "nick": "meds",
        "owner": "",
        "port": 5222,
        "prefix": "cfg",
        "server": "localhost",
        "user": "meds@localhost",
        "username": "meds"
    }

    irc config

    >>> print(irc)
    {
        "cfg": "irc",
        "channel": "#meds",
        "ipv6": false,
        "nick": "meds",
        "owner": "",
        "port": 6667,
        "prefix": "cfg",
        "realname": "meds",
        "server": "localhost",
        "username": "meds"
    }

    main config

    >>> print(main)
    {
        "all": false,
        "args": [],
        "background": false,
        "cfg": "main",
        "colors": false,
        "debug": false,
        "default": [...],
        "exclude": "...",
        "init": "",
        "loglevel": "...",
        "modules": "",
        "nowait": true,
        "onerror": false,
        "openfire": false,
        "owner": "",
        "packages": [...],
        "path": false,
        "port": "...",
        "prefix": "cfg",
        "reboot": false,
        "resume": false,
        "scan": false,
        "services": false,
        "shell": false,
        "verbose": ...,
        "workdir": "doctest.data"
    }

    udp config

    >>> print(udp)
    {
        "cfg": "udp",
        "host": "localhost",
        "password": "boh",
        "port": 5500,
        "prefix": "cfg",
        "seed": "blablablablablaz"
    }

    rest config

    >>> print(rest)
    {
        "cfg": "rest",
        "hostname": "...",
        "port": 10102,
        "prefix": "cfg"
    }

    stats config

    >>> print(stats)
    {
        "cfg": "stats",
        "prefix": "cfg",
        "showurl": true
    }

    rss config

    >>> print(rss)
    {
        "cfg": "rss",
        "descriptions": [
            "officiel"
        ],
        "display_list": [
            "title",
            "link",
            "Date"
        ],
        "dosave": [],
        "ignore": [],
        "nosave": [],
        "showurl": false,
        "sleeptime": 600
    }

    cli config

    >>> print(cli)
    {
        "cfg": "cli",
        "welcome": "mogge!!"
    }



meds.cfg.Object:

 yooooo !! 

meds.cfg.cfg:

 yooooo !! 

meds.cfg.cli:

 yooooo !! 

meds.cfg.irc:

 yooooo !! 

meds.cfg.main:

 yooooo !! 

meds.cfg.rest:

 yooooo !! 

meds.cfg.rss:

 yooooo !! 

meds.cfg.stats:

 yooooo !! 

meds.cfg.udp:

 yooooo !! 

meds.cfg.xmpp:

 yooooo !! 

