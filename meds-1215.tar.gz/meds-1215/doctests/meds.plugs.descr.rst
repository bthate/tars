meds.plugs.descr
================

 commit descriptions of MEDS. 

meds.plugs.descr.Event:


        Event()

    

meds.plugs.descr.Repeater:

None

meds.plugs.descr.descr:

None

meds.plugs.descr.init:

None

meds.plugs.descr.kernel:

None

