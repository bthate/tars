meds.plugs.zorg
===============

 zorg plugin 

meds.plugs.zorg.Event:


        Event()

    

meds.plugs.zorg.Repeater:

None

meds.plugs.zorg.kernel:

None

meds.plugs.zorg.start:

None

meds.plugs.zorg.zorg:

None

