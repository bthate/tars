meds.plugs.cfg
==============

 plugin to change config values. 

meds.plugs.cfg.ENODIR:

None

meds.plugs.cfg._cfg:

 yooooo !! 

meds.plugs.cfg.cfg:

None

meds.plugs.cfg.kernel:

None

