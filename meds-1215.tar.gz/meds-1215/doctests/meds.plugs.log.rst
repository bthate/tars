meds.plugs.log
==============

 log text entered in a channel. 

meds.plugs.log.Event:


        Event()

    

meds.plugs.log.cb_log:

 save event. 

meds.plugs.log.get_hour:

None

meds.plugs.log.kernel:

None

meds.plugs.log.parse_time:

None

meds.plugs.log.re:

None

meds.plugs.log.timed:

None

