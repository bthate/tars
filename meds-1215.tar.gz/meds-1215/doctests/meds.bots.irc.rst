meds.bots.irc
=============

 class to implement an Internet Relay Chat (IRC) bot. 

meds.bots.irc.Bot:


        Bot(Scheduler)

        Base class for bot implementations. 

    

meds.bots.irc.EDISCONNECT:

None

meds.bots.irc.Event:


        Event()

    

meds.bots.irc.IRC:

 A bot that connects to IRC networks. 

    def action(self, channel, txt):

        """ /me ;] """

    def announce(self, txt):

        """ announce txt on the registered channels. """

    def bind(self):

        """ bind the socket to a hostname. """

    def close(self):

        """ close the bot's sockets """

    def connect(self):

        """ connect to the server. """

    def connected(self, event):

        """ send usermodes and join all channels. """

    def connecting(self):

        """ start a connecting loop until bot is connected. """

    def ctcp(self, nick, txt):

        """ ctcp txt to a user, """

    def ctcped(self, event):

        """ CTCP callback. """

    def ctcpreply(self, channel, txt):

        """ give a ctcp reply. """

    def dccconnect(self, event):

        """ connect back to DCC user. """

    def dcced(self, event, s):

        """" start DCC session. """

    def dccloop(self, event, s):

        """ DCC loop. """

    def delop(self, channel, nick):

        """ remove op permissions of a user. """

    def dispatch(self, event):

        """ dispatch an event onto a registered handler. """

    def donick(self, name):

        """ set bot's nick. """

    def doop(self, channel, nick):

        """ give op permissions to a user. """

    def errored(self, event):

        """ print a log message on error. """

    def event(self):

        """ read an IRC event. """

    def getchannelmode(self, channel):

        """ query channel modes. """

    def h366(self, event):

        """ 366 callback. """

    def h433(self, event):

        """ 433 callback. """

    def h513(self, event):

        """ 513 callback. """

    def invited(self, event):

        """ join a channel on invitation. """

    def join(self, channel, password):

        """ join a channel. """

    def joinall(self):

        """ join all registered channels """

    def joined(self, event):

        """ register the joined channel with the bot. """

    def logon(self):

        """ logon the IRC network. """

    def names(self, channel):

        """ query all names on a channel. """

    def notice(self, channel, txt):

        """ notice a channel. """

    def noticed(self, event):

        """ called when the bot is noticed. """

    def out(self, txt):

        """ the lowlevel function to output text to the server. """

    def output(self, channel, line):

        """ split text into max. 450 chars lines and send that to the IRC server. """

    def parsing(self, txt):

        """ parse the incoming string into an IRC event. """

    def part(self, channel):

        """ leave a channel. """

    def ping(self, txt):

        """ send PING. """

    def pinged(self, event):

        """ ping callback. """

    def pong(self, txt):

        """ send PONG. """

    def ponged(self, event):

        """ pong callback. """

    def privmsg(self, channel, txt):

        """ send privmsg to the server. """

    def privmsged(self, event):

        """ start DCC, CTCP responce or exec a command. """

    def push(self):

        """ loop to output txt to the server. """

    def quit(self, reason):

        """ send a quit message. """

    def quited(self, event):

        """ quit the bot. """

    def register(self, key, value):

        """ register a handler callback. """

    def say(self, channel, txt):

        """ say text on a specific channel. """

    def settopic(self, channel, txt):

        """ set TOPIC. """

    def some(self):

        """ read the socket until data arrives. """

    def start(self):

        """ start IRC bot. """

    def stop(self, close):

        """ stop IRC bot. """

    def voice(self, channel, nick):

        """ give voice permissions to a user. """

    def who(self, channel):

        """ ask who is on a channel. """

    def whois(self, nick):

        """ ask WHOIS data of a user. """

meds.bots.irc.Object:

 yooooo !! 

meds.bots.irc.Storage:

None

meds.bots.irc.cfg:

 yooooo !! 

meds.bots.irc.get_exception:

None

meds.bots.irc.j:

None

meds.bots.irc.kernel:

None

meds.bots.irc.split_txt:

None

