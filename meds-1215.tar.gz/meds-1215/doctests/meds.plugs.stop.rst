meds.plugs.stop
===============

 kill threads of running services. 

meds.plugs.stop.kernel:

None

meds.plugs.stop.stop:

None

