meds.rest
=========

 rest interface. 

meds.rest.Launcher:

None

meds.rest.Object:

 yooooo !! 

meds.rest.REST:

None

meds.rest.RESTHandler:

None

meds.rest.Storage:

None

meds.rest.cfg:

 yooooo !! 

meds.rest.get_exception:

None

meds.rest.init:

None

meds.rest.launcher:

None

meds.rest.objs:

 yooooo !! 

meds.rest.stop:

None

meds.rest.store:

None

