meds.plugs.reload
=================

 reload command. 

meds.plugs.reload.cj:

None

meds.plugs.reload.kernel:

None

meds.plugs.reload.reload:

None

