meds.utils
==========

bag of tricks

