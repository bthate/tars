meds.bots.cli
=============

 plugin providing a class for a CLI bot. 

meds.bots.cli.Bot:


        Bot(Scheduler)

        Base class for bot implementations. 

    

meds.bots.cli.CLI:

 console line interface bot. 

    def out(self, txt):

        """ output text to stdout. """

    def prompt(self):

        """ return bot prompt. """

    def start(self):

        """ run command line command. """

    def stop(self):

        """ stop CLI bot. """

meds.bots.cli.Event:


        Event()

    

meds.bots.cli.cfg:

 yooooo !! 

meds.bots.cli.sname:

None

