test_scheduler
==============

start Scheduler loop.

>>> from meds.scheduler import Scheduler
>>> scheduler = Scheduler()
>>> list(kernel.running())
[...]

give the scheduler an Event to work on.

>>> e = Event(txt="cmnds")
>>> scheduler.put(e)

stop the scheduler.

>>> scheduler.stop()
