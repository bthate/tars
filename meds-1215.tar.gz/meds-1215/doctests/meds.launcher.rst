meds.launcher
=============

 launches threads and provides code to wait for completion.  

meds.launcher.Launcher:

None

    def __init__(self):

        """
            create a launcher to launch tasks with.

            >>> from meds.launcher import Launcher
            >>> launcher = Launcher()
            >>> print(launcher)
            {
                "_status": "init",
                "tasks": []
            }

        """

    def kill(self, name):

        """
            kill all tasks matching name.

        """

    def launch(self):

        """
            launch a task and return it.

        """

    def running(self, name):

        """
            show running tasks.

        """

    def waiter(self, thrs, timeout):

        """
            wait for tasks to finish.

        """

meds.launcher.Object:

 yooooo !! 

meds.launcher.Task:

None

meds.launcher.get_exception:

None

meds.launcher.thrname:

None

