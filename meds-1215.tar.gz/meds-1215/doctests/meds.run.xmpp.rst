meds.run.xmpp
=============

 run at the start of a XMPP bot. 

meds.run.xmpp.XMPP:

 XMPP chat bot. 

meds.run.xmpp.init:

 start the XMPP bot. 

meds.run.xmpp.kernel:

None

meds.run.xmpp.shutdown:

None

