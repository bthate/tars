meds.plugs.start
================

 start a service by running its run script. 

meds.plugs.start.kernel:

None

meds.plugs.start.start:

None

