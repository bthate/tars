meds.plugs.mbox
===============

 read email from an mbox directory or file. 

meds.plugs.mbox.Object:

 yooooo !! 

meds.plugs.mbox.get_exception:

None

meds.plugs.mbox.mbox:

None

meds.plugs.mbox.to_date:

None

