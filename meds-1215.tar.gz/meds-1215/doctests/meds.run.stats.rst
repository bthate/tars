meds.run.stats
==============

 code to start the suicide plugin, mentioning a suicide statistic. 

meds.run.stats.Repeater:

None

meds.run.stats.cfg:

 yooooo !! 

meds.run.stats.init:

None

meds.run.stats.kernel:

None

meds.run.stats.shutdown:

None

