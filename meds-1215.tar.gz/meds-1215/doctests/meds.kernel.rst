meds.kernel
===========

 central piece of code that loads the plugins and starts services. 

meds.kernel.CLI:

 console line interface bot. 

meds.kernel.Event:


        Event()

    

meds.kernel.Kernel:

None

    def __init__(self, bot):

        """
            Kernel(Scheduler, Storage)

            >>> from meds.kernel import Kernel
            >>> k = Kernel()
            >>> print(k)
            {
                "_cbs": {},
                "_connected": {
                    "_ready": "<threading.Event object at ...>"
                },
                "_handlers": {},
                "_poll": "<select.epoll object at ...>",
                "_queue": "<queue.Queue object at ...>",
                "_resume": {},
                "_starttime": ...,
                "_status": "running",
                "_table": {},
                "_thrs": [
                    "<Task(Kernel.schedule, started daemon ...)>",
                    "<Task(Kernel.engine, started daemon ...)>"
                ],
                "booted": false,
                "tasks": []
            }

        """

    def announce(self, txt):

        """
            announce on all bots registered.

            >>> kernel.announce('ok')
            ok

        """

    def boot(self):

        """
            initialize the kernel.

            >>> kernel.boot()
  
        """

    def direct(self, name, package):

        """
            directly import a module.

            >>> kernel.direct('meds.plugs.test')
            <module 'meds.plugs.test' from '.../meds/plugs/test.py'>

        """

    def find(self, cmnd):

        """
            command lookup.

            >>> cmnds = kernel.find('test')
            >>> list(cmnds)
            [...]

        """

    def initialize(self):

        """
             run startup scripts for services.

             >>> thrs = kernel.initialize("meds.run")
             >>> kernel.waiter(thrs)
             [None, None, None, None, None, None, None, None]

        """

    def list(self, want):

        """
            list all functions in modules loaded with the bot.

            >>> funcs = kernel.list()
            >>> list(funcs)
            [...]

        """

    def modules(self, packages, want):

        """
            look for all modules that can be loaded.

            >>> mods = kernel.modules()
            >>> list(mods)
            [...]

        """

    def objects(self, want):

        """
           load module.

            >>> kernel.load('meds.plugs.test')
            <module 'meds.plugs.test' from ...>

        """

    def reload(self, name, force):

        """
            reload/load a module.

            >>> kernel.reload('meds.plugs.test')
            <module 'meds.plugs.test' from '.../meds/plugs/test.py'>

            force load a module

            >>> kernel.reload('meds.plugs.test', True)
            <module 'meds.plugs.test' from '.../meds/plugs/test.py'>

        """

    def resume(self):

        """
            resume the kernel from a kernel dump.

            >>> kernel.resume()

        """


meds.kernel.Launcher:

None

meds.kernel.OOL:

None

meds.kernel.Object:

 yooooo !! 

meds.kernel.Scheduler:

 schedules events. 

meds.kernel.Storage:

None

meds.kernel.cfg:

 yooooo !! 

meds.kernel.enable_history:

None

meds.kernel.get_exception:

None

meds.kernel.include:

None

meds.kernel.j:

None

meds.kernel.locked:

None

meds.kernel.name:

None

meds.kernel.set_completer:

None

