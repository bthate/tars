meds.plugs.aliases
==================

 add aliases to the kernel's aliases table. 

meds.plugs.aliases.alias:

        create an user that is allowed to do aliases:

        >>> from meds.users import User
        >>> user = User("user@bot", ["ALIAS"])
        >>> path = user.sync()

        add user permission to change aliases

        >>> event = bot.cmnd('permission user@bot ALIAS')
        {
            "_path": ".../doctest.data/user/...",
            "permissions": [
                "ALIAS"
            ],
            "prefix": "user",
            "saved": "...",
            "user": "user@bot"
        }

        add alias.

        >>> from meds.core import aliases
        >>> event = bot.cmnd('alias ls cmnds')
        ok ls
        >>> aliases.ls
        'cmnds'


meds.plugs.aliases.kernel:

None

