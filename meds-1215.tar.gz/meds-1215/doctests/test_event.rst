test_event
==========

doctests file tests for the Event class.

>>> e = Event()
>>> repr(e)
'<meds.event.Event at ...>'

announce to all channels on all bots.

>>> e.announce("yo!")
yo!

reply to an event.

>>> e.reply("okdan")
>>> e.show(bot)
okdan

reply with an ok message.

>>> e.ok("thnx")
>>> e.show(bot)
ok thnx

show the content of an Object.

>>> bot._result = []
>>> o = Object()
>>> o.txt = "test1"
>>> o.comment = "okdan"
>>> e.display(o)
>>> e.show(bot)
okdan test1

display keys with their values.

>>> e.display(o, ["txt"])
>>> e.show(bot)
test1

