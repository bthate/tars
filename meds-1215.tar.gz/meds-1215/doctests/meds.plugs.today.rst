meds.plugs.today
================

 show objects registered on the current day. 

meds.plugs.today.day:

None

meds.plugs.today.kernel:

None

meds.plugs.today.to_day:

None

meds.plugs.today.today:

None

