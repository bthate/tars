meds.plugs.objs
===============

 show objects collected in meds.objs module. 

meds.plugs.objs.objects:

 yooooo !! 

meds.plugs.objs.objs:

None

