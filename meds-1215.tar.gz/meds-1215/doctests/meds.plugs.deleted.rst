meds.plugs.deleted
==================

 show deleted records. 

meds.plugs.deleted.Object:

 yooooo !! 

meds.plugs.deleted.deleted:

None

meds.plugs.deleted.kernel:

None

