test_launcher
=============


""" doctests file tests for the Launcher class """

    >>> from meds.plugs.test import deadline
    >>> import time

""" launch a Task that runs a bot.announce("test1") """

    >>> launcher = Launcher()
    >>> thr = launcher.launch(bot.announce, "test1")
    >>> thr
    <Task(<bound method Bot.announce of <meds.bots.test.TestBot at ...>>, started ...)>

""" join the launched Task/thread """

    >>> launcher.waiter([thr,])
    test1
    [None]

""" Ask for a list of running Tasks. """

    >>> thr = launcher.launch(deadline, event)
    >>> launcher.waiter([thr,])
    starting 2 sec sleep
    [None]


""" kill a Task. """

    >>> bot._result = []
    >>> launcher.kill("deadline")
    []
    >>> list(launcher.running())
    [...]
