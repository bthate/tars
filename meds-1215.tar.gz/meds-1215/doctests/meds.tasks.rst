meds.tasks
==========

 launches threads and provides code to wait for completion.  

meds.tasks.Object:

 yooooo !! 

meds.tasks.Task:

None

    def __init__(self):

        """
            Task(threading.Thread)

            A Task is the working unit of the bot. It extends a thread so it can get it's job passed on to it through a queue.

            >>> from meds.launcher import Task
            >>> task = Task
            >>> print(task)
            <class 'meds.tasks.Task'>

        """

    def clear(self):

        """
            clear ready flag.

        """

    def exit(self):

        """
            stop the task.

        """

    def isSet(self):

        """
             see if task is ready.
 
        """

    def join(self):

        """
            join this task and return results.

        """

    def put(self, func):

        """
            put function and it's args on the work queue.

        """

    def ready(self):

        """
            flag task as being ready.

        """

    def run(self):

        """
            basic loop of a task.

        """

    def wait(self, sec):

        """
            wait for task to be ready.

        """

meds.tasks.get_exception:

None

meds.tasks.thrname:

None

