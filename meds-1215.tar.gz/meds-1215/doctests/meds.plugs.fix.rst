meds.plugs.fix
==============

 correct signature failures. 

meds.plugs.fix.ESIGNATURE:

None

meds.plugs.fix.Object:

 yooooo !! 

meds.plugs.fix.fix:

None

meds.plugs.fix.kernel:

None

