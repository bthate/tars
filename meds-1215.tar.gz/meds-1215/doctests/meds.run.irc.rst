meds.run.irc
============

 code run at irc startup. 

meds.run.irc.IRC:

 A bot that connects to IRC networks. 

meds.run.irc.init:

 start irc bot. 

meds.run.irc.kernel:

None

meds.run.irc.shutdown:

 shutdown irc servers. 

