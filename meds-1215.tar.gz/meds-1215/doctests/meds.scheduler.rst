meds.scheduler
==============

 the schaeduler. 

meds.scheduler.EDISCONNECT:

None

meds.scheduler.Launcher:

None

meds.scheduler.Scheduler:

 schedules events. 

    def __init__(self):

        """
            scheduler object constructor.

            >>> from meds.scheduler import Scheduler
            >>> scheduler = Scheduler()
            >>> print(scheduler)
            {
                "_cbs": {},
                "_connected": {},
                "_handlers": {},
                "_queue": "<queue.Queue object at ...>",
                "_status": "running",
                "_table": {},
                "_thrs": [
                    "<Task(Scheduler.schedule, started daemon ...)>"
                ],
                "tasks": []
            }

        """

    def call_cb(self, event):

        """
            pass an event on to registered callbacks.

            >>> scheduler.call_cb(event)

        """

    def scheduling(self, timeout=None):

        """
            start the scheduler.

            >>> scheduler.launch(scheduler.scheduling)
            <Task(<bound method Scheduler.scheduling of <meds.scheduler.Scheduler at ...>>, started ...)>

        """

    def prompt(self):

        """
            return a prompt suitable for display.

            >>> scheduler.prompt()

        """

    def put(self, event):

        """
            put an event to the scheduler.
            start the scheduler if not already running.

            >>> scheduler.put(event)

        """


    def stop(self):

        """
            stop the scheduler.

            >>> scheduler.stop()

        """

meds.scheduler.cfg:

 yooooo !! 

meds.scheduler.sname:

None

