meds.plugs.cmnds
================

 list all commands available. 

meds.plugs.cmnds.cmnds:

None

meds.plugs.cmnds.kernel:

None

