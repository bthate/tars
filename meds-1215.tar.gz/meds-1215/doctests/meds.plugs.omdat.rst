meds.plugs.omdat
================

 omdat plugin 

meds.plugs.omdat.Event:


        Event()

    

meds.plugs.omdat.Repeater:

None

meds.plugs.omdat.init:

None

meds.plugs.omdat.kernel:

None

meds.plugs.omdat.omdat:

None

