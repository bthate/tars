meds.plugs.find
===============

 search for objects matching the given criteria. 

meds.plugs.find.find:

None

meds.plugs.find.kernel:

None

