meds.utils.file
===============

 file related functions. 

meds.utils.file.cdir:

None

meds.utils.file.check_permissions:

None

meds.utils.file.get_exception:

None

meds.utils.file.high:

None

meds.utils.file.highest:

None

meds.utils.file.touch:

None

