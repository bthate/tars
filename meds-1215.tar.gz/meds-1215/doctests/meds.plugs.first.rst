meds.plugs.first
================

 show the first record matching the given criteria. 

meds.plugs.first.ENODIR:

None

meds.plugs.first.first:

None

meds.plugs.first.kernel:

None

