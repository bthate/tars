meds.plugs.user
===============

 command to edit permissions of a user. 

meds.plugs.user.User:

None

meds.plugs.user.kernel:

None

meds.plugs.user.user:

None

