meds.objs
=========

 objects stash, a central place to store objects. 

meds.objs.Kernel:

None

meds.objs.Object:

 yooooo !! 

meds.objs.kernel:

None

meds.objs.objs:

 yooooo !! 

