meds.storage
============

 read files from disk. 

meds.storage.Event:


        Event()

    

meds.storage.Object:

 yooooo !! 

meds.storage.Storage:

None

meds.storage.cfg:

 yooooo !! 

meds.storage.fn_time:

None

meds.storage.j:

None

meds.storage.notwanted:

None

meds.storage.selector:

None

meds.storage.storage:

None

meds.storage.wanted:

None

