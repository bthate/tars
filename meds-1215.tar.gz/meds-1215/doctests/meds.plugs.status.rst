meds.plugs.status
=================

 show runtime information of running threads. 

meds.plugs.status.Object:

 yooooo !! 

meds.plugs.status.elapsed:

None

meds.plugs.status.kernel:

None

meds.plugs.status.name:

None

meds.plugs.status.pid:

None

meds.plugs.status.ps:

None

meds.plugs.status.uptime:

None

meds.plugs.status.version:

None

meds.plugs.status.whoami:

None

