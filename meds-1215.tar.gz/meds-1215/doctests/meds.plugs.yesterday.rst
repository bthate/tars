meds.plugs.yesterday
====================

 show objects added yesterday. 

meds.plugs.yesterday.day:

None

meds.plugs.yesterday.kernel:

None

meds.plugs.yesterday.to_day:

None

meds.plugs.yesterday.yesterday:

None

