meds.plugs.dump
===============

 dump objects matching the given criteria. 

meds.plugs.dump.dump:

None

meds.plugs.dump.kernel:

None

