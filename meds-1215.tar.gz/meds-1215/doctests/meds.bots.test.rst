meds.bots.test
==============

 bot to use in tests. 

meds.bots.test.Bot:


        Bot(Scheduler)

        Base class for bot implementations. 

    

meds.bots.test.Event:


        Event()

    

meds.bots.test.Object:

 yooooo !! 

meds.bots.test.Test:

 custom class for unittests. 

meds.bots.test.TestBot:

 Bot to use in testing. 

    def announce(self, txt):

        """ announce some text. """

    def clear(self):

        """ reset TestBot._result. """

    def out(self, txt):

        """ raw output function, uses print(). """

    def say(self, channel, txt):

        """ output to channel. """

meds.bots.test.cfg:

 yooooo !! 

