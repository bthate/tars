meds.utils.resolve
==================

 plugin containing resolver functions. 

meds.utils.resolve.bind:

None

meds.utils.resolve.resolve_host:

None

meds.utils.resolve.resolve_ip:

None

