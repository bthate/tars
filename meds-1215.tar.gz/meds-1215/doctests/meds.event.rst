meds.event
==========

 object representing an event, uses a string as the default value and is able to be parsed for commands. 

meds.event.ENODATE:

 no date can be detected. 

meds.event.ENOTSET:

None

meds.event.Event:


        Event()

    

    def __getattr__(self, name):

        """
            return an attribute and if not available return an empty string as default value.

            >>> event.__getattr__('test')
            'ok'

            executing a method that is not available returns an exception.

            >>> event.test()
            Traceback (most recent call last):
            ...
            TypeError: 'str' object is not callable

        """

    def __init__(self):

        """
            event constructor:

            >>> from meds.event import Event
            >>> e = Event()
            >>> repr(e)
            '<meds.event.Event at ...>'

            construct with a dict:

            >>> e = Event({'test': 'ok'})
            >>> e.test
            'ok'

            construct with another event:

            >>> e = Event(event)
            >>> e.test
            'ok'

        """

    def announce(self, txt):

        """
            announce on fleet bots.

            >>> event.announce('yo!')
            yo!

        """

    def dispatch(self):

        """
            dispatch on the self._func attribute, if available.

            >>> from meds.core import kernel
            >>> from meds.event import Event
            >>> from meds.plugs.test import test
            >>> event = Event()
            >>> event.origin = 'me@bot'
            >>> event._funcs.append(test)
            >>> event.dispatch()
            >>> event.show(bot)
            hello me@bot

        """

    def display(self, obj, keys, txt):

        """
            display an object, showing the provided keys.

            >>> e = Event()
            >>> e.test = 'ok'
            >>> e.test2 = 'ok2'
            >>> event.display(e, ['test', 'test2'])
            ok ok2

        """

    def join(self):

        """
            join thread that has been started on handling this event.

            >>> event.join(1.0)

        """

    def ok(self, txt):

        """
            reply with 'ok'.

            >>> event.ok('ready')
            ok ready

        """

    def parse(self, txt):

        """
            parse a string into an event.

            >>> e = Event()
            >>> e.parse('version')
            >>> e._parsed.cmnd
            'version'

        """

    def reply(self, txt):

        """
            reply to origin of event.

            >>> event.reply('ok')
            ok

        """

    def say(self, channel, txt):

        """
            use _bot to output txt.

            >>> event.say('#test', 'ok')
            ok

        """

meds.event.Object:

 yooooo !! 

meds.event.days:

None

meds.event.get_exception:

None

meds.event.sj:

None

meds.event.to_day:

None

