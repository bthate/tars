meds.plugs.entry
================

 commands to enter data. 

meds.plugs.entry.Object:

 yooooo !! 

meds.plugs.entry.log:

None

meds.plugs.entry.rss:

None

meds.plugs.entry.shop:

None

meds.plugs.entry.todo:

None

