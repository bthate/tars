meds.ool
========

 object of lists, usefull to iterate of collections of objects. 

meds.ool.OOL:

None

meds.ool.Object:

 yooooo !! 

