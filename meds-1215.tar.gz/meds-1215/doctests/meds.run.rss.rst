meds.run.rss
============

 runtime code to intialize RSS. 

meds.run.rss.Object:

 yooooo !! 

meds.run.rss.RSS:

None

meds.run.rss.fetcher:

None

meds.run.rss.init:

None

meds.run.rss.kernel:

None

meds.run.rss.objs:

 yooooo !! 

meds.run.rss.shutdown:

None

