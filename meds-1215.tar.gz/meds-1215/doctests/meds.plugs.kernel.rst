meds.plugs.kernel
=================

 command to dump kernel in json format. 

meds.plugs.kernel.kern:

None

meds.plugs.kernel.kernel:

None

