meds.bots
=========


    A Bot can connect to a network and communicate with that network.
    Methods are available to join channels and announce text to those channels.

meds.bots.Bot:


        Bot(Scheduler)

        Base class for bot implementations. 


    def announce(self, txt):

        """
            Announce text to all joined channels.

            >>> bot.announce('ok')
            ok
            
        """

    def cmnd(self, txt):

        """
            Run a command on the bot.

            >>> event = bot.cmnd('cmnds')
            alias,announce,begin,cfg,cmnds,core,deleted,dump,end,fetcher,find,first,fix,fleet,init,kernel,last,log,loud,mbox,meet,permission,pid,ps,re,reboot,reload,restore,rm,rss,shop,shutdown,silent,start,stats,stop,timer,today,todo,tomorrow,uptime,user,version,week,whoami,wisdom,yesterday

        """

    def event(self):

        """
            Get an event from the internal queue.

        """

    def events(self):

        """
            Use epoll object to poll for events.

        """

    def join(self, channel):

        """
            Join a channel.

            >>> bot.join('#test')

        """

    def joinall(self):

        """
            Join all channels registered in self.channels

            >>> bot.joinall()

        """

    def out(self, txt):

        """
            Lowlevel output function.

            >>> bot.out('ok')
            ok

        """

    def register_fd(self, f):

        """
            Add a file to the bot to monitor for input.

            >>> import sys
            >>> bot.register_fd(sys.stdin)
            0

        """

    def resume(self):

        """
            Resume the bot from a previous stored kernel dump.

            >>> bot.resume()
            Traceback (most recent call last):
            ... 
            meds.errors.ERESUME

        """

    def say(self, channel, txt):

        """
            Output text to channel.

            >>> bot.say('#test', 'ok')
            ok

        """

meds.bots.Event:


        Event()

    

meds.bots.Object:

 yooooo !! 

meds.bots.Scheduler:

 schedules events. 

meds.bots.get_exception:

None

meds.bots.sname:

None

