meds.udp
========

 relay txt through a udp port listener. 

meds.udp.Object:

 yooooo !! 

meds.udp.UDP:

 UDP class to echo txt through the bot, use the meds-udp program to send. 

    def exit(self):

        """ shutdown the UDP server. """

    def output(self, txt, addr):

        """ output to all bots on fleet. """

    def start(self):

        """ start the UDP server. """

meds.udp.cfg:

 yooooo !! 

meds.udp.kernel:

None

meds.udp.name:

None

