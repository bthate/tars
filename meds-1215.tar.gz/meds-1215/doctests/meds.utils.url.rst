meds.utils.url
==============

 functions that fetch data from url 

meds.utils.url.extract_div:

None

meds.utils.url.get_encoding:

None

meds.utils.url.get_exception:

None

meds.utils.url.get_feed:

None

meds.utils.url.get_url:

None

meds.utils.url.get_url2:

None

meds.utils.url.need_redirect:

None

meds.utils.url.parse_url:



    Attribute       Index   Value                   Value if not present
    scheme          0       URL scheme specifier    empty string
    netloc          1       Network location part   empty string
    path            2       Hierarchical path       empty string
    query           3       Query component         empty string
    fragment        4       Fragment identifier     empty string

    

meds.utils.url.strip_html:

None

meds.utils.url.unescape:

None

meds.utils.url.useragent:

None

