meds.object
===========


    An Object adds 'dotted access' to dicts to allow for better readable code.
    Object's also allow for saving JSON to disk to allow it to be restored at a later time.


meds.object.ENOJSON:

None

meds.object.ESET:

None

meds.object.ESIGNATURE:

None

meds.object.Object:

 yooooo !! 

    def __contains__(self, key):

        """
            See if the object contains a key.

            >>> obj.test = 'ok'
            >>> "test" in obj
            True

        """

    def __getattr__(self, name):

        """
            Define certain default actions on getting an attribute, if not present.

        """

    def __getattribute__(self, name):

        """
            Allow dotted access to a dict

            >>> obj.test = 'ok'
            >>> obj.__getattribute__('test')
            'ok'

        """

    def __repr__(self):

        """
            Return a default representation of the object

            >>> repr(obj)
            '<meds.object.Object at ...>'

        """

    def __setattr__(self, name, value):

        """
            Set an attribute on the object.
            Don't allow methods to be set, raise an AttributeSet exception if this is the case.

            >>> obj.__setattr__('test', 'ok')

        """

    def __setitem__(self, name, value):

        """
            Set an item on the base dict.

            >>> obj['test'] = 'ok'

        """

    def __str__(self):

        """
            Return a string representation of the object.

            >>> obj.test = 'ok'
            >>> print(obj)
            {
                "test": "ok"
            }

        """

    def clear(self):

        """
            Clear ready flag.

            >>> obj.clear()
            
        """

    def consume(self, value):

        """
            Consume a list into the object. 
            List elements are stored as key0, key1 etc. 

            >>> a = [1, 2, "test"]
            >>> obj.consume(a)
            >>> obj.key2
            'test'

        """

    def grep(self, val):

        """ 
            Grep all values of the object.
            Return an object with matched key, values.

            >>> obj.test = 'ok'
            >>> o = obj.grep('ok')
            >>> o.json()
            '{"test": "ok"}'
            
        """

    def isSet(self):

        """
            Check if ready flag is set.

            >>> obj.isSet()
            False

        """

    def json(self):

        """
            Return object as a JSON string.

            >>> o = Object()
            >>> o.test = 'ok'
            >>> o.json()
            '{"test": "ok"}'

        """

    def load(self, path, force):

        """
            Construct an object from the provided path, or object._path if the object has already been saved. 

            >>> o = Object()
            >>> o.test = 'ok'
            >>> path = o.save('test')
            >>> o.load(path)
            <meds.object.Object at ...>
            >>> o.test
            'ok'

        """

    def merge(self, obj):

        """ 
            Merge another Object into this one, not overriding already existing entries. 

            >>> o = Object()
            >>> o.test = 'ok'
            >>> obj.merge(o)
            >>> obj.test
            'ok'

        """

    def nice(self):

        """
            Return a prettied JSON string of the object.

            >>> o = Object()
            >>> o.test = 'ok'
            >>> o.nice()
            '{..."test": "ok"...}'

        """

    def prepare(self):

        """
            Prepare the object for saving.

            >>> o = Object()
            >>> o.test = 'ok'
            >>> o.prepare()
            '{..."data": {..."saved": "...",..."test": "ok"...},..."signature": "...",..."type": "Object"...}'

        """

    def read(self, path):

        """
            Read data from disk, skipping comments.

            >>> o = Object()
            >>> o.test = 'ok'
            >>> path = o.save('test')
            >>> data = o.read(path)
            >>> o.test
            'ok'

        """

    def ready(self):

        """
            Check is object is ready.

            >>> obj.ready()

        """

    def register(self, key, val):

        """
            Register a key, value pair.

            >>> obj.register('test', 'ok', force=True)
            >>> obj.test
            'ok'

        """

    def save(self, stime):

        """
            Save the object to disk using current time, optional filename can be provided.

            >>> o = Object()
            >>> o.test = 'ok'
            >>> o.save() 
            '.../doctest.data/.../...'

        """

    def search(self, name):

        """
            Search the object for keys, skipping keys that start with an underscore.

            >>> obj.test = 'ok'
            >>> o = obj.search('te')
            >>> o.json()
            '{"test": "ok"}'
            
        """

    def wait(self, sec):

        """
            Wait for object to be ready.

            >>> obj.wait(1.0)

        """

meds.object.cdir:

None

meds.object.dopath:

None

meds.object.dumps:

None

meds.object.get_strace:

None

meds.object.j:

None

meds.object.locked:

None

meds.object.make_signature:

None

meds.object.rtime:

None

meds.object.slice:

None

meds.object.urled:

None

meds.object.verify_signature:

None

