meds.plugs.timer
================

 timer command to schedule a text to be printed on a given time. 

meds.plugs.timer.ENODATE:

 no date can be detected. 

meds.plugs.timer.Event:


        Event()

    

meds.plugs.timer.Timer:

None

meds.plugs.timer.day:

None

meds.plugs.timer.get_day:

None

meds.plugs.timer.get_hour:

None

meds.plugs.timer.kernel:

None

meds.plugs.timer.timer:

None

meds.plugs.timer.to_day:

None

