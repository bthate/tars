meds.utils.getters
==================

 functions that can be used on objects. 

meds.utils.getters.ENODATE:

 no date can be detected. 

meds.utils.getters.check_permissions:

None

meds.utils.getters.dated:

None

meds.utils.getters.days:

None

meds.utils.getters.elapsed:

None

meds.utils.getters.fn_time:

None

meds.utils.getters.fnn:

None

meds.utils.getters.j:

None

meds.utils.getters.look:

None

meds.utils.getters.match:

None

meds.utils.getters.matching:

None

meds.utils.getters.path:

None

meds.utils.getters.root:

None

meds.utils.getters.rtime:

None

meds.utils.getters.slice:

None

meds.utils.getters.timed:

None

meds.utils.getters.to_date:

None

meds.utils.getters.to_time:

None

meds.utils.getters.urled:

None

