meds.utils.type
===============

 module containing type related functions. 

meds.utils.type.iscmnd:

None

meds.utils.type.isfunc:

None

meds.utils.type.isobj:

None

