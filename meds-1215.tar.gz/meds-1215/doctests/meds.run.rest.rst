meds.run.rest
=============

 start the REST server, providing access to stored objects through a httpd server. 

meds.run.rest.REST:

None

meds.run.rest.RESTHandler:

None

meds.run.rest.cfg:

 yooooo !! 

meds.run.rest.init:

None

meds.run.rest.kernel:

None

meds.run.rest.shutdown:

None

