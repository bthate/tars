meds.utils.name
===============

 name related functions, strip object names to be easily representable. 

meds.utils.name.name:

None

meds.utils.name.sname:

None

