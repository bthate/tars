meds.run.timer
==============

 start the timer daemon, running all reminders. 

meds.run.timer.Event:


        Event()

    

meds.run.timer.Storage:

None

meds.run.timer.Timer:

None

meds.run.timer.init:

None

meds.run.timer.kernel:

None

meds.run.timer.shutdown:

None

