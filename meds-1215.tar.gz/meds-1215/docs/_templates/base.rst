{{ fullname }}
{{ underline }}

.. auto{{ objtype }}:: {{ objname }}

.. currentmodule:: {{ module }}
