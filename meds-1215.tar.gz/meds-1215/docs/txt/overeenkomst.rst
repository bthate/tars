############
OVEREENKOMST
############

De van vorm vrijgegeven overeenkomst is een gevaar waar het een
behandelovereenkomst betreft. 

Niet de mondelinge overeenkomst, iedereen ziet het gevaar daarvan.
Maar de overeenkomst waarvan de inhoud nog later te bepalen is.

Omdat de patient niet instaat is zijn belangen ook in de overeenkomst te
laten vermelden, is de vorm van de overeenkomst meestal niet in zijn belang.

Sterker, bij overeenkomsten die het de gezondheid betreft is het van belang
dat de vormvrijheid niet ter plaatse bepaald moet worden en niet overgelaten
word aan het ter plekke gepleegde oordeel.

