##########
MEDICIJNEN
##########

Een antagonist is een stof die zich bindt aan een receptor zonder een biologische respons op te roepen, en daarmee de werking van een agonist dempt of bij verzadiging van de receptor zelfs verhindert. Zoals een agonist een respons veroorzaakt, blokkeert een antagonist die respons.

