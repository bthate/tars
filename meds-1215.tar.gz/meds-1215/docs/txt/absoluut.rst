.. _absoluut:

ABSOLUUT
~~~~~~~~

.. image:: ../jpg/absoluut2.jpg
