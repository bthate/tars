########
AANGIFTE
########


op datum ... doet bij de politie te ... aangifte:


 Naam                        : 

 Voornamen                   : 

 Geboortedatum               : 

 Adres                       : 

 Woonplaats                  : 

 Postcode                    : 

 Telefoon                    : 


tegen de verdachte:


 Naam                        : 

 Voornaam/initialen en titel :  

 Geboortedatum               :  

 Adres                       : 

 Woonplaats                  : 

 Postcode                    : 

 Functie                     : 

 Werkgever                   : 


 Datum/tijdstip plegen feit: van ... tot ...

 Plaats van het feit : 

 Omschrijving incident feit:  

  1) Antipsychotica blokkeren de receptoren en benadelen daarmee de gezondheid.
  2) Men dient de antipsychotica ook toe voor het blokkeren van de receptoren, opzettelijke benadeling van de gezondheid.
  3) Behandeling met antipsychotica is langdurige opzettelijke benadeling van de gezondheid.

 Aankruisen welk artikel en wet van toepassing is.

  [x] Mishandeling  - Wetboek van Strafrecht 300 lid 4 

 Ik verzoek om een bewijs van aangifte.
