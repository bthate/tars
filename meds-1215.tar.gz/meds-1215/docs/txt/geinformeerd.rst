.. _geinformeerd:

geinformeerd
~~~~~~~~~~~~

.. image:: ../jpg/geinformeerd.jpg
    :width: 100%
