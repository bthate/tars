######
EMAILS
######

::

 A. van Miltenburg			voorzitter@tweedekamer.nl
 L.Bontes 				l.bontes@tweedekamer.nl
 S. van Haersma Buma			S.Buma@tweedekamer.nl
 J.Houwers				j.houwers@tweedekamer.nl
 J.F. KLaaver				j.klaver@tweedekamer.nl
 N.P.M Klein				n.klein@tweedekamer.nl
 H.C.M Krol				h.krol@tweedekamer.nl
 T. Kuzu				t.kuzu@tweedekamer.nl
 A. Pechthold				a.pechthold@tweedekamer.nl
 E.G.M Roemer				e.g.m.roemer@tweedekamer.nl
 D.M. Samsom				D.Samsom@tweedekamer.nl
 A. Slob				A.Slob@tweedekamer.nl
 C.G. van der Staaij			C.vdStaaij@tweedekamer.nl
 M.L. Thieme				marianne.thieme@tweedekamer.nl
 R.A. van Vliet				r.vvliet@tweedekamer.nl
 G. Wilders				g.wilders@tweedekamer.nl
 H. Zijlstra				h.zijlstra@tweedekamer.nl


 voorzitter@tweedekamer.nl
 l.bontes@tweedekamer.nl
 S.Buma@tweedekamer.nl
 j.houwers@tweedekamer.nl
 j.klaver@tweedekamer.nl
 n.klein@tweedekamer.nl
 h.krol@tweedekamer.nl
 t.kuzu@tweedekamer.nl
 a.pechthold@tweedekamer.nl
 e.g.m.roemer@tweedekamer.nl
 D.Samsom@tweedekamer.nl
 A.Slob@tweedekamer.nl
 C.vdStaaij@tweedekamer.nl
 marianne.thieme@tweedekamer.nl
 r.vvliet@tweedekamer.nl
 g.wilders@tweedekamer.nl
 h.zijlstra@tweedekamer.nl
