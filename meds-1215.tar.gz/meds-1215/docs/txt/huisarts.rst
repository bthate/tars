########
HUISARTS
########

Behandeling met antipsychotica is langdurige mishandeling met de dood tot gevolg.

1) patient meld bijwerkingen die duiden op vergiftiging (flauwvallen, slecht zien)
2) patient word doorverwezen voor klacht
3) arts meet niet de medicijnspiegel
4) patient is vergiftigt of zit zonder medicijnen
5) patient pleegt suicide
