FACT
~~~~

(F)ACT bied niet de noodzakelijke verpleging die behandeling met antipsychotica verantwoord maken:

* verpleging naar gelang de situatie - meer zorg naarmate de situatie erger is, is niet preventief.
* niet 7 x 24 uurs verpleging - in het weekend en avonduren niet aanwezig.
* psychiater is niet op de hoogte van de situatie van de patient.
* de patient behandelovereenkomsten zijn niet volledig.
* zonder bedden geen snelle terugbrenging naar ziekenhuis mogelijk.
* Een arts die mishandelt met dodelijke stof en de noodzakelijke verpleging achterwege laat maakt levensgevaarlijke omstandigheden voor zijn patienten. Dit is voorwaardelijke opzet, waarbij het risico genomen word dat iemand overlijd. Word het risico werkelijkheid dan is het moord.

Antipsychotica zijn dodelijk, gebruik brengt levensgevaar met zich mee:

* Als een arts ontkent dat hij aan het mishandelen is.
* Als een arts de bloedspiegel van een medicijn niet meet.
* Als de noodzakelijke verpleging niet aanwezig is.

