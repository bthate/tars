####
EVRM
####

.. literalinclude:: Verdrag-tot-bescherming-van-de-rechten-v.txt
    :encoding: ISO-8859-15