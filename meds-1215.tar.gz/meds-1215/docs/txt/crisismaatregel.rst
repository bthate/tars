CRISISMAATREGEL
~~~~~~~~~~~~~~~

1. De burgemeester kan ten aanzien van een persoon die zich in zijn gemeente bevindt een
crisismaatregel nemen, indien:

a. er onmiddellijk dreigend ernstig nadeel is;
b. er een ernstig vermoeden bestaat dat het gedrag van een persoon als gevolg van een
   psychische stoornis dit dreigend ernstig nadeel veroorzaakt;
c. met de crisismaatregel het ernstig nadeel kan worden weggenomen;
d. de crisissituatie dermate ernstig is dat de procedure voor een zorgmachtiging niet kan
   worden afgewacht; en
e. er verzet is als bedoeld in artikel 1:4 tegen verplichte zorg.

2. De burgemeester kan een wethouder mandaat verlenen voor het nemen van een crisismaatregel
