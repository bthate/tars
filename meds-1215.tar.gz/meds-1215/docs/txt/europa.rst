######
EUROPA
######

De introductie van het nieuwe systeem in Nederland resulteert dat de 24/7 support weggenomen van de patient en 
vervangen door een front-end back-end systeem, waar de front-end besluit of de situatie van de patient ernstig genoeg is om 
actie de ondernemen. Een diagnose van de front-end dat verdere hulp niet - meteen - nodig is, is de doodsoorzaak 
voor patienten met serieuze psychiatrische aandoeningen. 

De ontkenning dat de patient in een bedreigende situatie zit, hem vertellen dat hij tot maandag moet wachten voordat 
er echte hulp is, zet deze patient in de situatie waar hij moet zien om te gaan met hemzelf en de gedachte om hier 
niet meer te willen zijn voor meer dan 48 uur. 

De behandeling word verkocht aan de regering op de belofte om de noodzaak tot ziekenhuis opnames te verminderen. Na 10 jaar
van gebruik van deze behandelmethode toont aan dat het NIET lijd tot minder noodzaak voor ziekenhuis opnames.  Wat te
verwachten is als de patient het hele weekend geen hulp heeft, terwijl 24/7 een voorwaarde is voor de behandeling.

De meeste suicides gebeuren in het weekend.
