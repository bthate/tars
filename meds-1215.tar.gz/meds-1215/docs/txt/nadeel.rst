NADEEL
~~~~~~

Voor de toepassing van deze wet en de daarop berustende bepalingen wordt onder “ernstig
nadeel” verstaan, het bestaan van of het aanzienlijk risico op:

a. levensgevaar, ernstig lichamelijk letsel, ernstige psychische, materiële, immateriële of
   financiële schade, ernstige verwaarlozing of maatschappelijke teloorgang, ernstig verstoorde
   ontwikkeling voor of vanbetrokkene of een ander;
b. bedreiging van de veiligheid van betrokkene al dan niet doordat hij onder invloed van een
   ander raakt;
c. de situatie dat betrokkene met hinderlijk gedrag agressie van anderen oproept;
d. de situatie dat de algemene veiligheid van personen of goederen in gevaar is.
