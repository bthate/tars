#######
RECHTEN
#######

Verdrag tot Berscherming van de Rechten van de Mens en de Fundementele
Vrijheden.

1. Verplichting tot eerbiediging van de rechten van de mens
2. Recht op leven
3. Verbod op foltering
4. Verbod van slavernij en dwangarbeid
5. Recht op vrijheid en veiligheid
6. Recht op een eerlijk proces
7. Geen straf zonder wet
8. Recht op eerbieding van prive, familie en gezinsleven
9. Vrijheid van gedachte, geweten en godsdienst
10. Vrijheid van meningsuiting
11. Vrijheid van vergadering en vereniging
12. Recht te huwen
13. Recht op een daadwerkelijk rechtsmiddel
14. Verbod op disciriminatie
15. Afwijking in geval van noodtoestand
16. Beperkingen op politieke activiteiten van vreemdelingen
17. Verbod van misbruik van recht
18. Inperking van de toepassing van beperkingen op rechten
19. Instelling van het Hof
20. Aantal rechters
21. Voorwaarden voor uitoefening van de functie
22. Verkiezing van rechters
23. Ambtstermijn en ontheffing uit het ambt
24. Griffie en rapporteurs
25. Hof in voltallige vergadering bijeen
26. Allenzittende rechters, comities, Kamers en Grote Kamer
27. Bevoegdheden van de alleenzittende rechters
28. Bevoegdheden van comites
29. Beslissingen van Kamers inzake ontvankelijkheid en gegrondheid
30. Afstand van rechtsmacht ten gunste van de Grote Kamer
31. Bevoegdheden van de Grote Kamer
32. Rechtsmacht van het Hof
33. Interstatelijke zaken
34. Individuele verzoekschriften
35. Voorwaarden voor ontvankelijkheid
36. Tussenkomst door derden
37. Schrapping van de rol
38. Behandeling van de zaak
39. Minnelijke schikkingen
40. Openbare zittingen en toegang tot de stukken
41. Billijke genoegdoening
42. Uitspraken van Kamers
43. Verwijzing naar de Grote Kamer
44. Einduitspraken
45. Redenen die aan uitspraken  en beslissingen ten grondslag liggen
46. Bindende kracht en tenuitvoerlegging van uitspraken
47. Adviezen
48. Bevoegdheid van het Hof met betrekking tot adviezen
49. Redenen die aan adviezen ten grondslag liggen
50. Kosten van het Hof
51. Voorrechten en immuniteiten van de rechters
52. Verzoeken om inlichtingen van de Secretaris-General
53. Waarborging van de bestaande rechten van de mens
54. Bevoegdheden van het Comite van Ministers
55. Uitsluiting van andere wijzen van geschillenregeling
56. Territoriale werkingssfeer
57. Voorbehouden
58. Opzegging
59. Ondertekening en bekrachtiging
