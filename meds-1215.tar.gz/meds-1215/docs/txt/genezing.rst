GENEZING
########

Antipsychotica genezen mensen niet van hun ziekte zodat ze minder gevaar zijn. Deze medicijnen zetten de hersenen op nonactief, zodat 
je de symptomen onderdrukt. Je bent dan minder gevaar omdat je niet functioneert, niet omdat je niet ziek meer bent.

Dit niet functioneren is voor de patient wel de dood. Je hersens slinken met 1% per jaar, je receptoren worden geblokkeerd en 
activiteit is dan ook moeilijk te doen. Het lichaam is niet meer instaat om in actie te komen, het bewustzijn is niet meer 
te motiveren tot bewegen. Resultaat is de suicide wens.

Mensen worden behandeld met antipsychotica omdat men hoopt de patient een minder groot gevaar te laten zijn door hem van zijn ziekte te genezen.
Deze medicijnen genezen mensen niet van hun wanen en hallucinaties, ze zetten de hersenen op non-actief zodat je niet meer instaat bent een 
gevaar te zijn. Niet het niet meer hebben van wanen en hallucinaties is het resultaat, het niet meer werken van de hersens is wat 
de medicijnen doen. Uitschakelen van de hersens is wat anders dan mensen genezen van hun wanen/hallucinaties.
