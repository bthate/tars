WET
###

In Nederland heeft de GGZ patient geen daadwerkelijk rechtsmiddel. Daarom is
het noodzaak om zelf bewijsmateriaal te verzamelen zodat men zelfstandig tot
een aangifte kan komen in plaats van een klacht over wat eigenlijk
misdrijven zijn.

BENADELING:

1) Progressive decrement in white matter volume was most evident among patients who received more antipsychotic treatment - http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3476840/

STRAFBAARHEID:

1) Artikel 300.4 Met mishandeling wordt gelijkgesteld opzettelijke benadeling van de gezondheid.
2) Artikel 304.3 indien het misdrijf wordt gepleegd door toediening van voor het leven of de gezondheid schadelijke stoffen.

STRAFRECHT:

1) Antipsychotica zijn in hun werking benadeling van de gezondheid.
2) Daarmee is toedienen van deze medicijnen mishandeling zoals vernoemd in het wetboek van strafrecht.
3) Het doen laten verdwijnen van gevaar is het oogmerk.

FOLTERING:

1) Een maatregel is geen straf.
2) Een ambtsbevel is geen rechtvaardiging.
3) Geen enkele omstandigheid is een rechtvaardiging.

EVRM:                           

1) Recht op leven
2) Verbod van foltering
3) Recht op vrijheid en veiligheid
4) Recht op daadwerkelijk rechtsmiddel
5) Verbod van misbruik van recht  
