##########
SLACHOFFER
##########

Status Slachtoffer 69389/12.

De patient moet zelf in het weekend via 112 de crisis dienst van de GGZ zien te bereiken. Voor een patient met een Ernstige Psychiatrische Aandoening kompleet onmogelijk om te doen. In acute psychische nood kan men NIET terecht bij een crisisdienst.
