VRAAG
~~~~~

1. Een ieder kan een melding doen bij het college van burgemeester en wethouders over een
persoon die woonachtig is in die gemeente of aldaar overwegend verblijft voor wie de noodzaak
tot geestelijke gezondheidszorg, die mogelijk zou moeten worden verleend met verplichte zorg,
zou moeten worden onderzocht.