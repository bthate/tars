VERLENEN
~~~~~~~~

Verplichte zorg kan worden verleend om:

a. een crisissituatie af te wenden,
b. ernstig nadeel af te wenden,
c. onderzoek naar de geestelijke gezondheid van betrokkene uit te voeren,
d. de geestelijke gezondheid van betrokkene te stabiliseren,
e. de geestelijke gezondheid van betrokkene dusdanig te herstellen dat hij zijn autonomie
   zoveel mogelijk herwint, of
f. het stabiliseren of herstellen van de fysieke gezondheid van betrokkene in het geval diens
   gedrag als gevolg van zijn psychische stoornis leidt tot ernstig nadeel daarvoor.