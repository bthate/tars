VERGIFTIGING
============

MILDE SYMPTOMEN VAN VERGIFTIGING

1) gedragsveranderingen (bijv., rusteloosheid, crankiness)
2) diarree
3) duizeligheid
4) slaperigheid
5) vermoeidheid
6) hoofdpijn
7) verlies van eetlust
8) kleine huid- of oogirritaties
9) misselijkheid of maagklachten
10) passen hoest (hoest die komt en gaat)
11) pijn of stijfheid in de gewrichten
12) dorst

MATIGE SYMPTOMEN

1) wazig zicht
2) Verwarring en desoriëntatie
3) ademhalingsproblemen
4) kwijlen
5) overmatig tranen
6) koorts
7) lage bloeddruk (hypotensie)
8) verlies van spiercontrole en spiertrekkingen
9) bleekheid (bleekheid) of gespoeld of gelige huid
10) aanhoudende hoest
11) snelle hartslag
12) toevallen
13) ernstige diarree
14) ernstige misselijkheid
15) maagkrampen
16) zweten
17) dorst
18) bevend
19) zwakte

BELANGERIJKSTE SYMPTOMEN

1) hartstilstand
2) krampen
3) diffuse intravasale stolling (mits ongecontroleerde bloeden of bloedstolling veroorzaakt)
4) oesofageale vernauwing (vernauwing van het orgaan dat voedsel uit de mond draagt naar de maag)
5) koorts (vaak hoog)
6) onvermogen om te ademen
7) versnelde ademhaling (snelle ademhaling)
8) verlies van bewustzijn
9) spiertrekkingen (ongecontroleerd en ernstige)
10) snelle hartslag met een lage bloeddruk
11) ademnood dat intubatie vereist (betreft het passeren van een buis naar beneden de luchtpijp [luchtpijp] om de longen te ademen bijstand te verlenen; mechanische beademing [dwz een ventilator] kan nodig zijn)
12) epileptische aanvallen die niet reageren op de behandeling (de zogenaamde status epilepticus)
13) dorst (vaak extreme)


