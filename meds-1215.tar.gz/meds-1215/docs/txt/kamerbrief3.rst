KAMERBRIEF3
===========

Geachte mevrouw Ricagnoli,

bedankt voor uw reactie op mijn brief van 26 oktober 2015. Ik wil hieronder nog een keer duidelijk maken waarom verplichte behandeling met antipsychotica mishandeling is en dat uw kamer het zich niet kan veroorloven een wet aan te nemen die tot deze mishandeling verplicht EN deze mishandeling daarmee niet strafbaar maakt.

Uit onderzoek blijkt dat antipsychotica schadelijk zijn voor de gezondheid, ze veroorzaken verlies van hersenweefsel.

" Viewed together with data from animal studies, our study suggests that antipsychotics have a subtle but measurable influence on brain tissue loss over time"

Zie http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3476840/

Ook de lijst van bijwerkingen die antipsychotica met zich meebrengen maakt duidelijk dat er sprake is van benadeling van de gezondheid.

Er moet sprake zijn van opzettelijke benadeling van de gezondheid wil men het mishandeling kunnen noemen, en een verplichte behandeling valt ook daaronder. Zekerheidsbewustzijn valt hier aan te denken, men WEET dat het schade oplevert. Oogmerk is ook nog te overwegen, want het schade toebrengen om op die manier gevaar te doen laten wijken is wat men als reden voor de verplichte behandeling opgeeft.

Het tegen de wil behandelen is sowieso mishandeling, maar hier gaat het om de schadelijkheid van de medicijnen die de mishandeling vormen. Tegen de wil behandelen met medicijnen die de gezondheid benadelen lijkt wel dubbelop mishandeling.

Een wet die behandeling met antipsychotica verplicht is een mishandelende wet, het verplicht tot het benadelen van de gezondheid.

Een wet die verplicht tot benadeling van de gezondheid verschaft de opzet in de benadeling en maakt het mishandeling. Mishandeling die niet strafbaar is en daarmee ook niet vervolgbaar door het Openbaar Ministerie maakt dat er aan de mishandeling geen einde te maken is.

Daarom:

* dient U de WvGGZ niet aan te nemen omdat een wet die mishandelt niet te tolereren is.
* dient U voor de mensen die onder de BOPZ mishandelt worden hun mishandeling stop te zetten.
* dient U het Openbaar Ministerie ontvankelijk te maken voor elke  mishandeling die er met deze wetten worden toegebracht.

"Antipsychotica benadelen de gezondheid en u kunt zich niet veroorloven de opzet te zijn van deze benadeling"

Met dank voor uw reactie,


Bart Thate

p.s. deze reactie is ook naar de andere fractie voorzitters gestuurd
