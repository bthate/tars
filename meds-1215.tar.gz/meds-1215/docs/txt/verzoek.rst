.. _verzoek:

VERZOEK
~~~~~~~

From: Bart Thate <bthate@gmail.com>
Date: 2012/10/18
Subject: Re: reactie op de brief van de minister met kenmerk
CZ-3131204 dd. 12 oktober 2012

De Griffier van het Europese Hof voor de
Rechten van de Mens
Raad van Europa
F-67075 Strasbourg Cedex


ik wil klagen over het schenden van mijn recht op leven hier in
Nederland. Lid 2. Ik verzoek u mij het verzoekschrifformulier toe te
zenden zodat ik kan melden over mijn persoonlijke schending van mijn
recht op leven en die van alle andere patienten met een geestelijke
stoornis hier in Nederland.

In short:

90% of the suicide in the Netherlands are committed by humans with a
psychiatric disease. What i am complaining about, and what concerns
the health of all people under treatment here in the Netherlands, is
that the government took a well proven treatement of these people (the
Assertive Communtiy Treatement) and adapted this method to the dutch
situation (Functional Assertive Community Treatement). Comes down that
by introducing this method the risk for suicide is greatly enhanced
due to not providing help when needed. The way the dutch government
treats people with a mental illness, is making the situation of the
patients worse instead of better.

I AM ASKING FOR PROTECTION FROM MY GOVERNMENT AND FROM THOSE WHO ARE
SAYING THAT THEY ARE SUPPOSED TO HELP ME

Ik paste nog even de melding die ik gemeld heb aan politie, openbaar
ministerie, betreffende kamer commissie en de rechtbank waarop dus
NIET gereageerd word.

"It is the not reacting of those that are responsible for giving help
in desperate situations that is what makes the patient commit suicide"

All those i have contacted about this problem have choose to ignore
me, refer me unproperly, give me wrong advice.

A.u.b. kan ik het verzoekschriftformulier invullen en hiervan melding
doen ? Zo vaak zo bang geweest dat ik zelf zelfmoord zou doen en dat
er nog niks van geleerd zo zijn.

Dank

Bart Thate
