.. _weigering:

ZORGVRAAGWEIGERING
~~~~~~~~~~~~~~~~~~

From: Bart Thate <bthate@gmail.com>
Date: 2012/10/14
Subject: reactie op de brief van de minister met kenmerk CZ-3131204
dd. 12 oktober 2012
To: Commissie VWS <cie.vws@tweedekamer.nl>, "Janneke Kramers
(stichting CCAF)" <j.kramers@ccaf.nl>, Hans Kroon <hkroon@trimbos.nl>,
"Info (Rechtbank Alkmaar)" <info.alkmaar@rechtspraak.nl>, "Bahler,
Michiel" <m.bahler@ggz-nhn.nl>, Patricia van Dooyeweerd
<p.vandooyeweerd@heerhugowaard.nl>, klachtencommissiepvp
<klachtencommissiepvp@gmail.com>, NHNLK160
<Postbus@noord-holland.politie.nl>, Roeland Hofstee
<r.hofstee@pvp.nl>, werkgeversservice@ggznederland.nl,
griffier@eerstekamer.nl, info <info@f-actnederland.nl>, Thies Thate
<m.j.thate@tele2.nl>, _dienstpostbus IGZ meldpunt <meldpunt@igz.nl>,
voorzitter@tweedekamer.nl, AP-Alkmaar@om.nl
Cc: Jaap van der Stel <jaapvanderstel@gmail.com>, E-mail NRC Service
<service@nrc.nl>, Geradt Poelman <poelman.geradt@gmail.com>, Jonel
Penders <J.Penders@nationaleombudsman.nl>, K Tielen
<ktielen@gmail.com>, Edith Kuijper <e.v.l.kuijper@gmail.com>,
ooggetuige@nos.nl, _Dienstpostbus IGZ Loket Utrecht <loket@igz.nl>,
Anneke Willems <annekewillems@tele2.nl>


Ik wil u meedelen dat ik dit onderwerp ook te sprake heb kunnen
brengen bij de minister. Mijn brief naar Hare Majesteit is
doorgestuurd naar de minister en is eindelijk dan beantwoord.

Het betreft hier het onderwerp suicide waarover de minister binnenkort
antwoorden zal geven aan de kamer. Ik vraag u om een email adres
waarmee ik officieel met u in dialoog kan gaan. 90% van de suicides
betreft GGZ patienten. 9 op de 10.

"Bedankt voor uw e-mail. Afhankelijk van de aard en inhoud van uw
bericht kunt u binnen twee werkdagen een reactie tegemoet zien. Uw
kenmerk is E1588216 (ontvangst reactie is bevestigd)" Dus over 2 dagen
weet ik meer. Ook zullen volgende week de kamervragen over suicide
door de minister beantwoord worden.

Ik quote hieronder graag even mijn email aan de commissie VWS

quote:

Begrijp ik nu goed dat u na het melden van misstanden in het door u
gecontroleerde systeem, u in een besloten vergadering een standpunt
inneemt als commissie en mij dan niet de overwegingen die leiden tot
uw beslissing kunt overleggen? Dat ik een mededeling krijg van we doen
niks en ik weet niet waarom ?

De zorgweigering die plaatst vind door invoering van het onder uw
toezien ingevoerde - ongeteste - systhematiek in de ambulante
geestelijke gezondheidszorg brengt situaties voort die negatief
werking op de gezondheid van mijn mede GGZ patienten EN mij. Het
risico op suicide word door de invoering van dit systeem vergroot,
omdat de diagnose voor wel of geen hulp nu gesteld word door de  -
huisarts - op de huisartsenpost.

U moet goed snappen en ik zal dit vele malen benadrukken, u spreekt
hier over mensen die in een zeer zeer zeer penibele situatie zitten.
Deze situatie, de omstandigheden waar men in verkeerd, zowel
geestelijk als materieel zijn zodanig dat er een lijden onstaat die
van ongekende proporties is. Deze mensen hebben hulp nodig. Direct,
altijd, omdat zij aangeven het leven niet meer aan te kunnen. Een
zorgweigering in deze situatie verhoogt het risico op suicide. Als dit
risico dus te groot word, is er sprake van daadwerkelijk overlijden
doo een door uw zorg gecontroleerde gecreeerde situatie.

Om een onbekende arts, die de patient niet ziet, via de telefoon, een
diagnose te laten stellen over iemand in deze situatie is
onverantwoord. Vroeger in het oude systeem had je een vaste buddy, die
jou en jij door en door kennen, weten waar je overpraat in de je
tijden van nood die deze diagnose deed. Zijn woord was ook in de
uitvoering van interventies doorslag gevend. Ook dit kan fout gaan,
zoals ik persoonlijk ondervonden heb, maar dan kan er nog een
leerproces opgang komen over hoe en beter kan. Gebeurd nu ook niet,
zelfs na een advies van een klachtencommissie is dit slecht een advies
aan de directie ... niemand controleert wat er met die adviezen
gebeurd.

Ook de dossiers waar de huisarts dan zijn oordeel me moet vellen zijn
niet volledig, suicide risisco's zijn niet aangegeven, zelf na
aanwijzigen van de IGZ dat hier verbetering in gekomen. Worden de
aanwijzingen van de IGZ ook gecontroleerd op uitvoering ?

Ik vraag u nogmaals om dit schrijven te bespreken, op korte termijn
gezien de urgentie, in het open. Zodat ik van alle betreffende
bewindslieden kan vernemen waarom slecht een terkennisnemen voldoet.
Waarom u niet tot actie overgaat NA het terkennisnemen.

Het betreft hier 4 doden per dag commissie, 60 pogingen per dag. Heb
dat allemaal al uit gelegd.

Mischien kan het lot van deze mensen u niet schelen (???) mij gaat het
wel enorm aan.

"Voor al die geweest zijn en voor al die komen gaan"

Kan iemand dit nu WEL serieus nemen ???????????
PLZ
- 3y303d 13h22m
