INSTALL
~~~~~~~

MEDS needs:

* ejabberd
* python3-setuptools
* python3-sphinx

export PYTHONPATH="." if a MEDS rundir is used.

for xmpp client config: 

 cfg xmpp user user@host 

 and add a sleekpass file with xmpp server password to your directory.

to allow certain users permission add a user with it's userhost and perm:

 user bart!~bart@localhost.localdomain REBOOT

