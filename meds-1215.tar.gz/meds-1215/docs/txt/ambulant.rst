########
AMBULANT
########

De ambulante verpleging thuis vereist:

1) 24/7 verpleging bereikbaar
2) periodieke controle van de psychiater 
3) volledig ingevulde behandelovereenkomst

Als de 24/7 verpleging ontbreekt, moet men bellen met een inschatting van risico aan de bellers kant (triade).

Als die geen hulp stuurt moet men zelf reizen wat niet mogelijk is zonder strippenkaart, geld voor taxi
of mantelzorgers aanwezig (zorgvraagweigering).

Wat rest is zonder hulp thuis maar het weekend doorkomen, onder enorme spanning (suicide risico).

Als de psychiater niet een periodieke controle doet, is hij niet op de hoogte van de toestand van de patient.
Dit houd in dat hij paniek voetbal gaat doen op het moment dat de patient onstabiel word (kwakzalverij).

Als de behandelovereenkomst niet goed ingevuld is, gaat met in tijden van crisis ter plekke een beslissing nemen.

Behandelovereenkomst bevat: 

1) behandelplan - dit bevat de verwachting van de te verlenen behandeling. 
2) signaleringsplan - dit bevat de symptomen waar men bij de patient op moet letten
3) crisisplan - dit omschrijft welke partij hoe moet handelen in een crisis situatie

De vertrouwensbreuk is een indicatie van permanente zorgvraagweigering.
Direct en volledig opstellen van de behandelovereenkomst is dan ook meteen nodig.

REGIONAAL TUCHTCOLLEGE VOOR DE GEZONDHEIDSZORG

http://tuchtrecht.overheid.nl/zoeken/resultaat/uitspraak/2014/ECLI_NL_TGZRAMS_2014_94?zaaknummer=2013%2F221&Pagina=1&ItemIndex=1
