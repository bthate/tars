######
CRISIS
######

Per jaar zijn er 150.000 tot 175.000 crisiscontacten

Jaarlijks vinden er circa 150.000 tot 175.000 beoordelingen door de crisisdienst plaats in
Nederland.2

Hierbij vindt de verwijzing in ongeveer 15% van de gevallen plaats door de
politie, in circa 40% van de gevallen door de huisarts of HAP en in de overige 45% van de
gevallen door de overige ketenpartners (SEH, eigen behandelaar en ambulance). In
Nederland wordt ongeveer 10% van de personen in crisis na beoordeling opgenomen in
een ggz-instelling. Een deel van deze opnames is gedwongen. Crisisdiensten geven aan dat
het opnamepercentage sterk verschilt per regio. Ongeveer 85% van de crisiscontacten leidt
tot vervolgconsulten bij de crisisdienst of (eigen) behandelaar. De overige 5% van de
crisiscontacten leidt niet tot vervolgbehandeling in de specialistische ggz. 

