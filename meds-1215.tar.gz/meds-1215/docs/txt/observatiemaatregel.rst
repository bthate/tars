OBSERVATIEMAATREGEL
~~~~~~~~~~~~~~~~~~~

1. De burgemeester kan ten aanzien van een persoon die zich in zijn gemeente bevindt een
observatiemaatregel nemen teneinde betrokkene op te doen nemen in een accommodatie, indien:

a. in voldoende mate van aannemelijkheid kan worden aangenomen dat de betrokkene aan een
   psychische stoornis lijdt,
b. het ernstige vermoeden bestaat dat die stoornis ernstig nadeel doet veroorzaken, en
c. de situatie dermate ernstig is dat de procedure voor een zorgmachtiging niet kan worden
   afgewacht.

2. De observatiemaatregel strekt uitsluitend tot onderzoek naar de aard is van de psychische
   stoornis en of die stoornis ernstig nadeel doet veroorzaken, bedoeld in artikel 3:2, tweede lid,
   onderdeel j.

3. Artikel 7:1, tweede tot en met zesde lid, is van overeenkomstige toepassing. 