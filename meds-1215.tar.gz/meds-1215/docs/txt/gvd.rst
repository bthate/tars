###
GVD
###

GVD - Een slachtoffer goed laten doen met zijn misdadigers is een mishandeling.
