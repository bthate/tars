.. _symptomen:

SYMPTOMEN
=========

negatieve symptomen
~~~~~~~~~~~~~~~~~~~

.. include:: DOPAMINE

vergiftiging
~~~~~~~~~~~~

.. include:: VERGIFTIGING


bijwerking
~~~~~~~~~~

.. include:: BIJWERKING

ontwenning
~~~~~~~~~~

.. include:: ONTWENNING
