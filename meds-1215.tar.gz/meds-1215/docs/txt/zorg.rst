ZORG
~~~~

Zorg kan bestaan uit: 
 
a. een interventie, bestaande uit een vorm van verzorging, bejegening, behandeling, begeleiding of bescherming; 
b. toediening van medicatie, vocht en voeding, regelmatige medische controle of andere medische handelingen; 
c. pedagogische of therapeutische maatregelen;
d. opname in een accommodatie;
e. beperking van de bewegingsvrijheid;
f. afzondering of separatie in een daartoe geschikte verblijfsruimte;  
g. beperking van het recht op het ontvangen van bezoek of het gebruik van communicatiemiddelen; 
h. toezicht op betrokkene;
i. onderzoek aan kleding of lichaam;
j. controle op de aanwezigheid van gedrag beïnvloedende middelen;
k. beperkingen in de vrijheid het eigen leven in te richten, die tot gevolg hebben dat betrokkene iets moet doen of nalaten.
