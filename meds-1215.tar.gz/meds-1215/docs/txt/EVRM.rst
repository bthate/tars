.. raw:: html

   <br>

.. _brief:

EVRM
~~~~


                            Le Greffe
                            Cour Europeenne des Droits de l'Homme
                            Conseil de l'Europe
                            F-67075 STRASBOURG CEDEX.


                                                   8 november 2012


uw kenmerk: 69389/12
mijn kenmerk: 20121108-1


In and about the year 2000, the government of the Netherlands, through the industry of the GGZ, the mental healthcare business, introduced an adapted method of treating people with a serious mental illness, that would be cheaper than the version it was derived from.

The original treatement recognized that for people with such a sickness there is a prerequirement for healing that is called the continuity of care. People who have to deal with "things that are not there", can get it so difficult dealing with that, that they need to have access to someone who can help them with those situations 24 hours a day. This is a necessity. Without this garantuee there is no chance of  recovery from the illness for the patient. Because without this support the situation can get unbearble and people deprive themselves from their lives to escape the hell they are living in.

When schizophrenic people hallucinate they are actually dreaming when being conscious (awake, there in reality) as well. Because one is awake and dreaming at the same time, for us, what we dream is real.

By introduction of the new system in the Netherlands, this 24/7 support is taken away from the patient and replace by a front-end back-end system, where the front-end decides whether the situation of the patient is severe enough to take action. A diagnose of this front-end that further help is not - immediately - necessary, is a death cause for patients with serious mental illnesses. The refusal to even acknowledge that the patient is in dire need, to tell him to wait until monday to get some real help, put this patient in a situation where he has to deal with himself not wanting to be here any more for more than 45 hours.

The terror, horror, fear, panic, dispair of people that can no longer hold it in this life during this period is enormous. Not only because of the  sickness, but mostely due to the knowledge that there will be no help.

It is left alone, we don't care if you die, have a nice weekend !!

This new method (FACT - Functional Assertive Community Treatement) is never tested. The effects of the new elements that were introduced with this method of treatement, were never tested. People in the psychiatric field knew this, the directive for the treatement of schizophrenic people here in the Netherlands says that this treatement should be tested before deployment of it on  a wider scale can happen.

The industry has not listened to this advice. Right now there are 150 teams in the Netherlands that are taking away support for sick people in the weekend. Plans are to grown this number to 500 in the coming years.

This treatement is sold to the government on the promise to reduce the need for hospitalisation of patients here in the Netherlands. After 10 years of using this treatement with out any testing, the first research shows that the treatement does NOT lead to less need for hospitalisation. What is to be expected when the patient is without help the whole weekend. Most suicides happen in the weekend.

The method where it is based on (ACT) is preventive for further hospitalisation and can indeed allow patients like me and some other 250 thousand patients here in the Netherlands learn how to deal with this "dreaming on the day", dealing with hallucinations and who can, with the right support and backup for difficult situations in life, regain a part of their original strength back. I was when I came in this program at 50% of my original skill set. Able to talk, communicate, have connections in this world.
The workings of this method is proven by science, numerous tests have been done that show the effectiveness on it. Because the people who developed it truly looked at what the patients needs. And then try to provide those basic requirements for life.

This proven, working method of treatement is withheld from me and my people.
Right now I am truly alone, none left to help me any more. People always wish me good luck with the struggle I am having to get attention to this problem. In the hell we are living in there is only bad luck. This sickness is like being mentally in a wheelchair, not able to move for ourselves. We are socially handicapped. Nobody wants us, nobody needs us, nobody gives a shit whether we are in this world or not.

I can understand some of this. This hallucination things scares people. It scares me as well !! I don't blame normal people for not knowing how to deal with people like me. It is just too difficult for them to understand, and what one does not understand scares.

But the people who get paid to help me to have - some - of a life, they are just not there when I need them.

The GGZ industry made the cost for this treatement lower from 10 thousand euro a year to 7 thousand. Cheaper for the country and the patient will be socially integrated with it as well !! The magic "we do more with less" thinking.

They withhold me from the proper care I need. My social wheelchair with which I can socially participate instead alone here at home.  Being alone is never good for anybody. Being alone with your - real - imagination is deadly for those who can not hold longer. Being without any living connection in this earth is ...

I want to bring this matter to the European Court for the Human Rights. I want my government to ackowledge the thing i am speaking of here. I also want my country to take - proper - measures to give my people (and me) the care that is needed to take part in life as any other of you do. Especially in the weekend.

We can live, we can have a place in society. But we can only do that if the people that need to help us are there when they are needed.

*Right to live* -  My country withholds me from the care I need to live.

*Torture* - My country lets people with a killer in their head, deal with that, alone at home, for more than 40 hours, before they can get somebody to listen to their problems.

*Denial of proper court of law* - My country has prevented me from bringing this to the Judge.

*Unforgivable* -  My country does not want to learn from things that go worng. They prefer to ignore them.
