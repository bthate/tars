.. _uitspraak:

UITSPRAAK
~~~~~~~~~

.. image:: ../jpg/20140730_011.jpg 