.. _minister:

minister
~~~~~~~~

.. image:: ../jpg/minister.jpg

