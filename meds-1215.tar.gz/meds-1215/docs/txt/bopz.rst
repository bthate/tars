BOPZ
====

.. literalinclude:: Wet-bijzondere-opnemingen-in-psychiatris.txt
    :encoding: "latin-1"