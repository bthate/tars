###
IGZ
###

U schrijft onder andere: “de Inspectie heeft onder de BOPZ allerlei taken om toe te zien op verantwoorde zorg voor de patient. Het zelfde zou moeten gelden voor ambulant behandelde patienten…”.

“Daar heeft u absoluut gelijk in, en dat is ook het geval: de Inspectie ziet toe op alle zorg en behandeling die verleend wordt, binnen de GGZ maar ook in andere vormen van gezondheidszorg; aan patienten die zijn opgenomen maar ook aan patienten die in ambulante behandeling zijn; ongeacht of iemand vrijwillig of krachtens de wet BOPZ wordt behandeld.”

Hoe is de IGZ van plan om onder de WvGGZ de kwaliteit van de behandeling te controleren nu de multidisciplinaire commissie uit de wet geschrapt is ?
