###
WET
###

Wet 1: Noem jezelf geen God als je geen respect hebt voor de schepping.

Wet 2: Ga vanuit onsterfelijkheid niet de sterfelijke mens duiden op zijn sterfelijkheid.

Wet 3: Laat een ieder zoals hij is, want veranderen brengt meer leed dan goed.

Wet 4: Gebruik leed niet om de mens naar God te leiden.

Wet 5: De mens is bedoelt om op de aarde te leven, voor de aarde. Niet voor de Hemel.

Wet 6: Accepteer geen hemel aarde interactie die een hel tot gevolg heeft.

Wet 7: Niet dat van een ander.
