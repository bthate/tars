########
GEMEENTE
########

Budgetoverschot is winst.

1) Te laat komen - 10% , 1 maand
2) Te weinig solliciteren - 10% , 1 maand
3) Huiswerk niet af - 20% , 1 maand
4) Ongewenst gedrag vertoont - 20% , 1 maand
5) Weigering van algemeen geaccepteerde arbeid - 100% , 2 maanden
6) In het geheel niet meewerken - 100% , 2 maanden
7) Verbaal geweld - 50% , 1 maand
8) Bedreiging - 25% , 1 maand
