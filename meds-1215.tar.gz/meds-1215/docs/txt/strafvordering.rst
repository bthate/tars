STRAFVORDERING
==============

.. literalinclude:: Wetboek-van-Strafvordering.txt
    :encoding: "latin-1"