.. _todo:

todo
~~~~

Brief over dat het geen behandeling is maar mishandeling en dus langs de strafrecht moet en niet de medische tuchtrechter.
Met de vraag om strafrechtelijke vervolging ook daadwerkelijk voor de nu behandelde patienten in te stellen.

Brief is aan voorzitters advocatuur en rechter verenigingen om deze vraag te geleiden naar hun leden. 
Dit om nieuwe WvGGZ te voorkomen.

Uitleg over hoe het toedienen van antipsychotica opzettelijke benadeling van de gezondheid is.
