STRAFRECHT
==========

.. literalinclude:: Wetboek-van-Strafrecht.txt
    :encoding: "latin-1"