##########
PREVENTIEF
##########

Maandblad Geestelijke Gezondheid - Jaargang 67 (2012) Nummer 6 - pagina 319-327

"Patiënten die (F)ACT krijgen blijven langer in zorg, maar het aantal 
opnamedagen neemt nauwelijks af. (F)ACT lijkt wel samen te gaan
met minder psychopathologie en beter functioneren, al is oorzakelijkheid
altijd moeilijk aan te tonen. Niet alle (F)ACT-patiënten blijven
voor eeuwig in (F)ACT. De patiëntengroep die het langst in
ACT blijft, is een andere groep met meer problemen dan patiënten
die voor kortere duur ACT krijgen." - Marjan Drukker, Ellen Visser, Hans
Kortrijk, Wijnand Laan, Hugo Smeets & Jim van Os 

(F)ACT verlaagt niet de vraag naar opnames:

1) Wijkteams werken niet met eigen (wijkgerichte) crisis teams. Tussen kantooruren en in de weekenden is er geen personeel wat de patient te woord kan staan.
2) Doordat de nieuwe methode niet op lokaal niveau de 7x24 uurs dienst verzorgt, is er geen preventieve werking wat betreft ziekenhuisopnames.
3) De patienten afhankelijk van deze methode worden niet preventief beschermt tegen ziekenhuis opname.
4) Hierdoor is het risico op suicide groter dan verantwoord en vallen er dus slachtoffers.
5) De wijkteams moeten verplicht wel lokaal 7x24 uurs dienst bieden, anders werkt de preventieve werking op opname niet.
