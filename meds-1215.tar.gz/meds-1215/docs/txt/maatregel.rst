###########
MAATREGELEN
###########

Kunt u maatregelen nemen om ervoor te zorgen dat psychiatrische patiënten met hoge psychische nood ook in het weekend voldoende hulp krijgen?

Antwoord op vraag 4.

Personen die in acute psychische nood verkeren kunnen 24 uur per dag en zeven dagen in de week terecht bij de crisisdienst van een psychiatrische instelling. Voor personen die kampen met acute suïcidale problemen bieden de Stichting Ex6 en de Stichting 113online via de telefoon en via internet anoniem crisiscounseling eveneens met een 24 uur bereikbaarheid. Er wordt dus in voldoende mate voorzien in hulpverlening aan mensen met acute psychische problemen die in het weekend opspelen.
