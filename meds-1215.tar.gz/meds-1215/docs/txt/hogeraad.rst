HOGERAAD
~~~~~~~~

2012/10/22 Info Hoge Raad <info@hogeraad.nl<mailto:info@hogeraad.nl>>
Geachte heer Thate,

Op 20 september 2012 ontvingen wij per mail uw bericht. Helaas kan de Hoge Raad niets voor u doen. De Hoge Raad kan geen advocaten aan- of toewijzen. De advocatuur in Nederland is een zelfstandige organisatie. Met eventuele vragen kunt u zich wenden tot de Nederlandse Orde van Advocaten. Waar het de organisatie van en verantwoordelijkheid voor de GGZ betreft verwijs ik u naar de website van GGZ Nederland. De Hoge Raad heeft geen bemoeienis met de GGZ en heeft ook niet de bevoegdheid om onderzoek te doen naar de door u aangegeven materie. U zou zich nog kunnen wenden tot de minister van Volksgezondheid, Welzijn en Sport of tot de leden van de Tweede Kamer die de gezondheidszorg in hun portefeuille hebben. De Hoge Raad echter kan uw mail alleen voor kennisgeving aannemen.

Hoogachtend,
de griffier van de Hoge Raad der Nederlanden,

Mr. J. Storm




Secretariaat Hoge Raad der Nederlanden
Postbus 20303
2500 EH  DEN HAAG
Telefoon: 070 361 12 68<tel:070%20361%2012%2068>
P Bespaar op papier - Is het noodzakelijk dat U deze email print?
