#########
UITSTROOM
#########

Categorie Uitstroom vanwege:

1) Werk 

 'arbeid in dienstbetrekking' of 'zelfstandig beroep of bedrijf'

2) Scholing

 'gaan volgen onderwijs met studiefinanciering'

3) Andere inkomsten

'uitkering arbeidsongeschiktheid' of 'alimentatie', 'vermogensopbrengsten',
'ander inkomen' of 'uitkering werkloosheid'.

4) Handhaving 

'overschrijden maximale verblijfsduur buitenland', 'geen inlichtingen', 'niet
verschenen op herhaalde oproep inlichtingenplicht', 'niet verschenen op
herhaalde oproep re-integratiegesprek' of 'kunnen volgen van onderwijs
maar dit niet doen'

5) Verloop 

'bereiken van de AOW-gerechtigde leeftijd', 'overlijden', 'detentie',
'verhuizing naar andere gemeente', 'verhuizing naar buitenland' of
'aangaan relatie'.

6) Overig 

'andere oorzaak' of 'oorzaak partner' 