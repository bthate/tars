TWEEDE KAMER
============

Behandeling met antispsychotica is opzettelijke benadeling van de gezondheid gepleegd door toediening van voor het leven of de gezondheid schadelijke stoffen, om met die benadeling van de gezondheid te proberen de psychotische symptomen te verminderen.

kortom:

Antipsychotica brengen schade toe aan de hersenen in de hoop de psychotische symptomen te verminderen. De schade die men toebrengt is opzettelijk en daarmee is het mishandeling.

Een wet die daartoe verplicht en op die manier de mishandeling niet strafbaar maakt, maakt de behandeling nog niet een niet strafbaar feit. Er word nog steeds een strafbaar feit gepleegd, waar men schuldig aan is en wat men direct dient te stoppen. Men kan hoogstens niet strafbaar pleiten, niet het gedogen van het plegen van een strafbaar feit.

Het is de plicht van het Openbaar Ministerie om op te treden als er strafbare feiten worden gepleegd, ook als vervolging tot niet strafbaar leid, met als argument dat het plegen van strafbare feiten gestopt moet worden.

Met het aannemen van de Wet verplichte Geestelijke Gezondheidzorg maakt de Tweede Kamer de behandeling met antipsychotica verplicht en daarmee mishandeling gepleegd door het toedienen van voor het leven en de gezondheid schadelijke stoffen niet strafbaar. 

De Tweede Kamer maakt zich hiermee schuldig aan het op grote schaal mogelijk maken van mishandeling.
