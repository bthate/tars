# meds/cmnds.py
#
#

""" commands scheduler. """

from meds.object import OOL

class Cmnds(OOL): pass

