# meds/runner.py
#
#

""" handle command events. """

from meds.scheduler import Scheduler

class Runner(Scheduler):

   def dispatch(self, event):
        event.parse()
        event.dispatch()
        event.wait()
        event.show()
