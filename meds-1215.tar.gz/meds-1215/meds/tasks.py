# meds/launcher.py
#
#

""" launches threads and provides code to wait for completion.  """

from meds.utils.trace import get_exception, get_strace
from meds.utils.name import sname
from meds.utils.join import j
from meds.object import Object

import threading
import logging
import queue
import time

class Task(threading.Thread):

    def __init__(self, *args, **kwargs):
        """
            Task(threading.Thread)

            A Task is the working unit of the bot. It extends a thread so it can get it's job passed on to it through a queue.

            >>> from meds.launcher import Task
            >>> task = Task
            >>> print(task)
            <class 'meds.tasks.Task'>

        """
        super().__init__(*args, **kwargs)
        self.setDaemon(kwargs.get("daemon", False))
        self._last = time.time()
        self._name = ""
        self._queue = queue.Queue()
        self._ready = threading.Event()
        self._result = ""
        self._starttime = time.time()
        self._status = "start"
        self.args = args
        self.kwargs = kwargs
        self.once = True
        self.type = "Task"

    def __del__(self):
        self._status = ""

    def put(self, func, *args):
        self._queue.put_nowait((func, args))
        return self

    def run(self):
        self._status = "working"
        while self._status:
            _func, args = self._queue.get()
            if not self._status or not _func: break
            self._name = self.name or sname(_func)
            self.setName(self._name)
            self._begin = time.time()
            self._result =  _func(*args)
            self._last = time.time()
            try: args[0].ready()
            except: pass
            if self.once: break
        self.ready()
        return self._result

    def stop(self):
        self._status = ""
        self.put(None, None)

    def isSet(self):
        return self._ready.isSet()

    def ready(self):
        self._ready.set()

    def clear(self):
        self._ready.clear()

    def wait(self, sec=180.0):
        self._ready.wait()

