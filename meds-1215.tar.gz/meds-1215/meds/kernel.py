# meds/kernel.py
#
#

""" central piece of code that loads the plugins and starts services. """


from meds.utils.cli import hello, set_completer, enable_history, termsetup
from meds.utils.misc import include, locked
from meds.utils.trace import get_exception
from meds.utils.name import name, sname, mname
from meds.utils.join import j

from meds.scheduler import Scheduler
from meds.object import Object, OOL
from meds.engine import Engine
from meds.event import Event

from meds import __version__

import meds.core

import importlib
import logging
import pkgutil
import termios
import types
import time
import tty
import sys

class Kernel(Engine):


    def announce(self, txt):
        from meds.core import fleet
        for bot in fleet:
            bot.announce(txt)

    def boot(self):
        """ start boot proces of the kernel. use provided config. """
        from meds.core import cfg
        if cfg.shell: hello(cfg.name, version=__version__, **cfg)
        self._cfg = cfg
        self._resume.fd = sys.stdin.fileno()
        self._resume.old = termsetup(sys.stdin.fileno())
        for name in cfg.packages: self.walk(name)
        self.initialize("meds.run")
        set_completer(sorted(set([cmnd for cmnd in self.list()])))
        enable_history()
        meds.core.cfg.update(cfg)
        self.ready()
        self.start()

    def dispatch(self, event):
        event.dispatch()

    def find(self, cmnd):
        """ find command. """
        for name in meds.core.names.get(cmnd, []):
            if name not in self._table: continue
            mod = self._table[name]
            obj = getattr(mod, cmnd, None)
            if obj and type(obj) == types.FunctionType:
                if "event" in obj.__code__.co_varnames:
                    yield obj

    def initialize(self, name):
        """ initialze package. """
        event = Event()
        thrs = []
        for modname in self.walk(name):
            n = modname.split(".")[-1]
            mod = self._table.get(modname, None)
            if not mod:
                mod = self.load(modname)
            if n in self._cfg.default:
                mod.init(event)
            if self._cfg.all or n in self._cfg.init.split(","):
                if n not in self._cfg.exclude.split(','):
                    logging.info("! init %s" % n)
                    thr = self.launch(mod.init, event, name="%s.initialize" % n)
                    thrs.append(thr)
        event.ready()
        return thrs

    def loading(self, modname, force=False):
        """ load a module. """
        from meds.core import cmnds, names
        if force: mod = self.load(modname)
        else: mod = self.direct(modname)
        for key in dir(mod):
            obj = getattr(mod, key, None)
            if obj and type(obj) == types.FunctionType:
                if "event" in obj.__code__.co_varnames:
                    if key.startswith("cb_"): 
                        k = key.split("cb_")[-1]
                        self._cbs.register(key, obj)
                    else:
                        names.register(key, modname)
                        if key not in ["init", "shutdown"]:
                            cmnds.register(key, obj)

    def list(self, want=""):
        """ list all functions found in a module. """
        for modname in self.modules():
            mod = self.direct(modname)
            for key in dir(mod):
                if key in ["init", "shutdown"]: continue
                if want and key != want: continue
                obj = getattr(mod, key, None)
                if obj and type(obj) == types.FunctionType:
                    if "event" in obj.__code__.co_varnames:
                        yield key

    def resume(self):
        """ resume the kernel. """
        pass

    @locked
    def shutdown(self, close=True):
        """ stop bots, services and plugins. """
        logging.debug("shutdown")
        event = Event()
        thrs = []
        for key, mod in self._table.items():
            if "meds.run" not in key:
                continue
            if "shutdown" in dir(mod):
                thr = self.launch(mod.shutdown, event)
                thrs.append(thr)
        for bot in meds.core.fleet:
            if "stop" in dir(bot):
                thr = self.launch(bot.stop)
                thrs.append(thr)
            if "exit" in dir(bot):
                thr = self.launch(bot.exit)
                thrs.append(thr)
            bot.ready()
        meds.core.launcher.waiter(thrs)
        self.killall()
        self.ready()

    def walk(self, name, force=False):
        """ return all modules in a package. """
        logging.info("! walk %s" % name)
        mods = []
        for modname in sorted(list(self.modules(name))):
            self.loading(modname, force)
            mods.append(modname)
        return mods
