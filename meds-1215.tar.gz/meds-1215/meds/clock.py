# clock.py
#
#

""" timer, repeater and other clock based classes. """

from meds.utils.trace import get_exception
from meds.utils.name import name
from meds.object import Object

import threading
import logging
import time

class Timer(Object):

    def __init__(self, date, func, *args, **kwargs):
        super().__init__()
        self._starttime = time.time()
        self._status = "running"
        self._name = name(func)
        self.sleep = date - time.time()
        self.func = func
        self.args = args
        self.kwargs = kwargs
       
    def start(self):
        self._timer = threading.Timer(self.sleep, self.run)
        self._timer.setDaemon(True)
        self._timer.setName(self._name)
        self._timer._starttime = time.time()
        self._timer._last = time.time()
        self._timer._status = "waiting"
        self._timer.sleep = self.sleep
        self._timer.start()

    def run(self, **kwargs):
        try: self.func(*self.args, **self.kwargs)
        except: logging.error(get_exception())
        self._timer._status = "done"
 
    def exit(self):
        self._status = ""
        self._timer.cancel()

class Repeater(Timer):

    def __init__(self, sleep, func, *args, **kwargs):
        super().__init__(sleep, func, *args, **kwargs)
        self._name = kwargs.get("name", name(func))
        self.sleep = sleep

    def run(self, **kwargs):
        try: self.func(*self.args, **self.kwargs)
        except: logging.error(get_exception()) ; return
        self.start()
