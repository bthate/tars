# meds/launcher.py
#
#

""" launches threads and provides code to wait for completion.  """

from meds.utils.name import naam as thrname
from meds.utils.trace import get_exception
from meds.object import Object
from meds.tasks import Task

import threading
import logging
import queue
import time

class Launcher(Object):

    cc = "!"
    default = ""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._status = "init"
        self.tasks = []
        
    def waiter(self, thrs, timeout=10.0):
        result = []
        for thr in thrs:
            res = thr.join(timeout)
            result.append(res)
        return result

    def launch(self, *args, **kwargs):
        name = kwargs.get("name") or args[0]
        t = Task(**kwargs)
        t.once = True
        t.name = name
        t.start()
        t.put(*args)
        return t

    def killall(self):
        for thr in self.running():
            logging.info("! killed %s" % thrname(thr))
            if "stop" in dir(thr): thr.stop()
            if "exit" in dir(thr): thr.exit()
            if "cancel" in dir(thr): thr.cancel() 

    def kill(self, name):
        thrs = []
        for thr in self.running(name):
            logging.info("! killed %s" % thrname(thr))
            if "exit" in dir(thr): thr.exit()
            if "stop" in dir(thr): thr.stop()
            if "cancel" in dir(thr): thr.cancel() 
            thrs.append(thr)
        return thrs

    def running(self, name=""):
        n = str(name).upper()
        for thr in threading.enumerate():
            thrname = str(thr).upper()
            if thrname.startswith("<_"): continue
            if n not in thrname: continue
            yield thr
