# errors.py
#
#

""" possible exceptions thrown in the code. """

class Error(BaseException):
     """ basic error raised in MEDS. """
     pass

class EBORDER(Error): pass

class EWORKDIR(Error): pass

class ERESUME(Error): pass

class EREBOOT(Error): pass

class EPASSWORD(Error): pass

class ERESERVED(Error): pass

class ELOAD(Error): pass

class EFILENAME(Error): pass

class EISMETHOD(Error):
    """ Attribute is a method. """
    pass

class ENOMETHOD(Error): pass

class ENODATE(Error): pass

class ENOTIME(Error): pass

class ENODIR(Error): pass

class EDISPATCHER(Error): pass

class EATTRIBUTE(Error): pass

class ENOTSET(Error): pass

class ESET(Error):
    """ Attribute is already set. """
    pass

class ESIGNATURE(Error): pass

class ENOTIMPLEMENTED(Error): pass

class ENOJSON(Error): pass

class EJSON(Error): pass

class EDISCONNECT(Error): pass

class ECONNECT(Error): pass

class EFILE(Error): pass

class EARGUMENT(Error): pass

class ETYPE(Error): pass

class EOWNER(Error): pass

class EFUNC(Error): pass

class ENOFUNC(Error): pass

class EREGISTER(Error): pass
