# meds/__init__.py
#
#

""" Die medicijnen zijn gif en het toedienen ervan is stafbaar !!. """

__version__ = 1215
__txt__ = "Opzettelijke benadeling van de gezondheid"

#__txt__ = "Antipsychotica zijn dodelijk en met een behandelplan is het moord."
#__txt__ = "langdurige mishandeling gepleegd door toediening van voor het leven of de gezondheid stoffen."
#__txt__ = "Medicijn, Hoofdpijn. Dood. http://nos.nl/artikel/2122766-politie-onderzoekt-dood-nederlandse-in-duitse-kankerkliniek.html"
#__txt__ = "Het toedienen van giftige medicijnen is strafbaar !!"
