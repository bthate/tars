# udp.py
#
#

""" relay txt through a udp port listener. """

from meds.utils.name import name
from meds.cfg import Config, udp
from meds.object import Object

from meds.core import fleet

import logging
import socket
import time

class UDP(Object):

    """ UDP class to echo txt through the bot, use the meds-udp program to send. """

    def __init__(self):
        super().__init__(self)
        self._cfg = Config(udp)
        self._cfg.load("udp")
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        self._sock.setblocking(1)
        self._status = "start"
        self._starttime = time.time()

    def start(self):
        """ start the UDP server. """
        logging.info("! start udp %s:%s" % (self._cfg.host, self._cfg.port))
        self._sock.bind((self._cfg.host, self._cfg.port))
        self.ready()
        self._status = "ok"
        while self._status:
            (txt, addr) = self._sock.recvfrom(64000)
            if not self._status: break
            data = str(txt.rstrip(), "utf-8")
            if not data: break
            self.output(data, addr)
        logging.info("! stop udp %s:%s" % (self._cfg.host, self._cfg.port))

    def exit(self):
        """ shutdown the UDP server. """
        self._status = ""
        self._sock.settimeout(1.0)
        self._sock.sendto(bytes("bla", "utf-8"), (self._cfg.host, self._cfg.port))

    def output(self, txt, addr=None):
        """ output to all bots on fleet. """
        (passwd, text) = txt.split(" ", 1)
        text = text.replace("\00", "")
        if passwd == self._cfg.password:
            for bot in fleet:
                bot.announce(text)
