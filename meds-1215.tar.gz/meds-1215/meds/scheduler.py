# meds/scheduler.py
#
#

"""
     the schaeduler. 

"""

from meds.utils.trace import get_strace, get_exception
from meds.utils.name import sname, tname, naam
from meds.utils.getters import slice
from meds.object import Object, OOL
from meds.errors import EDISCONNECT
from meds.launcher import Launcher

import importlib
import threading
import pkgutil
import logging
import queue
import types
import time
import sys

class Scheduler(Launcher):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._connected = Object()
        self._queue = queue.Queue()
        self._cbs = OOL()
        self._table = Object()
        self._handlers = OOL()
        self._status = "running"
        self._thrs = []
        thr = self.launch(self.scheduling, name="%s.schedule" % sname(self), daemon=True)
        self._thrs.append(thr)

    def scheduling(self, timeout=None):
        logging.info("! start %s" % sname(self))
        self._connected.wait()
        while self._status:
            event = self._queue.get(timeout=timeout)
            if not event: break
            try: self.handle_event(event)
            except: logging.error(get_exception())
        logging.info("! stop %s" % sname(self))
        self.ready()

    def handle_event(self, event):
        self.dispatch(event)
        self.call_cb(event)

    def dispatch(self, event):
        if event._parsed.cmnd in self._handlers:
            for func in self._handlers[event._parsed.cmnd]:
                func(event)

    def call_cb(self, event): 
        try: cbs = self._cbs[event.origin]
        except KeyError: cbs = []
        for cb in cbs:
            cb(event)

    def direct(self, name, package=None):
        return importlib.import_module(name, package)

    def load(self, modname, force=True):
        logging.debug("! load %s" % modname)
        mod = self.direct(modname)
        if force: self._table[modname] = mod
        return mod

    def modules(self, packagename="", want=""):
        if not packagename: packagename="meds"
        package = self.direct(packagename)
        for pkg in pkgutil.walk_packages(package.__path__, packagename + "."):
            yield pkg[1]

    def prompt(self): pass

    def put(self, event): self._queue.put_nowait(event)

    def register(self, key, value):
        self._handlers.register(key, value)

    def reload(self, name, force=False, event=None):
        from meds.event import Event
        e = event or Event()
        if name not in self._table: self.load(name, True)
        n = name.split(".")[-1]
        if name in self._table and "shutdown" in dir(self._table[name]): self._table[name].shutdown(e) ; e.ready()
        if name not in self._table or force: self.load(name, True)
        else: self._table[name] = importlib.reload(self._table[name])
        if "init" in dir(self._table[name]): self._table[name].init(e) ; e.ready()
        return self._table[name]

    def start(self):
        self._connected.ready()

    def stop(self):
        self._status = ""
        self._queue.put_nowait(None)
