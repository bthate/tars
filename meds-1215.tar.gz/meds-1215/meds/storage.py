# store.py
#
#

""" read files from disk. """

from meds.utils.selector import selector, ignore, wanted, notwanted
from meds.utils.tijd import fn_time
from meds.utils.join import j, sj
from meds.errors import ENODIR
from meds.object import Object
from meds.event import Event

import logging
import os

class Storage(Object):

    def scan(self, path, *args, **kwargs):
        """ scan all files in the cfg.main.workdir directory. """
        p = Event(**kwargs)
        if not path.endswith(os.sep): path += os.sep
        for root, dirs, files in os.walk(path, topdown=True):
            if not os.path.isdir(root): continue
            for fn in files:
                fnn = j(root, fn)
                timed = fn_time(fnn)
                if timed and p.start and timed < p.start: continue
                if timed and p.end and timed > p.end: continue
                yield fnn

    def all(self, *args, **kwargs):
        """ sort all files in the workdir, sort based on timestamp in the filename. """
        from meds.core import kernel
        p = kernl._cfg.workdir
        return sorted(self.scan(p, *args, **kwargs), key=lambda x: fn_time(x))

    def find(self, prefix, *args):
        """ find all objects stored with a prefix subdirectory. """
        for fn in self.prefixed(prefix, *args):
            try: obj = Object().load(fn)
            except: logging.warn("fail %s" % fn) ; continue
            if "deleted" in obj and obj.deleted: continue
            yield obj
            
    def prefixed(self, *args, **kwargs):
        """ return all filename in a workdir subdirectory, the 'prefix'. """
        from meds.core import kernel
        p = kernel._cfg.workdir
        if not os.path.exists(p): os.mkdir(p)
        args = list(args)
        if args and args[0]:
            p = j(p, args[0])
            d = os.path.abspath(p)
            if not os.path.exists(d): return []
        return sorted(self.scan(p, *args, **kwargs), key=lambda x: fn_time(x))

    def selected(self, event):
        """ select objects based on a parsed event. """
        nr = 0
        if not event._parsed.args: return []
        if event._parsed.args: event.prefix = event._parsed.args[0]
        for fn in self.prefixed(event.prefix, **event._parsed):
            try: obj = Object().load(fn)
            except: logging.warn("fail %s" % fn) ; continue
            if not event.nodel and "deleted" in obj and obj.deleted: continue
            if not selector(obj, event._parsed.fields): continue
            if notwanted(obj, event._parsed.notwant): continue
            if not wanted(obj, event._parsed.want): continue
            if ignore(obj, event._parsed.ignore): continue
            nr += 1
            if event._parsed.index and event._parsed.index != nr: continue
            yield obj
        logging.warn("# selected %s" % nr)

    def since(self, start, *args, **kwargs):
        """ return all object since a given time. """
        e = Event(**kwargs)
        e.start = start
        for fn in self.prefixed(*args, **e):
            try: obj = Object().load(fn)
            except: logging.warn("fail %s" % fn) ; continue
            if "deleted" in obj and obj.deleted: continue
            yield obj
 
    def first(self, *args, **kwargs):
        """ return first object matching provided prefix. """
        for fn in self.prefixed(*args, **kwargs):
            try: obj = Object().load(fn)
            except: logging.warn("fail %s" % fn) ; continue
            if "deleted" in obj and obj.deleted: continue
            if len(args) > 1 and obj.get(args[0]) != args[1]: continue
            return obj

    def last(self, *args, **kwargs):
        """ return last record with a matching prefix. """
        e = Event(**kwargs)
        for fn in self.prefixed(*args, **kwargs)[::-1]:
            try: obj = Object().load(fn)
            except: logging.warn("fail %s" % fn) ; continue
            if "deleted" in obj and obj.deleted: continue
            if len(args) > 1 and obj.get(args[0]) != args[1]: continue
            return obj
