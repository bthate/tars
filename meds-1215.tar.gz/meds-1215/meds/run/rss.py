# meds/run/rss.py
#
#

""" runtime code to intialize RSS. """

from meds.core import kernel, launcher, objs, storage
from meds.object import Object
from meds.rss import RSS

import logging

def init(event):
    objs.RSS = RSS()
    objs.RSS.start()

def shutdown(event):
    if "RSS" in objs:
        objs.RSS.stop()
    
def fetcher(event):
    event.reply("fetching")
    if "RSS" not in objs: objs.RSS = RSS()
    objs.RSS.fetcher()

fetcher.threaded = True
