# meds/run/timer.py
#
#

""" start the timer daemon, running all reminders. """

from meds.core import storage, launcher
from meds.event import Event
from meds.clock import Timer

import time

def init(event):
    for fn in storage.prefixed("timer"):
        e = Event().load(fn)
        if e.done: continue
        if "time" not in e: continue
        if time.time() < int(e.time):
            timer = Timer(int(e.time), e.announce, e.txt)
            launcher.launch(timer.start)

def shutdown(event):
    launcher.kill("timer")
