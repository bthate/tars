# meds/run/udp.py
#
#

""" start the udp server, allowing for echoing through udp. """

from meds.core import objs, launcher
from meds.udp import UDP

def init(event):
    objs.UDP = obj = UDP()
    launcher.launch(obj.start)

def shutdown(event):
    udp = objs.get("UDP", None)
    if udp:
        udp.exit()
        launcher.kill("UDP")
