# meds/run/rest.py
#
#

""" start the REST server, providing access to stored objects through a httpd server. """

from meds.utils.trace import get_exception
from meds.rest import REST, RESTHandler
from meds.cfg import rest

from meds.core import kernel, launcher, objs

import logging

def init(event):
    try: objs.REST = obj = REST((rest.hostname, int(kernel._cfg.port or rest.port)), RESTHandler)
    except: logging.error(get_exception()) ; return
    launcher.launch(obj.start)

def shutdown(event):
    rest = objs.get("REST", None)
    if rest: rest.exit()
