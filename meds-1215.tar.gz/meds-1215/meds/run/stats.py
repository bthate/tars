# meds/run/stats.py
#
#

""" code to start the stats plugin, mentioning a suicide statistic. """

from meds.core import kernel, launcher, storage, objs, cfgs
from meds.clock import Repeater

def init(event):
    from meds.plugs.stats import wanted, cijfers, seconds, nr, stats
    for name, obj in wanted.items():
        if name in kernel._cfg.init.split(",") or name in event._parsed.args:
            for key, val in obj.items():
                sec = seconds(val)
                repeater = Repeater(sec, stats, event, name="Stats.%s" % key)
                launcher.launch(repeater.start)

def shutdown(event):
    launcher.kill("Stats")
