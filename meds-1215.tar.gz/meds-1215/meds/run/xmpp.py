# meds/run/xmpp.py
#
#

""" XMPP bot startup script. """

from meds.core import fleet, kernel, launcher, storage, objs
from meds.bots.xmpp import XMPP

import logging
import os

def init(event):
    fn = os.path.expanduser("~/.sleekpass")
    try:
        f = open(fn, "r")
        pw = f.read()
        f.close()
    except:
        logging.error("missing sleekpass file")
        return
    bot = XMPP()
    bot.start(pw)
    objs.XMPP = bot

def shutdown(event):
    for bot in fleet:
        if "XMPP" in str(type(bot)):
           bot.stop()
    launcher.kill("XMPP")
