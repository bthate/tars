# meds/run/irc.py
#
#

""" code run at irc startup. """

from meds.utils.name import sname
from meds.bots.irc import IRC

from meds.core import fleet, launcher, objs, storage

def init(event):
    """ start irc bot. """
    bot = IRC()
    bot.start()
    objs.IRC = bot

def shutdown(event):
    for bot in fleet:
        if "IRC" in str(type(bot)):
           bot.stop()
    launcher.kill("IRC")