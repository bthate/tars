# meds/cfg.py
#
#

"""
    default config objects containing default values for various services and plugins.

"""

from meds.utils.trace import get_strace
from meds.errors import EWORKDIR
from meds.object import Object

import logging
import socket
import time
import ast
import os

class Config(Object):

    def __getattr__(self, name):
        try: return super().__getattr__(name)
        except AttributeError: self[name] = ""
        return self[name]

    def load(self, name):
        from meds.core import storage
        obj = storage.last("cfg", name)
        if obj:
            logging.info("cfg on %s %s" % (name, obj))
            self.update(obj)
        return self

#:
xmpp = Config()
xmpp.prefix = "cfg"
xmpp.user = "meds@localhost"
xmpp.server = "localhost"
xmpp.username = "meds"
xmpp.channel = "#meds"
xmpp.nick = "meds"
xmpp.cfg = "xmpp"
xmpp.port = 5222
xmpp.owner = ""

#:
irc = Config()
irc.cfg = "irc"
irc.channel = "#meds"
irc.nick = "meds"
irc.ipv6 = False
irc.owner = ""
irc.port = 6667
irc.prefix = "cfg"
irc.realname = "meds"
irc.server = "localhost"
irc.username = "meds"

#:
main = Config()
main.path = False
main.prefix = "cfg"
main.colors = False
main.debug = False
main.background = False
main.openfire = False
main.shell = False
main.server = "main@server"
main.init = ""
main.workdir = os.path.expanduser("~/.meds")
main.loglevel = "error"
main.packages = ["meds.bots", "meds.plugs", "meds.cbs"]
main.modules = ""
main.default = ["aliases", "config"]
main.exclude = "test,xmpp"
main.services = False
main.cfg = "main"
main.args = []
main.all = False
main.scan = False
main.resume = False
main.reboot = False
main.verbose = False

#:
udp = Config()
udp.prefix = "cfg"
udp.cfg = "udp"
udp.host = "localhost"
udp.port = 5500
udp.password = "boh"
udp.seed = "blablablablablaz" # needs to be 16 chars wide
udp.server = udp.host

#:
rest = Config()
rest.prefix = "cfg"
rest.cfg = "rest"
rest.hostname = socket.getfqdn()
rest.port = 10102
rest.server = rest.hostname

#:
stats = Config()
stats.prefix = "cfg"
stats.cfg = "stats"
stats.showurl = True

#:
rss = Config()
rss.cfg = "rss"
rss.display_list = ["title", "link", "Date"]
rss.descriptions = ["officiel", ]
rss.sleeptime = 600
rss.ignore = []
rss.dosave = []
rss.nosave = []
rss.showurl = False

#:
cli = Config()
cli.welcome = "mogge!!"
cli.cfg = "cli"
cli.server = "user@cli"
#:
input = Config()
input.server = "input@local"

templates = Object()
templates.xmpp = xmpp
templates.irc = irc
templates.main = main
templates.udp = udp
templates.rest = rest
templates.stats = stats
templates.rss = rss
templates.cli = cli
