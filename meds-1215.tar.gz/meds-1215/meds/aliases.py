# meds/aliases.py
#
#

""" aliases for commands. """

from meds.object import Object

class Aliases(Object):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        try: self.load('aliases')
        except: pass
