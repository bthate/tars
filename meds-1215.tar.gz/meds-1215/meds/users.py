# meds/user.py
#
#

""" Users object to manage bot users permissions. """

from meds.storage import Storage
from meds.object import Object

class User(Object):

    """
        User class to represent a bot user. 

        construct a user with an origin and a list of permissions

        >>> from meds.users import User
        >>> user = User("root@shell", ["REBOOT", "START"])
        >>> print(user)
        {
            "permissions": [
                "REBOOT",
                "START"
            ],
            "prefix": "user",
            "user": "root@shell"
        }
        >>> path = user.sync()

    """

    def __init__(self, origin, permissions=["USER",]):
        self.prefix = "user"
        self.user = origin
        self.permissions = permissions

class Users(Storage):

    """
        Users class to query whether a user has a permission.

        the core module contains an preconstructed users object:

        >>> from meds.core import users
        >>> users.allowed("root@shell", "REBOOT")
        True

    """

    def add(self, origin, permissions=[]):
        """ add a user to the store. """
        u = self.last("user", origin)
        if not u:
            u = User(origin, [x.upper() for x in permissions])
            u.save()
        else:
            u.permissions = [x.upper() for x in permissions]
            u.sync()
        return u

    def allowed(self, origin, perm):
        """ check whether a user has a permission. """ 
        user = self.last("user", origin)
        if user and perm.upper() in user.permissions: return True
        return False

    def fetch(self, origin):
        """ return user data. """
        return self.last("user", origin)

    def set(self, origin, permission):
        """ set a permission of a user. """
        u = self.last("user", origin)
        if u:
           if permission.upper() not in u.permissions:
               u.permissions.append(permission.upper())
           u.sync()
        return u
