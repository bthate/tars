# meds/bots/xmpp.py
#
#

""" module implementing an XMPP bot. """

from meds.utils.trace import get_exception
from meds.utils.misc import stripped
from meds.utils.name import sname
from meds.event import Event
from meds.bots import Bot

from meds.core import cmnds, kernel, launcher

import threading
import logging
import queue
import time
import os

class XMPP(Bot):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        launcher.launch(self._core, name="%s._core" % sname(self))

    def announce(self, txt):
        for channel in self.channels:
            self.say(channel, txt)

    def connected(self, data):
        self._connected.ready()

    def disconnected(self, data):
        self._connected.clear()

    def event(self): return self._queue.get()

    def exception(self, data): self._error = data

    def failedauth(self, data):
        self._error = data

    def failure(self, data):
        self._error = data

    def invalid_cert(self, data):
        self._error = data

    def iqed(self, data):
        logging.warn("# Iq %s:%s" % (self.server, self.port))

    def messaged(self, data):
        logging.debug("< %s" % data)
        m = Event()
        m.btype = sname(self)
        m.update(data)
        if m.type == "error": logging.error("^ %s" % m.error) ; return
        m.cc = ""
        m["from"] = str(m["from"])
        if self._cfg.user in m["from"]:
            logging.debug("! ignore %s %s" % (m.type, m["from"]))
            return
        m.origin = m["from"]
        m.channel = m.origin
        m.to = m.origin
        m.element = "message"
        m.txt = m["body"]
        if '<delay xmlns="urn:xmpp:delay"' in str(data):
            logging.debug("! ignore %s" % m.origin)
            return
        logging.info("< %s %s" % (stripped(m.origin), m.txt))
        self.put(m)

    def out(self, txt):
        self.client.send_raw(txt)

    def pinged(self, event):
        print(event)

    def presenced(self, data):
        logging.debug("< %s" % data)
        o = Event()
        o.update(data)
        o.btype = str(type(self))
        o.origin = o["from"]
        if "txt" not in o: o.txt = ""
        o.element = "presence"
        username = o.origin
        if o.type == 'subscribe':
            pres = Event({'to': o["from"], 'type': 'subscribed'})
            self.client.send_presence(dict(pres))
            pres = Event({'to': o["from"], 'type': 'subscribe'})
            self.client.send_presence(dict(pres))
        elif o.type == "unavailable" and username != self._cfg.jid and username in self.channels:
            self.channels.remove(username)
        elif o.origin != self._cfg.user and username != self._cfg.jid and username not in self.channels:
            self.channels.append(username)
        o.no_dispatch = True
        o.txt = o.type
        logging.info("< %s %s" % (stripped(o.origin), o.type))
        self.put(o)

    def register(self, key, value):
        self.client.add_event_handler(key, value)

    def resume(self): pass

    def say(self, jid, txt):
        txt = str(txt)
        self.client.send_message(jid, txt)
        logging.info("> %s %s" % (stripped(jid), txt))

    def session_start(self, data):
        self.client.send_presence()
        self.ready()

    def start(self, pw):
        thr = launcher.launch(self._connect, pw)
        thr.join()
        super().start()

    def stop(self):
        self.client.disconnect()
        self._queue.put(None)
        super().stop()

    ## helpers

    def _core(self):
        self._connected.wait()
        self.client.process(block=True)

    def _connect(self, pw):
        self._makeclient(self._cfg.user, pw)
        self.client.reconnect_max_attempts = 1
        if kernel._cfg.openfire: self.client.connect((self._cfg.server, self._cfg.port), use_ssl=True, reattempt=True)
        else: self.client.connect(reattempt=False)
        if self._cfg.noresolver: self.client.configure_dns(None)
        self.register_fd(self.client.socket)

    def _makeclient(self, jid, password):
        import sleekxmpp
        self.client = sleekxmpp.clientxmpp.ClientXMPP(jid, password)
        self.register("session_start", self.session_start)
        self.register("message", self.messaged)
        self.register("iq", self.iqed)
        self.register("ssl_invalid_cert", self.invalid_cert)
        self.register('disconnected', self.disconnected)
        self.register('connected', self.connected)
        self.register('presence_available', self.presenced)
        self.register('presence_dnd', self.presenced)
        self.register('presence_xa', self.presenced)
        self.register('presence_chat', self.presenced)
        self.register('presence_away', self.presenced)
        self.register('presence_unavailable', self.presenced)
        self.register('presence_subscribe', self.presenced)
        self.register('presence_subscribed', self.presenced)
        self.register('presence_unsubscribe', self.presenced)
        self.register('presence_unsubscribed', self.presenced)
        self.register('groupchat_message', self.messaged)
        self.register('groupchat_presence', self.presenced)
        self.register('groupchat_subject', self.presenced)
        self.register('failed_auth', self.failedauth)
        self.client.exception = self.exception
        self.client.use_signals()
        self.ready()
