# meds/bots/__init__.py
#
#

"""
    A Bot can connect to a network and communicate with that network.
    Methods are available to join channels and announce text to those channels.

"""

from meds.utils.trace import get_exception
from meds.utils.name import sname

from meds.scheduler import Scheduler
from meds.launcher import Launcher
from meds.log import YELLOW, ENDC
from meds.object import Object
from meds.engine import Engine
from meds.event import Event
from meds.cfg import Config

from meds.core import cfg, fleet, kernel, launcher, storage

import logging
import select
import socket
import sys
import os

class Bot(Engine):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.channels = []
        self._cfg = Config()
        self._cfg.load(sname(self).lower())
        if not self._cfg.server: self._cfg.server = "host"

    def announce(self, txt):
        if self._cfg.silent: return
        if not self.channels:
            self.out(txt)
        for channel in self.channels:
            self.say(channel, txt)

    def cmnd(self, txt):
        event = Event()
        event._server = self._cfg.server
        event.btype = sname(self)
        event.origin = "user@bot"
        event.txt = txt
        self.dispatch(event)
        return event

    def connect(self): pass

    def dispatch(self, event):
        event._server = self._cfg.server
        event.parse()
        event.dispatch()
        event.wait()
        #self.show(event)
        event.show()

    def join(self, channel): pass

    def joinall(self):
        for channel in self.channels:
            self.join(channel)

    def out(self, txt): print(txt)

    def prompt(self):
        if kernel._cfg.colors: txt = "%s>%s " % (YELLOW, ENDC)
        else: txt = "> "
        sys.stdout.write(txt)
        sys.stdout.flush()

    def run_forever(self):
        self.start()
        if not kernel._cfg.shell:
            if kernel._cfg.args:
                self.cmnd(" ".join(kernel._cfg.args))
        else:
            self.prompt()
            self.wait()

    def say(self, channel, txt): self.out(txt)

    def show(self, event):
        for txt in event._result:
            self.say(event.channel, txt)

    def start(self):
        if self not in fleet: fleet.append(self)
        super().start()
