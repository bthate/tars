# meds/bots/test.py
#
#

""" bot to use in tests. """

from meds.utils.name import sname
from meds.object import Object
from meds.event import Event
from meds.bots import Bot

from meds.core import cfg

import unittest
import queue

class Result(Bot):

    """ Bot to use in testing. """

    cc = ""

    def out(self, txt):
        """ raw output function, uses print(). """
        self._result.append(txt)

    def say(self, channel, txt):
        """ output to channel. """
        self.out(txt)
