# meds/bots/input.py
#
#

""" plugin providing a class for a CLI bot. """

from meds.utils.name import sname
from meds.bots.cli import CLI
from meds.event import Event

from meds.core import cfg, cmnds, kernel, storage

import readline
import logging
import select
import tty
import sys
import os

class Input(CLI):

    def dispatch(self, event):
        super().dispatch(event)
        if cfg.shell: self.prompt()

    def event(self):
        e = Event()
        e.server = self._cfg.server
        e.btype = sname(self)
        e.txt = input()
        e.txt = e.txt.rstrip()
        e.origin = "root@shell"
        return e

