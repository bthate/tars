# meds/bots/cli.py
#
#

""" plugin providing a class for a CLI bot. """

from meds.utils.name import sname
from meds.log import YELLOW, ENDC
from meds.event import Event
from meds.bots import Bot

import logging
import termios
import select
import sys
import os

class CLI(Bot):

    def __init__(self, *args, **kwargs):
        super().__init__(self, *args, **kwargs)
        self.register_fd(sys.stdin)
        self.register_fd(sys.stdout)
        self.register_fd(sys.stderr)

    def event(self):
        event = Event()
        event.btype = sname(self)
        event.txt = str(os.read(fd, 512), "utf-8")
        event.txt = event.txt.rstrip()
        event.origin = "root@shell"
        yield event

    def out(self, txt):
        sys.stdout.write(str(txt))
        sys.stdout.write("\n")
        sys.stdout.flush()

    def register_fd(self, f):
        try: fd = f.fileno()
        except: fd = f
        logging.warn("# engine on %s" % str(fd))
        self._poll.register(fd, select.EPOLLIN | select.EPOLLOUT | select.EPOLLET)
        self._resume.fd = fd
        return fd
