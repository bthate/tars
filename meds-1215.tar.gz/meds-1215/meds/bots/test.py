# meds/bots/test.py
#
#

""" bot to use in tests. """

from meds.utils.name import sname
from meds.object import Object
from meds.event import Event
from meds.bots import Bot

import unittest
import queue
import sys

class Test(unittest.TestCase):

    """ custom class for unittests. """

    pass

class TestBot(Bot):

    """ Bot to use in testing. """

    cc = ""

    #def out(self, txt):
    #    """ raw output function, uses print(). """
    #    print(txt)

