# meds/plugs/output.py
#
#

""" commands that output data. """

from meds.utils.name import sname
from meds.core import kernel as _kernel
from meds.core import fleet as _fleet
from meds.core import names

def cmnds(event):
    """ show list of commands. """
    res = sorted(set([cmnd for cmnd, mod in names.items() if "test" not in str(mod)]))
    event.reply(res or "no modules loaded.")

def kernel(event):
    """ show kernel dump. """
    if not event._parsed.rest: res = _kernel
    else: res = _kernel.get(event._parsed.rest, None)
    if res: event.reply(res.nice())

def announce(event):
    """ announce text on all channels in fleet. """
    event.announce(event._parsed.rest)

def fleet(event):
    """ show list of running bots. """
    for bot in _fleet:
        if event._parsed.rest and event._parsed.rest not in sname(bot).lower():
            continue
        event.reply(bot.nice())

def core(event):
    """ show core objects. """
    from meds.core import kernel
    mod = kernel.load("meds.core")
    for name in dir(mod):
       if event._parsed.rest and event._parsed.rest not in name: continue
       obj = getattr(mod, name)
       event.reply("%s %s" % (name, obj))        

def bot(event):
    """ dump bot json. """
    from meds.core import fleet
    for bot in fleet:
        if bot._cfg.server == event._server:
            event.reply(bot)