# meds/plugs/timer.py
#
#

""" timer command to schedule a text to be printed on a given time. stopwatch to measure elapsed time. """

from meds.utils.tijd import to_time, now, elapsed, to_day, day, get_day, get_hour
from meds.errors import ENODATE
from meds.clock import Timer
from meds.event import Event

from meds.core import launcher

import time

start = 0

def timer(event):
    """ echo txt on a given time. """
    if not event._parsed.rest: return
    seconds = 0
    line = ""
    for word in event._parsed.args:
        if word.startswith("+"):
             try: seconds = int(word[1:])
             except: event.reply("%s is not an integer" % seconds) ; return
        else: line += word + " "
    if seconds: target = time.time() + seconds
    else:
        try: target = get_day(event._parsed.rest)
        except ENODATE: target = to_day(day())
        hour =  get_hour(event._parsed.rest)
        if hour: target += hour
    if not target or time.time() > target: event.reply("already passed given time.") ; return
    e = Event()
    e.services = "clock"
    e.prefix = "timer"
    e.txt = event._parsed.rest
    e.time = target
    e.done = False
    e.save()
    timer = Timer(target, e.reply, e.txt)
    launcher.launch(timer.start)
    event.ok(time.ctime(target))

def begin(event):
    """ begin stopwatch. """
    global start
    start = to_time(now())
    if start: event.reply("time is %s" % time.ctime(start))

def end(event):
    """ stop stopwatch. """
    diff = time.time() - start
    if diff: event.reply("time elapsed is %s" % elapsed(diff))
