# meds/plugs/cfg.py
#
#

""" plugin to change config values. """

from meds.cfg import Config, templates

import meds.core

import time
import ast
import os

def edit(event):
    if not meds.core.users.allowed(event.origin, "CONFIG"):
        event.reply("you are not allowed to change the config.")
        return
    obj = meds.core.objs
    args = event._parsed.args
    if not args:
        event.reply("edit <item> <key> <value>")
        return
    name = args[0]
    o = getattr(obj, name, None)
    if not o:
        obj = meds.core.cfgs
        o = getattr(obj, name, None)
        if not o:
            o = Config().load(name)
            if not o:
                template = templates.get(name, None)
                if template:
                    o = Config(template)
            if o:
                obj[name] = o
    if not o:
        event.reply("no %s object available." % name)
        return
    else:
        o = o.get("_cfg", o)
    try:
        key = args[1]
    except IndexError:
        event.reply(o)
        return
    if len(args) < 3:
        event.reply("i need a value to set.")
        return
    if len(args) == 3:
        val = args[2]
    else:
        val = args[2:]
    try:
        o[key] = ast.literal_eval(val)
    except (TypeError, ValueError):
        o[key] = val
    o.sync()
    event.reply(o)
