# meds/plugs/proces.py
#
#

""" start/stop/reload a plugin. """

from meds.utils.cli import reboot as boot
from meds.utils.name import sname
from meds.utils.join import cj
from meds.object import Object
from meds.event import Event

from meds.core import cfg, kernel, fleet, storage, users

import termios
import time
import sys

doreboot = False

def start(event):
    """ start a plugin. """
    user = storage.last("user", event.origin)
    if not user or (user and "START" not in user.permissions):
        event.reply("EPERM START %s" % event.origin)
        return
    if not event._parsed.rest:
        res = [x for x in names.keys() if "run" in x]
        event.reply(sorted(res))
        return
    modname = event._parsed.args[0]
    name = "meds.run.%s" % modname
    kernel.reload(name, force=True, event=event)
    event.ok(name)

def stop(event):
    """ stop a plugin. """
    if not event._parsed.rest:
        event.reply("stop what ?")
        return
    name = "meds.run.%s" % event._parsed.rest
    try: mod = kernel.load(name)
    except ImportError: event.reply("no %s module found." % name) ; return
    mod.shutdown(event)
    event.reply("stopped %s" % name)

def reload(event):
    """ reload a plugin. """
    if not event._parsed.rest:
        event.reply(",".join([x.split(".")[-1] for x in kernel.modules()]))
        return
    user = storage.last("user", event.origin) 
    if not user or (user and "RELOAD" not in user.permissions): 
         event.reply("EPERM RELOAD %s" % event.origin)
         return 
    for modname in kernel.modules():
        if event._parsed.rest not in modname: continue
        try: event.reply(kernel.reload(modname))
        except ImportError as ex: event.reply(str(ex))

