# meds/plugs/entry.py
#
#

""" commands to enter data. """

from meds.object import Object

def tomorrow(event):
    """ show todo items for tomorrow. """
    if not event._parsed.rest:
        event.reply("tomorrow <txt>")
        return
    event.tomorrow = event.txt.replace("tomorrow", "").strip()
    event.prefix = "tomorrow"
    event.save()
    event.ok()

def rss(event):
    if not event._parsed.rest:
        event.reply("rss <url>")
        return
    o = Object(event)
    o.prefix = "rss"
    o.rss = event._parsed.rest
    o.service = "rss"
    path = o.save()  
    event.ok(1)

def todo(event):
    if not event._parsed.rest:
        event.reply("todo <txt>")
        return
    o = Object(event)
    o.prefix = "todo"
    o.todo = event._parsed.rest
    path = o.save()
    event.ok(1)

def shop(event):
    if not event._parsed.rest:
        event.reply("shop <txt>")
        return
    o = Object(event)
    o.prefix = "shop"
    o.shop = event._parsed.rest
    path = o.save()
    event.ok(1)

def log(event):
    if not event._parsed.rest:
        event.reply("log <txt>")
        return
    o = Object(event)
    o.prefix = "log" 
    o.log = event._parsed.rest
    path = o.save()   
    event.ok(1)

def shop(event):
    if not event._parsed.rest:
        event.reply("shop <txt>")
        return
    o = Object(event)
    o.prefix = "shop" 
    o.shop = event._parsed.rest
    path = o.save()   
    event.ok(1)
