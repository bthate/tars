# meds/plugs/mbox.py
#
#

""" read email from an mbox directory or file. """

from meds.utils.trace import get_exception
from meds.utils.tijd import to_date

from meds.object import Object

import logging
import mailbox
import os

def mbox(event):
    if not event._parsed.rest: event.reply("mbox <path>") ; return
    fn = os.path.expanduser(event._parsed.args[0])
    nr = 0
    if os.path.isdir(fn): thing = mailbox.Maildir(fn, create=False)
    elif os.path.isfile(fn): thing = mailbox.mbox(fn, create=False)
    else: event.reply("need a mbox or maildir.") ; return
    for m in thing:
        try:
            o = Object()
            o.update(m.items())
            try: sdate = os.sep.join(to_date(o.Date).split())
            except AttributeError: sdate = None
            o.text = ""
            for load in m.walk():
                if load.get_content_type() == 'text/plain': o.text += load.get_payload()
            o.text = o.text.replace("\\n", "\n")
            o.prefix = "email"
            o.email = o.From
            if sdate: o.save(sdate)
            else: o.save()
            nr += 1
        except: logging.error(get_exception())
    if nr: event.ok(nr)
