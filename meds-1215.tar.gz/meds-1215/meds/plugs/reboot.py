# meds/plugs/reboot.py
#
#

""" reboot the bot. """

from meds.utils.cli import reboot as boot, shutdown
from meds.object import Object
from meds.event import Event

from meds.core import cfg, fleet, kernel, runner, users

import time

def real_reboot(bla):
    """ actual reboot. """
    kernel.shutdown()
    shutdown()
    boot()

def reboot(event):
    """ reboot the bot, allowing statefull reboot (keeping connections alive). """
    if not cfg.reboot:
        event.reply("reboot is not enabled")
        return
    if not users.allowed(event.origin, "REBOOT"):
        event.reply("you don't have reboot permissions.")
        return
    event.announce("rebooting")
    resume = Object()
    resume.kernel = kernel._resume
    resume.fleet = fleet
    resume.save("resume")
    e = Event()
    e._funcs.append(real_reboot)
    print(e)
    kernel.put(e)
