# meds/plugs/tijd.py
#
#

""" show objects entered in the last week. """

from meds.utils.tijd import day, to_day
from meds.core import storage

import time

def week(event):
    """ show last week's logged objects. """
    if not event._parsed.rest:
        event.reply("week <key>")
        return
    event._parsed.start = to_day(day()) - 7 * 24 * 60 * 60
    event._parsed.end = time.time()
    nr = 1
    for obj in storage.selected(event):
        event.display(obj, event._parsed.args, str(nr))
        nr += 1

def today(event):
    """ show objects logged for today. """
    if not event._parsed.rest:
        event.reply("today <key>")
        return
    event._parsed.start = to_day(day())
    event._parsed.end = time.time()
    nr = 1
    for obj in storage.selected(event):
        event.display(obj, event._parsed.args, str(nr))
        nr += 1

def yesterday(event):
    """ show objects added yesterday. """
    if not event._parsed.rest:
        event.reply("yesterday <key>")
        return
    event._parsed.start = to_day(day()) - 24 * 60 * 60
    event._parsed.end = to_day(day())
    nr = 1
    for obj in storage.selected(event):
        event.display(obj, event._parsed.args, str(nr))
        nr += 1
