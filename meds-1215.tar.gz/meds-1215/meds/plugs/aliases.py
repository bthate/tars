# meds/plugs/aliases.py
#
#

"""
    add aliases to the kernel's aliases table. 

    >>> e = bot.cmnd("alias l cmnds")
    ok l

"""

from meds.core import aliases, kernel, storage, users

def alias(event):
    """ key, value aliases. """
    if not users.allowed(event.origin, "ALIAS"):
        event.reply("you don't have ALIAS permission set.")
        return
    try: cmnd, alias = event._parsed.rest.split(" ", 1)
    except ValueError:
        event.reply('alias <cmnd> <aliased>')
        return
    aliases.register(cmnd, alias, force=True)
    aliases.save('aliases')
    event.ok(cmnd)

