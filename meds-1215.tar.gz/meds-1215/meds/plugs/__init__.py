# meds/plugs/__init__.py
#
#

""" plugins with commands to exec. """
