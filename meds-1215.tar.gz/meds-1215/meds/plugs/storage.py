# meds/plugs/storage.py
#
#
from meds.utils.tijd import day, to_day
from meds.errors import ESIGNATURE
from meds.object import Object
from meds.core import storage

import time

def find(event):
    """ present a list of objects based on prompt input. """
    if not event._parsed.rest:
        event.reply("find <prefix>")
        return
    nr = 0
    for obj in storage.selected(event):
        nr += 1
        event.display(obj, event._parsed.args, str(nr))

def rm(event):
    """ set deleted flag on objects. """
    if not event._parsed.index and not event._parsed.want:
        event.reply("rm <key=value> or rm key index=<nr>")
        return
    nr = 0
    for obj in storage.selected(event):
        nr += 1
        obj.deleted = True
        obj.sync()
    event.ok(nr)

def deleted(event):
    """ show deleted records. """
    if not event._parsed.rest:
        event.reply("deleted <prefix>")
        return
    nr = 0
    event.nodel = True
    for obj in storage.selected(event):
       event.display(obj, event._parsed.args, str(nr))
       nr += 1

def dump(event):
    """ dump objects matching the given criteria. """
    if not event._parsed.rest:
        event.reply("dump <prefix>")
        return
    for obj in storage.selected(event):
        event.reply(obj.nice())

def first(event):
    """ show the first record matching the given criteria. """
    if not event._parsed.args:
        event.reply("first <prefix>")
        return 
    obj = storage.first(*event.fields)
    if obj: event.reply(obj.nice())

def last(event):
    """ show last object matching the criteria. """
    if not event._parsed.args:
        event.reply("last <prefix>")
        return 
    obj = storage.last(*event._parsed.args)
    if obj: event.reply(obj.nice())

def restore(event):
    """ set deleted=False in selected records. """
    nr = 0
    event.nodel = True
    for obj in storage.selected(event):
        obj.deleted = False
        obj.sync()
        nr += 1
    event.ok(nr)
