# meds/plugs/cfg.py
#
#

""" plugin to change config values. """

import meds.core
import meds.cfg

import time
import ast
import os

def cfg(event):
    if event._parsed.args:
        ctype = event._parsed.args[0]
        obj = meds.core.storage.last("cfg", ctype.lower())
        if not obj:
            obj = getattr(meds.cfg, ctype, None)
        if not obj:
            obj = meds.cfg.Config()
            obj.prefix = "cfg"
    else:
        event.reply(meds.core.cfg)
        return
    try: 
        key = event._parsed.args[1]
        if ctype == "main" and key == "workdir" or key.startswith("_"):
            event.reply("%s is not editable" % key)
            return
        if len(event._parsed.args) > 3:
            rest = event._parsed.args[2:]
        else:
            rest = event._parsed.args[2]
        if not meds.core.users.allowed(event.origin, "CONFIG"):
            event.reply("you are not allowed to change the config")
            return
        try:
            obj[key] = ast.literal_eval(rest)
        except Exception as ex:
            obj[key] = rest
        if key == "user" and "@" in obj[key]:
            obj["username"], obj["server"] = obj[key].split("@")
        obj.sync()
        meds.core.cfg.update(obj)
        event.reply("%s set to %s" % (key, rest))
    except IndexError: pass
    event.reply(obj)
