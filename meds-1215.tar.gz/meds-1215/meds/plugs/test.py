# meds/plugs/test.py
#
#

""" plugin containing test commands and classes. """

from meds.utils.misc import stripped
from meds.utils.name import name, sname
from meds.errors import ENODATE, EBORDER
from meds.event import Event

from meds.core import cfg, fleet, kernel, storage

import logging
import string
import random
import types
import time

def randomname():
    res = ""
    for x in range(random.randint(3,10)):
        res += random.choice(string.printable)
    return res

def randomarg():
    t = random.choice(types.__all__)
    return types.new_class(t)()
    
def e(event): event.reply(event.nice())

def test(event):
    event.reply("hello %s" % stripped(event.origin))

def flood(event):
    txt = "b" * 5000
    event.reply(txt)

def forced(event):
    for bot in fleet:
        try: bot._sock.shutdown(2)
        except: event.reply("%s bot doesn't have a _sock attribute" % name(bot))

def exception(event):
    user = storage.last("user", event.origin)
    if not user or (user and "EXCEPTION" not in user.permissions):
        event.reply("EPERM EXCEPTION %s" % event.origin)
        return
    raise Exception('test exception')

def wrongxml(event):
    event.reply('sending bork xml')
    for bot in fleet:
        bot.out('<message asdfadf/>')

def unicode(event): event.reply(outtxt)

def deadline(event):
    try: nrseconds = int(event._parsed.rest)
    except: nrseconds = 2
    event.reply('starting %s sec sleep' % nrseconds)
    time.sleep(nrseconds)


def testcfg(event):
    cfg.workdir = event._parsed.rest
    e = Event()
    path = e.save()
    event.reply(path)

def workdir(event):
    event.workdir = "bla.test"
    try: event.save()
    except EBORDER: pass
    event.reply(event._path)

def html(event):
    event.reply('<span style="font-family: fixed; font-size: 10pt"><b>YOOOO BROEDERS</b></span>')

def cmndrun(event):
    cfg.workdir = "test.data"
    for name in sorted(kernel.modules()):
        if name in ["meds.plugs.test", "meds.plugs.rss"]: continue
        mod = kernel.direct(name)
        for n in dir(mod):
           if n in exclude: continue
           func = getattr(mod, n, None)
           if func and type(func) in [types.FunctionType, types.MethodType]:
               if "event" in func.__code__.co_varnames:
                   e = Event()
                   e.btype = event.btype
                   e._funcs.append(func)
                   e.workdir = "test.data"
                   e.origin = "test@bot"
                   kernel.put(e)

def functest(event):
    cfg.workdir = "test.data"
    for name in sorted(kernel.modules()):
        if name in ["meds.plugs.test", "meds.plugs.rss"]: continue
        mod = kernel.direct(name)
        for n in dir(mod):
           if n in exclude: continue
           func = getattr(mod, n, None)
           if func and type(func) in [types.FunctionType, types.MethodType]:
               logging.info(str(func))
               try: func(randomarg())
               except (ENODATE, TypeError, AssertionError, AttributeError) as ex: pass

def testcmnds(event):
    cfg.workdir = "test.data"
    for cmnd in sorted(kernel._handlers.keys()):
        e = Event()
        e.btype = event.btype
        e.txt = "%s %s" % (cmnd, randomname())
        e.origin = "test@bot"
        e.parse()
        event.reply("put %s" % e.txt)
        kernel.put(e)

def runkernel(event):
    cfg.workdir = "test.data"
    if cfg.owner not in event.origin:
        event.reply("EOWNER %s" % event.origin)
        return
    thrs = []
    try: nrloops = int(event._parsed.args[0])
    except: nrloops = 1
    for x in range(nrloops):
        thr = kernel.launch(testcmnds, event)
        thrs.append(thr)
    for thr in thrs: thr.join()

exclude = ["parse_cli", "builtin", "os", "sys", "log", "functest", "hello", "getline", "cmndrun", "fetcher", "testcmnds", "test", "runkernel", "reboot", "real_reboot", "shutdown", "loglevel", "testline", "connect"]
outtxt = u"Đíť ìš éèñ ëņċøďıńğŧęŝţ· .. にほんごがはなせません .. ₀0⁰₁1¹₂2²₃3³₄4⁴₅5⁵₆6⁶₇7⁷₈8⁸₉9⁹ .. ▁▂▃▄▅▆▇▉▇▆▅▄▃▂▁ .. .. uǝʌoqǝʇsɹǝpuo pɐdı ǝɾ ʇpnoɥ ǝɾ"
