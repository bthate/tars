# meds/plugs/silent.py
#
#

""" disable announce per bot.  """

from meds.core import fleet

def silent(event):
    """ put a bot into silent mode. """
    for bot in fleet:
        if event.btype in str(type(bot)):
            bot._cfg.silent = True
            bot._cfg.sync()
            event.reply("silent mode enabled.")

def loud(event):
    """ disable silent mode of a bot. """
    for bot in fleet:
        if event.btype in str(type(bot)):
            bot._cfg.silent = False
            bot._cfg.sync() 
            event.reply("silent mode disabled.")
