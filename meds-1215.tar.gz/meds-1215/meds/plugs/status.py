# meds/plugs/status.py
#
#

""" show runtime information of running threads. """

from meds.utils.name import name, sname, tname, naam
from meds import __version__, __txt__
from meds.utils.tijd import elapsed
from meds.object import Object

from meds.core import kernel, launcher

import time
import os

def uptime(event): event.reply("uptime is %s" % elapsed(time.time() - kernel._starttime))

def version(event): event.reply("MEDS #%s - %s" % (__version__, __txt__))

def whoami(event): event.reply(event.origin)

def pid(event): event.reply(str(os.getpid()))

psformat = "%-17s %-25s %s %s %s"

def ps(event):
    res = []
    nr = 1
    for thr in sorted(launcher.running(), key=lambda x: name(x)):
        obj = Object() 
        obj.update(vars(thr))
        try: obj = obj.__class__.__self__
        except: pass
        if "sleep" in obj: next = int(obj.sleep) - int(time.time() - int(obj._last))
        else: next = 0
        thrname = naam(thr) 
        try: stxt = obj._status.strip()
        except: stxt = "working"
        try: etxt = obj._error.strip()
        except: etxt = ""
        try: uptime = int(time.time()) - int(obj._starttime)
        except: uptime = int(time.time() - kernel._starttime)
        txt = psformat % (elapsed(next), thrname, stxt, elapsed(uptime), etxt)
        res.append((next, txt))
    for next, txt in sorted(res, key=lambda x: x[0], reverse=True):
        event.reply("%-5s %s" % (nr, txt))
        nr += 1
    if nr == 1: event.reply("no tasks running.")
