# meds/plugs/meet.py
#
#

""" command to edit permissions of a user. """

from meds.core import storage, users

def meet(event):
    """ create an user record. """
    if not users.allowed(event.origin, "OPER"):
        event.reply("you don't have MEET permission.")
        return
    try: origin, *permissions = event._parsed.rest.split()
    except: event.reply("meet <origin> [<perm1> <perm2>]") ; return
    user = users.add(origin, permissions)
    event.reply("user %s created" % origin)

def permission(event):
    """ add/change permissions of an user. """
    if not users.allowed(event.origin, "OPER"):
        event.reply("you don't have MEET permission.")
        return
    try: origin, permission = event._parsed.args
    except: event.reply("perm <userhost> <perm>") ; return
    user = users.set(origin, permission)
    if not user:
        event.reply("can't find a user matching %s" % origin)
        return
    event.reply(user)

def user(event):
    """ show user data. """
    event.reply(users.fetch(event._parsed.rest))

def w(event):
    """ show user data. """
    event.reply(users.fetch(event.origin))
    