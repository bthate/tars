# meds/core.py
#
#

""" objects stash, a central place to store objects. """

from meds.object import Object, OOL
from meds.launcher import Launcher
from meds.aliases import Aliases
from meds.storage import Storage
from meds.runner import Runner
from meds.kernel import Kernel
from meds.users import Users
from meds.cmnds import Cmnds
from meds.cfg import Config, main

#:
cfg = Config(main)
#:
aliases = Aliases()
#:
cmnds = Cmnds()
#:
fleet = []
#:
kernel = Kernel()
#:
launcher = Launcher()
#:
names = OOL()
#:
runner = Runner()
#:
storage = Storage()
#:
users = Users()
#:
cfgs = Config()
#:
objs = Object()
objs.cfg = cfg
objs.aliases = aliases
objs.cmnds = cmnds
objs.fleet = fleet
objs.kernel = kernel
objs.launcher = launcher
objs.names = names
objs.runner = runner
objs.storage = storage
objs.users = users
