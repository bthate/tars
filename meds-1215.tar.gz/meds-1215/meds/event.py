# meds/event.py
#
#

""" object representing an event, uses a string as the default value and is able to be parsed for commands. """

from meds.utils.tijd import to_day, get_day, to_time
from meds.utils.trace import get_exception
from meds.errors import ENOTSET, ENODATE
from meds.utils.misc import stripped
from meds.utils.getters import days
from meds.object import Object, OOL
from meds.utils.join import sj, j

import logging
import types
import time
import os

class Parsed(Object):

    def __getattr__(self, name):
        if name == "cmnd": self.cmnd = ""
        if name == "switch": self.switch = Object()
        if name == "want": self.want = Object()
        if name == "ignore": self.ignore = OOL()
        if name == "notwant": self.notwant = Object()
        if name == "args": self.args = []
        if name == "rest": self.rest = ""
        if name == "fields": self.fields = []
        if name == "words": self.words = []
        if name == "index": self.index = 0
        if name not in self: raise AttributeError(name)
        return self[name]

class Event(Object):

    def __getattr__(self, name):
        if name == "_parsed": self._parsed = Parsed() 
        try: return super().__getattr__(name)
        except AttributeError: self[name] = ""
        return self[name]                

    def announce(self, txt):
        """ announce on all available channels on all available bots. """
        from meds.core import fleet
        for bot in fleet:
            bot.out(txt)

    def dispatch(self):
        """ execute all functione registered in self._funcs list. """
        from meds.core import launcher
        for func in self._funcs:
            logging.info("! exec %s %s" % (stripped(self.origin), str(func)))
            thr = launcher.launch(func, self)
            self._thrs.append(thr)
        self.ready()

    def display(self, obj=None, keys=[], txt=""):
        """ display the content of an object. """
        res = ""
        if not obj: obj = self
        if not keys: keys = obj.keys()
        for key in keys:
            val = getattr(obj, key, None)
            if val: res += " " + str(val)
        try: d = days(obj)
        except ENODATE: pass
        if d: res += " - %s" % d
        if txt: res = "%s %s" % (txt, res)
        self.reply(res)

    def done(self): self.reply("done")

    def join(self, *args, **kwargs):
        """ join threads started while handling this event. """
        for thr in self._thrs:
            thr.join(*args, **kwargs)

    def ok(self, txt=""):
        """ reply with 'ok'. """
        self.reply("ok %s" % txt)

    def parse(self, txt=""):
        """ parse provided text or available self.txt and determine cmnd, args, rest and other values. Adds a _parsed object to the event. """
        from meds.core import aliases, cmnds, cfg, names
        if txt: self.txt = txt.rstrip()
        if self.txt.endswith("&"): self.threaded = True ; self.txt = self.txt[:-1]
        splitted = self.txt.split()
        quoted = False
        key2 = ""
        counter = -1
        parsed = Parsed()
        for word in splitted:
            counter += 1
            if counter == 0:
                if "cc" in self and self.cc:
                    if self.cc != word[0]: continue
                    else: word = word[1:]
                alias = aliases.get(word, None)
                if alias: word = alias
                cmnd = word.lower().strip()
                if cmnd:
                    parsed.cmnd = cmnd
                    funcs = cmnds.get(cmnd, None)
                    if not funcs:
                        modnames = names.get(cmnd, [])
                        for modname in modnames:
                            self.load(modname)
                if funcs:
                    self._funcs.extend(funcs)
                    self._funcs = list(set(self._funcs))
                continue
            try: key, value = word.split("=", 1) 
            except (IndexError,ValueError):
                key = ""
                value = word 
            if value.startswith('"'):
                if value.endswith('"'):
                    value = value[1:-1]
                    parsed.words.append(value)
                else:
                    key2 = key
                    value = value[1:]
                    parsed.words.append(value)
                    quoted = True
                    continue
            if quoted:
                if value.endswith('"'):
                    key = key2
                    parsed.words.append(value[:-1])
                    value = sj(*parsed.words)
                    self._parsed.words = []
                    quoted = False
                else:
                    parsed.words.append(value)
                    continue
            if quoted:
                parsed.words.append(value)
                continue
            if counter == 1:
                if word.count("[") == 1:
                    value, index = word.split("[")
                    try: parsed.index = int(index[:-1])
                    except ValueError: pass
                if not self.prefix:
                    if key and os.path.isdir(j(cfg.workdir, key)):
                        self.prefix = key
                    elif os.path.isdir(j(cfg.workdir, value)):
                        self.prefix = value
            if "http" in value:
                parsed.args.append(value)
                parsed.rest += " " + value
                continue
            if key=="index":
                parsed.index = int(value)
                continue
            if key == "start":
                parsed.start = to_time(value)
                continue 
            if key == "end":
                parsed.end = to_time(value)
                continue 
            if value.startswith("+") or value.startswith("-"):
                try: parsed.time_diff = int(value[1:])
                except ValueError: parsed.time_diff = 0
            if value.endswith("++") or value.endswith("--"):
                try: parsed.karma = value[:-2]
                except ValueError: pass
            if key and value:
                pre = key[0]
                op = key[-1]
                post = value[0]
                last = value[-1]
                if key.startswith("!"):
                     key = key[1:]
                     parsed.switch[key] = value
                     continue
                if post == "-":
                     value = value[1:]
                     parsed.ignore.register(key, value)
                     continue
                if op == "-":
                     key = key[:-1]
                     parsed.notwant[key] = value
                     continue
                if last == "-":
                    value = value[:-1]
                parsed.want[key] = value 
                if last == "-" :
                     continue
                if counter > 1: parsed.fields.append(key)
                parsed.args.append(key)
                parsed.rest += " " + key
            else:
                if counter > 1: parsed.fields.append(value)
                parsed.args.append(value)
                parsed.rest += " " + str(value)
        self._parsed.update(parsed)
        self._parsed.rest = self._parsed.rest.strip()
        return parsed

    def reply(self, txt):
        """ give a reply to the origin of this event. """
        if type(txt) in [list, tuple]: txt = ",".join([str(x) for x in txt])
        self.say(self.channel, txt)

    def say(self, channel, txt):
        """ say something on a channel, using the bots available in the fleet. """
        self._result.append(txt)

    def show(self):
        from meds.core import fleet
        for txt in self._result:
            if self.outer:
                self.outer.write(str(txt) + "\n")
                self.outer.flush()
                continue
            for bot in fleet:
                if bot._cfg.server == self._server:
                    bot.say(self.channel, txt)

    def wait(self):
        super().wait()
        for thr in self._thrs:
            thr.join()
