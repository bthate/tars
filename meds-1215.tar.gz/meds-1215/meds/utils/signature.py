# meds/utils/signature.py
#
#

""" signature related functions. """

import hashlib
import json

def signature(obj): return str(hashlib.sha1(bytes(str(obj), "utf-8")).hexdigest())

def make_signature(obj):
    data = json.dumps(obj, indent=4, ensure_ascii=True, sort_keys=True)
    return str(hashlib.sha1(bytes(str(data), "utf-8")).hexdigest())

def verify_signature(obj, signature):
    signature2 = make_signature(obj)
    return signature2 == signature
