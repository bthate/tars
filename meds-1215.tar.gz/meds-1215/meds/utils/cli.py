
# meds/utils/cli.py
#
#

""" function concerning the command line options of the bot. """

from meds.utils.file import touch
from meds import __version__
from meds.cfg import Config

import rlcompleter
import threading
import optparse
import readline
import termios
import logging
import atexit
import sys
import os

histfile = os.path.expanduser("~/.history")

def getline(prompt="> "):
    import termios, sys
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    new = termios.tcgetattr(fd)
    #new[3] = new[3] & ~termios.ECHO          # lflags
    try:
        termios.tcsetattr(fd, termios.TCSADRAIN, new)
        line = input(prompt)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    return line

def termsetup(fd):
    old = termios.tcgetattr(fd)
    #new = termios.tcgetattr(fd)
    #new[3] = new[3] & ~termios.ECHO          # lflags
    #termios.tcsetattr(fd, termios.TCSADRAIN, new)
    return old

def termreset(fd, old):
    termios.tcsetattr(fd, termios.TCSADRAIN, old)

class Completer(rlcompleter.Completer):

    def __init__(self, options):
        super().__init__()
        self.options = options
 
    def complete(self, text, state):
        if state == 0:
            if text: self.matches = [s for s in self.options if s and s.startswith(text)]
            else: self.matches = self.options[:]
        try:
            return self.matches[state]
        except IndexError:
            return None

def set_completer(optionlist):
    completer = Completer(optionlist)
    readline.set_completer(completer.complete)
    atexit.register(lambda: readline.set_completer(None))

def enable_history():
    logging.info("! enabling history")
    readline.parse_and_bind("tab: complete")
    if not os.path.exists(histfile): touch(histfile)
    readline.read_history_file(histfile)
    atexit.register(close_history)

def close_history():
    readline.write_history_file(histfile)

def shutdown():
    close_history()
    from meds.core import kernel
    termreset(kernel._resume.fd, kernel._resume.old)

def stop(name=""):
    logging.warn("# stopping")
    for thr in threading.enumerate():
        if str(thr).startswith("<_"): continue
        if name and name not in str(thr): continue
        if "stop" in dir(thr): thr.stop()
        elif "exit" in dir(thr): thr.exit()
        elif "cancel" in dir(thr): thr.cancel()
        else: thr.join(0.1)

def hello(descr, **kwargs):
    from meds import __version__, __txt__
    from meds.log import YELLOW, GREEN, BOLD, ENDC
    version = kwargs.get("version", __version__)
    colors = kwargs.get("colors", "")
    try:
        if colors: print("%s%s%s #%s%s - %s%s%s\n" % (BOLD, YELLOW, descr, version, ENDC, GREEN, __txt__, ENDC))
        else: print("%s #%s - %s\n" % (descr, version, __txt__))
    except Exception as ex: print(ex) ; print('try setting PYTHONIOENCODING="utf-8" before starting this program.')
    
def make_opts(options):
    parser = optparse.OptionParser(usage='usage: %prog [options]', version=str(__version__))
    for option in options:
        type, default, dest, help = option[2:]
        if "store" in type:
            try: parser.add_option(option[0], option[1], action=type, default=default, dest=dest, help=help)
            except Exception as ex: logging.error("^ Opts/error %s option %s" % (str(ex), option)) ; continue
        else:
            try: parser.add_option(option[0], option[1], type=type, default=default, dest=dest, help=help)
            except Exception as ex: logging.error("^ Opts/error %s option %s" % (str(ex), option)) ; continue
    args = parser.parse_args()
    return args

def parse_cli(name="MEDS", version=__version__, eggs=False, workdir=""):
    from meds.log import loglevel
    from meds.cfg import main
    import meds.core
    opts, args = make_opts(opts_defs)
    cfg = Config(main)
    cfg.name = name
    cfg.args = args
    cfg.update(vars(opts))
    loglevel(cfg.loglevel, colors=cfg.colors)
    if not cfg.workdir: cfg.workdir = os.path.expanduser(workdir or "~/.meds")
    if cfg.scan or eggs:
        for fn in os.listdir(os.getcwd()):
            if fn.endswith(".egg") and fn not in sys.path:
                logging.warn("# load %s" % fn.split()[-1])
                sys.path.insert(0, os.path.abspath(fn))
    meds.core.cfg.update(cfg)
    return cfg

def list_eggs(filter="meds"):
    for f in sys.path:
        if ".egg" not in f: continue
        if filter and filter not in f: continue
        yield f

def show_eggs(filter="meds"):
    path = list(list_eggs(filter))[0]

def reboot():
    from meds.core import cfg
    print("reboot")
    os.execl(sys.argv[0], *(sys.argv + ["-r"]))

opts_defs = [
              ('', '--debug', 'store_true', False, 'debug', "enable debug mode."),
              ('', '--path', 'store_true', False, 'path', "show syspath"),
              ('', '--scan', 'store_true', False, 'scan', "scan working directory for eggs"),
              ('-a', '--all', 'store_true', False, 'all', "load all plugins."),
              ('-b', '--background', 'store_true', False, 'background', "switch to background mode."),
              ('-c', '--colors', 'store_true', False, 'colors', "turn on color mode"),
              ('-d', '--workdir', 'string',  "", 'workdir', "working directory."),
              ('-e', '--onerror', 'store_true', False, 'onerror', "raise on error"),
              ('-i', '--init', 'string', "", 'init', "whether to initialize plugins."),
              ('-l', '--loglevel', 'string', "error", 'loglevel', "loglevel."),
              ('-m', '--modules', 'string', "", 'modules', "list of modules to use."),
              ('-n', '--nowait', 'store_false', True, 'nowait', 'use blocking mode'),
              ('-o', '--owner', 'string', "", 'owner', "userhost/JID of the bot owner"),
              ('', '--openfire', 'store_true', False, 'openfire', 'use openfire to connect to XMPP.'),
              ('-p', '--port', 'string', "10102", 'port', "port to run HTTP server on."),
              ('-r', '--resume', 'store_true', False, 'resume', "resume on restart."),
              ('-s', '--shell', 'store_true', False, 'shell', "enable shell mode."),
              ('-v', '--verbose', 'store_true', False, 'verbose', 'use verbose mode.'),
              ('-x', '--exclude', 'string', "test", 'exclude', "modules to exclude"),
              ('-z', '--reboot', 'store_true', False, 'reboot', "enable rebooting."),
              ('', '--skip', "string", "", "skip", "list of items to skip.")
          ]

opts_defs_sed = [
              ('-d', '--dir', 'string', "", 'dir_sed', "directory to work with."),
              ('-l', '--loglevel', 'string', "error", 'loglevel', "loglevel"),
          ]  

opts_defs_udp = [
              ('-p', '--port', 'string', "10102", 'port', "port to run API server on"),
              ('-l', '--loglevel', 'string', "error", 'loglevel', "loglevel"),
          ]

opts_defs_doctest = [
              ('-e', '--onerror', 'store_true', False, 'onerror', "raise on error"),
              ('-v', '--verbose', 'store_true', False, 'verbose', "use verbose"),
              ('-l', '--loglevel', 'string', "error", 'loglevel', "loglevel"),
          ]

