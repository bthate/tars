# meds/utils/selector.py
#
#

""" functions used in code to select what objects to use. """

from meds.errors import ENOTSET

def selector(obj, keys):
    if not keys: return True
    go = False
    for key in keys:
        try: attr = getattr(obj, key)
        except (AttributeError, ENOTSET): attr = None
        if attr: go = True
        else: go = False ; break
    return go

def wanted(obj, want):
    if not want: return True
    if list(want.keys()) == ["start"]: return True
    if list(want.keys()) == ["start", "end"]: return True
    go = False
    for key, value in want.items():
        if not value: continue
        if value.startswith("-"): continue
        if key in ["start", "end"]: continue
        if key in obj and value and value in str(obj[key]): go = True
        else: go = False ; break
    return go

def notwanted(obj, notwant):
    if not notwant: return False
    
    for key, value in notwant.items():
        try: value = obj[key] ; return True
        except: pass
    return False

def ignore(obj, ignore):
    if not ignore: return False
    for key, values in ignore.items():
        value = getattr(obj, key, [])
        for val in values:
            if val in value: return True
    return False
