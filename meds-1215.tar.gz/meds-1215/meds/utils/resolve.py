# meds/utils/resolve.py
#
#

""" plugin containing resolver functions. """

import socket
import random

def resolve_ip(hostname=None, timeout=1.0):
    oldtimeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try: ip = socket.gethostbyname(hostname or socket.gethostname())
    except socket.timeout: ip = None
    socket.setdefaulttimeout(oldtimeout)
    return ip

def resolve_host(ip=None, timeout=1.0):
    oldtimeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try: host = socket.gethostbyaddr(ip or resolve_ip())[0]
    except socket.timeout: host = None
    socket.setdefaulttimeout(oldtimeout)
    return host

def bind(server):
    if not server:
        try: socket.inet_pton(socket.AF_INET6, server)
        except socket.error: pass
    if not server:
        try: socket.inet_pton(socket.AF_INET, server)
        except socket.error: pass
    if not server:
        ips = []
        server = random.choice(ips)
        try:
            for item in socket.getaddrinfo(server, None):
                if item[0] in [socket.AF_INET, socket.AF_INET6] and item[1] == socket.SOCK_STREAM:
                    ip = item[4][0]
                    if ip not in ips: ips.append(ip)
        except socket.error: pass
    return server
