# meds/utils/type.py
#
#

""" module containing type related functions. """

import types

def isfunc(obj): return type(obj) in [types.FunctionType, ]

def isobj(obj): return type(obj) not in [types.FunctionType, types.MethodType, types.ModuleType]

def iscmnd(obj):
    if isfunc(obj): return "event" in obj.__code__.co_varnames
