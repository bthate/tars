# meds/utils/trace.py
#
#

""" functions concering stack trace. """

import traceback
import sys
import os

def get_exception(txt=""):
    exctype, excvalue, tb = sys.exc_info()
    trace = traceback.extract_tb(tb)
    result = ""
    for i in trace:
        fname = i[0]
        linenr = i[1]
        func = i[2]
        plugfile = fname[:-3].split(os.sep)
        mod = []
        for i in plugfile[::-1]:
            mod.append(i)  
            if i == "meds": break
        ownname = '.'.join(mod[::-1])
        result += "%s:%s %s | " % (ownname, linenr, func)
    del trace
    return "%s%s: %s %s" % (result, exctype, excvalue, txt)

def get_frame(search="code"):
    result = {}
    frame = sys._getframe(1)
    search = str(search)
    for i in dir(frame):
        if search in i:
            target = getattr(frame, i)
            for j in dir(target):
                result[j] = getattr(target, j)
    return result

def get_strace(depth=1):
    result = ""
    loopframe = sys._getframe(depth)
    if not loopframe: return result
    while 1:
        try: frame = loopframe.f_back
        except AttributeError: break
        if not frame: break
        linenr = frame.f_lineno
        fn = frame.f_code.co_filename
        func = frame.f_code.co_name
        result += "%s %s:%s | " % (fn, func, linenr)
        loopframe = frame
    del loopframe
    return result[:-3]

