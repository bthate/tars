# meds/utils/name.py
#
#

""" name related functions, strip object names to be easily representable. """

def name(obj):
    txt = repr(obj)[1:-1]
    if " at " in txt: txt = txt.split(" at ")[0]
    if "," in txt: txt = txt.split(",")[0] 
    if " from " in txt: return txt.split(" from ")[0].split()[1][1:-1]
    if " of " in txt: txt = txt.split(" of ")[0] 
    txt = txt.replace("<function ", "")
    txt = txt.replace("<bound method ", "")
    txt = txt.replace("bound method ", "")
    return txt

def sname(obj): return tname(obj).split(".")[-1]

def tname(obj): return name(obj).split("(")[-1]

def mname(obj): return name(obj)

def naam(obj): return name(obj) + ")"
