# meds/utils/getters.py
#
#

""" functions that can be used on objects. """

from meds.utils.tijd import to_date, to_time, elapsed, fn_time, rtime
from meds.utils.file import check_permissions
from meds.errors import ENODATE
from meds.utils.join import j

import time
import os

dirmask = 0o700
filemask = 0o600

def fnn(obj):
    fn = obj.f_code.co_filename
    return fn.split(os.sep)[-1][:-3]

def urled(obj):
    from meds.core import cfg
    from meds.cfg import rest
    if "_path" in obj: fn = os.sep.join(obj._path.split(os.sep)[-2:])
    else: fn = ""
    return "http://%s:%s/%s" % (rest.hostname, cfg.port, fn)

def root(obj):
    from meds.core import kernel
    path = kernel._cfg.workdir
    path = os.path.abspath(path)
    check_permissions(path)
    return path

def path(obj):
    if "workdir" in obj: p = obj.workdir
    else: p = root(obj)
    if "prefix" in obj: p = j(p, obj.prefix)
    return os.path.abspath(p) 

def days(obj):
    t1 = time.time()
    try: t2 = timed(obj)
    except ENODATE: t2 = None
    if t2:
        time_diff = float(t1 - t2)
        return elapsed(time_diff)

def dated(obj):
    res = getattr(obj, "Date", None)
    if not res: res = getattr(obj, "date", None)
    if not res: res = getattr(obj, "published", None)
    if not res: res = getattr(obj, "added", None)
    if not res: res = getattr(obj, "saved", None)
    if not res: res = getattr(obj, "timed", None)
    if not res:
        res = getattr(obj, "_state", None)
        if res: res = getattr(res, "saved", None)
    if not res: raise ENODATE
    return res

def timed(obj):
    t = to_date(dated(obj))
    if t: t = to_time(t)
    if not t and "_path" in obj: t = fn_time(obj._path)
    if not t: t = fn_time(rtime())
    return t

def look(obj, name):
    l = []
    for key in obj.keys():
        if name in key: l.append(key)
    return l

def match(obj, txt):
    for key in obj.keys():
        if txt not in key: continue
        return obj[key]

def matching(obj, keys):
    for key in keys:
        if not getattr(obj, key, None): return False
    return True

def slice(obj, keys=[]):
    from meds.object import Object
    o = Object()
    if not obj: return o
    if not keys: keys = obj.keys()
    for key in keys:
        if key.startswith("_"): continue
        try: val = obj[key]
        except KeyError: continue
        try: val.keys() ; o[key] = slice(val)
        except: o[key] = val
    return o
