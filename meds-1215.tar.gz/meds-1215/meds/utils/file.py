# meds/utils/file.py
#
#

""" file related functions. """

from meds.utils.trace import get_exception

import logging
import stat
import os

dirmask = 0o700
filemask = 0o600

def touch(fname):
    try: fd = os.open(fname, os.O_RDONLY | os.O_CREAT) ; os.close(fd)
    except TypeError: pass
    except Exception as ex: logging.error(get_exception())

def check_permissions(ddir, dirmask=dirmask, filemask=filemask):
    uid = os.getuid()
    gid = os.getgid()
    try: stats = os.stat(ddir)
    except OSError: cdir(ddir) ; stats = os.stat(ddir)
    if stats.st_uid != uid: os.chown(ddir, uid, gid)
    if os.path.isfile(ddir): mask = filemask
    else: mask = dirmask
    m = oct(stat.S_IMODE(stats.st_mode))
    if m != oct(mask): os.chmod(ddir, mask)

def cdir(path):
    res = "" 
    for p in path.split(os.sep):
        res += "%s%s" % (p, os.sep)
        padje = os.path.abspath(os.path.normpath(res))
        if os.path.isdir(padje): continue
        try: os.mkdir(padje)
        except FileExistsError: pass
        except OSError as ex: logging.error(get_exception())
    return True

def high(target, file_name):
    highest = 0
    for i in os.listdir(target):
        if file_name in i:
            try: seqnr = i.split('.')[-1]
            except IndexError: continue  
            try:
                if int(seqnr) > highest: highest = int(seqnr)
            except ValueError: pass
    return highest

def highest(target, filename):
    nr = high(target, filename)
    return "%s.%s" % (filename, nr+1)
