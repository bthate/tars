# meds/utils/misc.py
#
#

""" misc. helper functions. """

import _thread
import re
import os

def exclude(name):
    from meds.core import cfg
    n = name.split(".")[-1]
    if not cfg.main.all:
        if n in cfg.main.exclude.split(","): return True
        if n not in cfg.main.init.split(","): return True
    else:
        if n in cfg.main.exclude.split(","): return True
    return False

def include(name):
    from meds.core import cfg
    n = name.split(".")[-1]
    if n in cfg.main.exclude: return False
    return True

def fnn(obj):
    fn = obj.f_code.co_filename
    return fn.split(os.sep)[-1][:-3]

def fields(main):
    for obj in main.values():
        for key in obj: yield key

def matching(keys, value):
    for key in keys:
        if key in value: return True
    return False

def get_source(mod, package="."):
    import pkg_resources as p
    source = os.path.abspath(p.resource_filename(mod, package))
    return source

def copyright(): return "© Copyright 2016 Bart Thate"

def locked(func, *args, **kwargs):

    lock = _thread.allocate_lock()

    def lockedfunc(*args, **kwargs):
        lock.acquire()
        res = None
        try: res = func(*args, **kwargs)
        finally:
            try: lock.release()
            except: pass
        return res
    return lockedfunc

def split_txt(what, l=450):
    z = ""
    for txt in what.split("\n"):
        if len(txt) < l: yield txt
        else:
            for y in txt.split():
                if len(y) + len(z) < l:
                    z += " " + y
                    continue
                yield z.strip()
                z = ""
    if z: yield z.strip()
         
def stripped(input):
    try: return str(input).split("/")[0]
    except: return str(input)

def feed(text):
    from meds.object import Object
    result = []
    chunks = text.split("\r\n")
    for chunk in chunks:
        obj = Object().feed(chunk)
        result.append(obj)
    return result

def run_sed(filename, sedstring):
    f = open(filename, 'r')
    tmp = filename + '.tmp'
    fout = open(tmp, 'w')
    if sedstring:
        char = "#"
        seds = sedstring.split(char)
        fr = seds[1]
        to = seds[2]
        for line in f:
            l = re.sub(fr, to, line)
            fout.write(l)
    else:
        for line in f:
            l = re.sub("\t", "    ", line.rstrip() + "\n")
            fout.write(l)
    fout.flush()
    fout.close()
    os.rename(tmp, filename)

headertxt = '''# this is an MEDS file, %s
#
# the bot can edit this file !!

'''

reliq = """
for i in range(int(len(input)/16)):
txt = input[i*16:i*16+16]
try: data += crypt.decrypt(txt)
except Exception as ex: logging.error(get_exception()) ;  break
"""
