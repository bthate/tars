# meds/utils/json.py
#
#

""" functions used to dump json. """

from meds.utils.name import name

import string
import json

def smooth(a):
    if type(a) not in basic_types: return repr(a)
    else: return a

def dumps(obj, *args, **kwargs):
    kwargs["sort_keys"] = True
    return json.dumps(obj, default=smooth, *args, **kwargs)

basic_types = [str, int, float, bool, None]
allowedchars = string.ascii_letters + string.digits + "_,-. \n" + string.punctuation
allowednamechars = string.ascii_letters + string.digits + '!.@'
