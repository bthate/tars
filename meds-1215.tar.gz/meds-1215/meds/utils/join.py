# meds/utils/join.py
#
#

"""
    string concat functions, join strings together. 

    use j to use os.path.join

    >>> from meds.utils.join import j, mj, cj, sj, dj

    >>> l = ["a","b", "c"]
    >>> j(*l)
    'a/b/c'

    use mj to join with a dot

    >>> mj(*l)
    'a.b.c'

    use cj to join with a comma

    >>> cj(*l)
    'a,b,c'

    sj is to join with a space

    >>> sj(*l)
    'a b c'   

    dj works to join with a underscore

    >>> dj(*l)
    'a_b_c'

"""

import os.path
import os

def j(*args):
    if not args: return
    todo = list(map(str, filter(None, args)))
    return os.path.join(*todo)

def mj(*args):
    if not args: return
    todo = list(map(str, filter(None, args)))
    return os.path.join(*todo).replace(os.sep, ".")

def cj(*args):
    if not args: return
    todo = list(map(str, filter(None, args)))
    return os.path.join(*todo).replace(os.sep, ",")

def sj(*args):
    if not args: return
    todo = list(map(str, filter(None, args)))
    return os.path.join(*todo).replace(os.sep, " ")

def dj(*args):
    if not args: return
    todo = list(map(str, filter(None, args)))
    return os.path.join(*todo).replace(os.sep, "_")

