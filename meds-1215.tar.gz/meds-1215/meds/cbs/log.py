# meds/plugs/log.py
#
#

""" log text entered in a channel. """

from meds.utils.tijd import parse_time, get_hour
from meds.core import storage
from meds.event import Event

def cb_log(event):
    """ save event. """
    event.prefix = "cblog"
    event.nick = event.origin.split('!')[0]
    event.save()

def re(event):
    try: t = parse_time(event._parsed.rest)
    except ValueError: t = None
    if not t: event.reply("since when ?") ; return
    for obj in storage.since("cblog", t):
        e = Event(obj)
        event.reply("%s %s %s" % (e.created.split()[3], e.nick or e.origin, e.txt))
