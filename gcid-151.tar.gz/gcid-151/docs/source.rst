.. _source:

.. raw:: html

     <br><br>


.. title:: Source


**GCID**

.. raw:: html

     <br>


.. autosummary::
    :toctree: 
    :template: module.rst

    gcid.clients	patients
    gcid.clocked	timer/repeater
    gcid.command	commands
    gcid.decoder	json decoder
    gcid.default	default return values
    gcid.encoder	json encoder
    gcid.handler	event handler
    gcid.listens	list of listeners
    gcid.message	messages
    gcid.modules	plugins
    gcid.objects	objects
    gcid.scanner 	scan modules 
    gcid.storage	storing json objects
    gcid.threads	threads
    gcid.utility	utilities


.. raw:: html

     <br>


**GCID.MODULES**


.. raw:: html

     <br>


.. autosummary::
    :toctree: 
    :template: module.rst

    gcid.modules.cmd		commands list
    gcid.modules.irc		internet relay chat
    gcid.modules.mdl		genocide model
    gcid.modules.req		request
    gcid.modules.rss		rich site syndicate
    gcid.modules.tdo		things todo
    gcid.modules.upt		uptime
