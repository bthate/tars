.. _guilty:

.. raw:: html

     <br><br>

.. title:: Guilty

.. _informed:


**informed**


.. raw:: html

  <br>

.. image:: informed.jpg
    :width: 100%

.. raw:: html

    <br><br>

.. _chamber:

**chamber**

.. raw:: html

  <br>

.. image:: kamer.png


.. raw:: html

    <br><br>

.. _king:


**king**


.. raw:: html

  <br>

.. image:: bevestigd.jpg

.. raw:: html

  <br><br>

