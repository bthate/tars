# This file is placed in the Public Domain.


"uptime"


import time


from gcid.utility import elapsed


def __dir__():
    return (
            'upt',
           )


__all__ = __dir__()


starttime = time.time()

def upt(event):
    event.reply(elapsed(time.time()-starttime))
