# This file is placed in the Public Domain.


"json with object decoding/encoding"


import datetime
import json
import os
import types
import uuid
import _thread


from functools import wraps


from .objects import Object
from .utility import locked

def __dir__():
    return (
            'ObjectDecoder',
            'ObjectEncoder',
            'dump',
            'dumps',
            'load',
            'loads',
            
            )


__all__ = __dir__()


olock = _thread.allocate_lock()


class ObjectDecoder(json.JSONDecoder):


    def decode(self, s, _w=None):
        value = json.loads(s)
        return Object(value)


class ObjectEncoder(json.JSONEncoder):


    def default(self, o):
        if isinstance(o, dict):
            return o.items()
        if isinstance(o, Object):
            return vars(o)
        if isinstance(o, list):
            return iter(o)
        if isinstance(o,
                      (type(str), type(True), type(False),
                       type(int), type(float))
                     ):
            return str(o)
        try:
            return json.JSONEncoder.default(self, o)
        except TypeError:
            return str(o)


def dump(
         obj,
         fnm,
         *args,
         skipkeys=False,
         ensure_ascii=True,
         check_circular=True,
         allow_nan=True,
         cls=None,
         indent=None,
         separators=None,
         default=None,
         sort_keys=False,
         **kw
        ):
    return json.dump(
                     obj,
                     fnm,
                     *args,
                     skipkeys=skipkeys,
                     ensure_ascii=ensure_ascii,
                     check_circular=check_circular,
                     allow_nan=allow_nan,
                     cls=ObjectEncoder,
                     indent=indent,
                     separators=separators,
                     default=default,
                     sort_keys=sort_keys,
                     **kw
                    )



def dumps(
          obj,
          *args,
          skipkeys=False,
          ensure_ascii=True,
          check_circular=True,
          allow_nan=True,
          cls=None,
          indent=None,
          separators=None,
          default=None,
          sort_keys=False,
          **kw
         ):
    return json.dumps(
                      obj,
                      *args,
                      skipkeys=skipkeys,
                      ensure_ascii=ensure_ascii,
                      check_circular=check_circular,
                      allow_nan=allow_nan,
                      cls=cls or ObjectEncoder,
                      indent=indent,
                      separators=separators,
                      default=default,
                      sort_keys=sort_keys,
                      **kw
                     )

def load(
         fnm,
         *args,
         cls=None,
         object_hook=None,
         parse_float=None,
         parse_int=None,
         parse_constant=None,
         object_pairs_hook=None,
         **kw
        ):
    return json.load(
                     fnm,
                     *args,
                     cls=ObjectDecoder,
                     parse_float=parse_float,
                     parse_int=parse_int,
                     parse_constant=parse_constant,
                     object_pairs_hook=object_pairs_hook,
                     **kw
                    )


def loads(s, *args, cls=None, object_hook=None, parse_float=None, parse_int=None, parse_constant=None, object_pairs_hook=None, **kw):
    return json.loads(
                      s,
                      *args,
                      cls=ObjectDecoder,
                      parse_float=parse_float,
                      parse_int=parse_int,
                      parse_constant=parse_constant,
                      object_pairs_hook=object_pairs_hook,
                      **kw
                     )

