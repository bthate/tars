.. _source:

.. raw:: html

    <br><br>

.. title:: source


**genocide package**

.. raw:: html

    <br>

.. autosummary::
    :toctree: 
    :template: module.rst

    genocide.hdl		handler
    genocide.irc		internet relay chat
    genocide.fnd		find
    genocide.log		log
    genocide.mdl		model
    genocide.mbx		mailbox
    genocide.obj		object
    genocide.req		request
    genocide.rss		rich site syndicate
    genocide.slg		slogan
    genocide.tdo		todo
    genocide.tmr		timer
