.. _{{ fullname }}:

.. raw:: html

    <br>
    <center><b>
    <br><br>
    </b>

.. title:: {{ fullname }}

{{ fullname }}
{{ underline }}

.. raw:: html

    </b></center>
    <br>

.. auto{{ objtype }}:: {{ fullname }}
    :members:
    :private-members:
    :undoc-members:

.. raw:: html

    <br><br>
