.. _request:


.. raw:: html

    <br><br>


.. title:: Request


| **Information and Evidence Unit**
| **Office of the Prosecutor**
| **Post Office Box 19519**
| **2500 CM The Hague**
| **The Netherlands**
|

Dear Mister Mark P. Dillon,

i received your writing to not to proceed with my request OTP-CR-117/19 on 20-05-2019.

i write you to ask you to reconsider now removed evidence has been restored online again.

In chronological order:

11-12-2017 I informed the chamber of the fact that the medicine used in treatements of psychiatric illnesses are poison. The proof exists of a url to the European Chemical Agency, showing that Haldol is a toxic substance (toxic if swallowed accompanied by a skull en bones). This link worked a the time the chamber member were informed.

23-01-2018 The Chamber votes in favour of the Wet Forensische Zorg, Wet verplichte GGZ, Wet Zorg en Dwang knowing that the medicine used in these treatements are poison.

05-10-2018 I inform the King of the fact that these medicine are poison

01-01-2019 The Wet Forensische Zorg is activated

10-01-2019 I inform local authorities of the informednes of both the chamber member and the king.

21-01-2019 I inform the Office of the Prosecutor with proof that these medicine are poison and proof of the informedness of the King and the chamber members.

23-01-2019 I withdraw the request to arrest king and chamber member from the local authorities. They didn't react at all.

06-02-2019 The information on the ECHA website about Haldol being a poison is removed and a "nothing wrong with it" version is added

25-02-2019 After consideration i decided to formaly ask the king and chamber members to be prosecuted.

27-02-2019 I noticed that the site was updated and informed the Office of the Prosecutor about it.

20-05-2019 The Prosecutor informs me of his decision to not to proceed, mentioning the he could reconsider if new evidence arises.

25-06-2019 I talk to members of ECHA on twitter and got the link to the proof restored.


Knowing that the proof that Haldol is a poison was offline when you reached your conclusion to not to proceed, could you reconsider your conclusion now this proof is back online again ?
