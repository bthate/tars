# This file is placed in the Public Domain.
# pylint: disable=C,I,R,W


"""Killing, torturing, castrating, destroying, in whole or in part, all elderly
and all handicapped, all criminals and all psychiatric patients in the
Netherlands"""


__author__ = "B.H.J. Thate <thatebhj@gmail.com>"
__version__ = 1

TXT = "@IntlCrimCourt @KarimKhanQC @oszagi reconsider OTP-CR-117/19."
URL = "http://genocide.rtfd.io"
URL2 = "http://pypi.org/project/genocide"


def slg(event):
    event.reply(__doc__ + "\n\n" + TXT + "\n\n" + URL2)
