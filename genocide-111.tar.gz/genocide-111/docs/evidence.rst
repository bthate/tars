.. _evidence:

.. title:: Evidence

.. _haldol:

.. raw:: html

  <br>

**haldol**


.. raw:: html

  <br>

.. image:: ECHAhaldol.png
    :width: 100%

.. raw:: html

  <br><br>

.. _clozapine:


**clozapine**


.. raw:: html

  <br>


.. image:: ECHAclozapine.png
    :width: 100%


.. raw:: html

  <br><br>

.. _zyprexa:


**zyprexa**


.. raw:: html

  <br>

.. image:: ECHAzyprexa.png
    :width: 100%

.. raw:: html

  <br><br>

.. _abilify:


**abilify**


.. raw:: html

  <br>

.. image:: ECHAabilify.png
     :width: 100%

