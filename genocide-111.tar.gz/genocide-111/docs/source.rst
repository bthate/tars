.. _source:

.. raw:: html

     <br><br>

.. title:: Source


**genocide**


.. raw:: html

     <br>


.. autosummary::
    :toctree: 
    :template: module.rst

    genocide.clocked	timer/repeater
    genocide.handler	event handler
    genocide.loggers 	logging
    genocide.modules	plugins
    genocide.objects	objects
    genocide.persist	storage
    genocide.runtime	configuration
    genocide.scanner	scan modules
    genocide.threads	threading
    genocide.utility	utils


.. raw:: html

     <br>


**genocide.modules**


.. raw:: html

     <br>


.. autosummary::
    :toctree: 
    :template: module.rst

    genocide.modules.cmd	commands list
    genocide.modules.err	errors
    genocide.modules.flt	list of bots
    genocide.modules.fnd	locate objects
    genocide.modules.irc	internet relay chat
    genocide.modules.log	log text
    genocide.modules.mdl	genocide model
    genocide.modules.req	request
    genocide.modules.rss	rich site syndicate
    genocide.modules.tdo	things todo
    genocide.modules.sts	status
    genocide.modules.thr	list of running threads
    genocide.modules.upt	uptime
    genocide.modules.usr	users
