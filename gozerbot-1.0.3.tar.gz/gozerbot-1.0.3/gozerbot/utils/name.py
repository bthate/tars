# gozerbot/utils/name.py
#
#

""" name related helper functions. """

__status__ = "seen"

## basic imports

import string
import os

## defines

allowednamechars = string.ascii_letters + string.digits + '!.@-'

## functions

def stripname(txt):
    res = ""
    for c in txt:
        if c in allowednamechars: res += c
    res.replace(os.sep, '-')
    return res

#### BHJTW 22-01-2012
