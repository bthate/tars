# gozerbot package
#
#

""" gozerbot core package. """

__status__ = "seen"

__version__ = "1.0.3"

__all__ = ['aliases', 'database', 'ignore', 'periodical', 'tests', \
           'botbase',  'datadir', 'persist', 'threads', \
           'cache', 'eventbase', 'irc', 'plughelp', 'users', \
           'callbacks', 'eventhandler', 'jabber', 'plugins', 'utils', \
           'channels', 'examples', 'jsonusers', 'plugs', 'wait', \
           'commands', 'exit', 'less', 'redispatcher', \
           'compat', 'fleet', 'monitor', 'rest', \
           'config', 'morphs', 'runner', 'wave', \
           'contrib', 'gozerimport', 'partyline', 'stats', 'utils', 'reboot', 'xmpp']

## gozerbot imports

from eggs import loadegg

## basic imports

import os

## initialisation

loadegg('simplejson', [os.getcwd(), os.getcwd() + os.sep + 'gozernest'], log=False)
loadegg('sqlalchemy', [os.getcwd(), os.getcwd() + os.sep + 'gozernest'], log=False)
