# gozerbot/datadir.py
# -*- coding: utf-8 -*-
#

""" the datadir of the bot. """

__status__ = "ok"

## basic imports

import re
import os

## makedirs function

def makedirs(ddir=None):

    """ make subdirs in datadir. users, db, fleet, pgp, plugs and old. """
    ddir = ddir or datadir
    curdir = os.getcwd()
    if not os.path.isdir(ddir): os.mkdir(ddir)
    if not os.path.isdir(ddir + '/run/'): os.mkdir(ddir + '/run/')
    if not os.path.isdir(ddir + '/users/'): os.mkdir(ddir + '/users/')
    if not os.path.isdir(ddir + '/db/'): os.mkdir(ddir + '/db/')
    if not os.path.isdir(ddir + '/fleet/'): os.mkdir(ddir + '/fleet/')
    if not os.path.isdir(ddir + '/pgp/'): os.mkdir(ddir + '/pgp/')
    if not os.path.isdir(ddir + '/plugs/'): os.mkdir(ddir + '/plugs/')
    if not os.path.isdir(ddir + '/old/'): os.mkdir(ddir + '/old/')

## defines

datadir = 'gozerdata'
