# gozerbot/admin.py
#
#

""" gozerbot admin related funtions. """

__status__ = "ok"

## basic imports

from simplejson import loads

## table definitions

try: cmndtable = loads(open('gozerdata' + os.sep + 'run' + os.sep + 'cmndtable').read())
except: cmndtable = {}

try: pluginlist = loads(open('gozerdata' + os.sep + 'run' + os.sep + 'pluginlist').read())
except: pluginlist = []

