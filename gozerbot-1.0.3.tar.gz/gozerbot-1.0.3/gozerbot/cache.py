# gozerbot.cache
#
#

""" attempt to make a global usercache. not used yet. """

__status__ = "ok"

## global userhost cache

userhosts = {}
