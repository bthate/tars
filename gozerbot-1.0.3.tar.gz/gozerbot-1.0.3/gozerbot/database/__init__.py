from gozerbot.eggs import loadegg
loadegg('sqlalchemy', log=False)
