# plugs/code.py
#
#

""" code related commands. """

__status__ = "seen"

## gozerbot imports

from gozerbot.redispatcher import rebefore, reafter
from gozerbot.commands import cmnds
from gozerbot.examples import examples
from gozerbot.utils.exception import exceptionlist
from gozerbot.plugins import plugins
from gozerbot.aliases import aliasset
from gozerbot.plughelp import plughelp
from gozerbot.tests import tests

## plughelp

plughelp.add('code', 'the code plugin provides code related commands')

## code-exceptions command

def handle_showexceptions(bot, ievent):
    """ no arguments - show exception list. """
    try: printto = ievent.args[0]
    except IndexError: printto = ievent.channel
    cp = list(exceptionlist)
    for exception in cp: bot.say(printto, exception, groupchat=False)
    if not exceptionlist: ievent.reply('no exceptions yet !')

cmnds.add('code-exceptions' , handle_showexceptions, 'OPER')
examples.add('code-exceptions', 'show exception list', '1) code-exceptions 2) code-exceptions bthate@dds.nl')
aliasset('exceptions', 'code-exceptions')
tests.add('code-exceptions')

## code-funcnames command

def handle_funcnames(bot, ievent):
    """ no arguments - show function names of a plugin. """
    try: plugname = ievent.args[0]
    except IndexError: ievent.missing('<plugname>') ; return
    if not plugins.exist(plugname): ievent.reply('no %s plugin exists' % plugname) ; return
    funcnames = []
    funcnames = rebefore.getfuncnames(plugname)
    funcnames += cmnds.getfuncnames(plugname)
    funcnames += reafter.getfuncnames(plugname)
    if funcnames: ievent.reply(funcnames, dot=True)
    else: ievent.reply("can't find funcnames for %s plugin" % plugname)
        
cmnds.add('code-funcnames', handle_funcnames, 'OPER')
examples.add('code-funcnames', 'show function names of a plugin', 'code-funcnames birthday')
aliasset('funcnames', 'code-funcnames')
tests.add('code-funcnames core', 'handle_version')
