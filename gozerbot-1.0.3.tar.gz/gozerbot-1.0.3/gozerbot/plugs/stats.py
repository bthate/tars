# gozerbot/plugs/stats.py
#
#

""" show the bots stats. """

## gozerbot imports

from gozerbot.commands import cmnds
from gozerbot.examples import examples
from gozerbot.stats import stats
from gozerbot.tests import tests

## stats command

def handle_stats(bot, ievent):
    """ show stats of the bot. """
    if not ievent.rest: ievent.missing('[%s]' % '|'.join(stats.all())) ; return
    item = ievent.rest
    result = stats.get(item)
    if result: ievent.reply('stats of %s ==> ' % item, dict(result))

cmnds.add('stats', handle_stats, 'OPER')
examples.add('stats', 'show stats of the bot', '1) stats 2) stats callbacks')

#### BHJTW 21-01-2012
