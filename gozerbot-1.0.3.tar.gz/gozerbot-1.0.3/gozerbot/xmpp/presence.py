# gozerbot/xmpp/presence.py
#
#

""" XMPP Presence class. """

## gozerbot imports

from gozerbot.eventbase import EventBase
from gozerbot.utils.trace import whichmodule
from gozerbot.utils.log import rlog
from core import XMLDict

## basic imports

import time
 
## Presence class

class Presence(EventBase):

    def __init__(self, nodedict={}, bot=None):
        rlog(2, whichmodule(1), 'PRESENCE: ' + str(nodedict))
        EventBase.__init__(self, nodedict, bot)
        self.element = 'presence'

    def toirc(self):
        """ set ircevent compatible attributes """
        self.cmnd = 'Presence'
        try: self.nick = self.fromm.split('/')[1]
        except (AttributeError, IndexError): self.nick = ""
        self.jid = self.jid or self.fromm
        self.ruserhost = self.jid
        self.userhost = str(self.jid)
        self.resource = self.nick
        self.stripped = self.jid.split('/')[0]
        self.channel = self.fromm.split('/')[0]
        self.printto = self.channel
        self.origtxt = self.txt
        self.time = time.time()
        if self.type == 'groupchat': self.groupchat = True
        else: self.groupchat = False
        if self.txt: makeargrest(self)

#### BHJTW 22-01-2012
