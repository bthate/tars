# gozerbot/xmpp/monitor.py
#
#

""" monitors .. call callback on bot output. """

__status__ = "seen"

## gozerbot imports

from gozerbot.utils.exception import handle_exception
from gozerbot.monitor import Monitor
from gozerbot.config import config
from gozerbot.eventbase import EventBase
from message import Message

## XMPPmonitor class

class XMPPmonitor(Monitor):

    """ monitor jabber output """

    def handle(self, bot, event):
        """ fire jabber monitor callbacks. """
        try:
            e = Message()
            e.copyin(event)
            e.isreply = True
            e.iscmnd = True
            e.remotecmnd = True
            e.remoteout = bot.jid
            e.channel = event.to
            e.fromm = e['from'] = bot.jid
            e.nick = bot.nick
            e.botoutput = True
            Monitor.handle(self, bot, e)
        except AttributeError: handle_exception()

## defines

xmppmonitor = XMPPmonitor('xmppmonitor')

#### BHJTW 22-01-2012
