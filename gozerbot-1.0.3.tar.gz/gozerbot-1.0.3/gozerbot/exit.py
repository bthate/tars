# gozerbot/exit.py
#
#

""" gozerbot's finaliser """

__status__ = "ok"

## gozerbot imports

from utils.log import rlog
from utils.trace import whichmodule
from eventhandler import mainhandler
from plugins import plugins
from fleet import fleet
from persist.persist import saving
from runner import runners_stop
from gozerbot.config import config

## basic imports

import atexit
import os
import time
import sys

## globalshutdown function

def globalshutdown():
    """ shutdown the bot. """
    rlog(10, 'GOZERBOT', 'SHUTTING DOWN')
    try: os.remove('gozerbot.pid')
    except: pass
    try:
        runners_stop()
        rlog(10, 'gozerbot', 'shutting down fleet')
        fleet.exit()
        rlog(10, 'gozerbot', 'shutting down plugins')
        plugins.exit()
        rlog(10, 'GOZERBOT', 'done')
        os._exit(0)
    except Exception, ex: rlog(10, 'gozerbot.exit', 'exit error %s:' % str(ex))

