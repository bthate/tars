# gozerbot/users.py
#
#

""" gozerbot users package. """ 

__status__ = "seen"

## gozerbot imports

from gozerbot.config import config

## defines

if config.get('db_driver') == "olddb":
    try:
        import gozerbot.database.db
        import gozerbot.dbusers
    except Exception, ex:
        handle_exception()
        rlog(100, 'users', 'an error has occured while trying to enable the database')
        die()
    users = gozerbot.dbusers.Dbusers()
else:
    import gozerbot.sausers as sa
    users = sa.DbUsers()
