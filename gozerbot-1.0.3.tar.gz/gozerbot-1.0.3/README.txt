.. _readme:

GOZERBOT 1.0 README
===================

welcome to GOZERBOT ;] see http://pikacode.com/bthate/gozerbot

I am pleased to present to you version 1.0 of GOZERBOT, a IRC and
Jabber(XMPP) bot. 

join us on #dunkbots irc.freenode.net ;]

1.0 Requirements 
~~~~~~~~~~~~~~~~

    * a shell
    * python 2.5 or higher
    * sqlite3 (already in 2.7)
    * optional is SQLAlchemy support - enable this in gozerdata/mainconfig
      (set db_driver to "alchemy")

quick run
~~~~~~~~~

    !! make a separate user and group for the bot !!

    * wget the latest code from http://pikacode.com/bthate/gozerbot
    * untar it
    * cd into the bot dir and run the following:

      * IRC

      ::

        ./bin/gozerbot -o <userhost of the owner> -s <server> -c <\#channel>

      notice the \ thats for escaping the # in the channel name

      * Jabber / XMPP

      ::

        ./bin/gozerbot -t xmpp -o <JID of the owner> -u <bot JID> -p <pass>

    * this creates the necesary directories and config files .. after
      checking if the bot runs fine you can run the bot in daemon mode with
      ::

        ./bin/gozerbot >> logfile 2>&1 &

      gozerbot-start is for globally installed bots running from ~/.gozerbot (debian and freebsd)

    * you can also edit the gozerdata/mainconfig and gozerdata/fleet/default/config files


next
~~~~

    * you can /msg the bot !join #channel to let the bot join channels, the 
      bot wil remember channels it has joined
    * you can use the "meet <nick>" command to add other users to the bot, if 
      you are not in a channel or conference use:
      ::

          !user-add <username> <host or JID>

    * gozerplugs plugins will not be loaded on default. use !reload <plugin> 
      to enable a plugin. see the !available command to see what plugins can 
      be reloaded
    * when using commands in a /msg use --chan <channel> to let the command
      operate on a channel .. default channel in a /msg is the users nick
    
plugin configuration
~~~~~~~~~~~~~~~~~~~~

    * plugin config can be done with the <plugname>-cfg command
      usage:
      ::

        !<plugname>-cfg                   ->      shows list of all config
        !<plugname>-cfg key value         ->      sets value to key
        !<plugname>-cfg key               ->      shows value of key
        !<plugname>-cfg key add value     ->      adds value to list
        !<plugname>-cfg key remove value  ->      removes value from list
        !<plugname>-cfg key clear         ->      clears entire list
        !<plugname>-cfgsave               ->      save configuration to disk

    * or edit gozerdata/plugs/<plugname>/config

notes
~~~~~

    * we are on #dunkbots Freenode

    * MAKE REGULAR BACKUPS OF YOUR BOT DIRECTORY

    * if you want to email me use bthate@dds.nl

THNX
~~~~

Special thnx goes out to Annemiek, Danny, Kirsten, Doscha and my parents
Anneke and Thies. They made me possible and this bot to begin with.

;]

Thnx props and shouts go out to:

channel #xs4all on irc.xs4all.nl

channel #dudinet on irc.dudi.org

channel #linux.nl on irc.xs4all.nl

channel #freebsd.nl on irc.xs4all.nl

channel #cable-gang on irc.xs4all.nl

channel #dunkbots on irc.xs4all.nl

channel #fifo on irc.fifo.nl

channel #trac on irc.freenode.net

channel #mononoke on irc.mononoke.net

channel #dunkbots on irc.freenode.net

channel #dragonflybsd on efnet.xs4all.nl

- Aim for his pyro collective enthusiasm.

- Jemfinch for his more and other ideas of inspiration, see his superb 
  python bot:
  ::
  
    < dunker> @source
    <@supybot> dunker: My source is at http://supybot.sf.net/

- TW for his making me learn the first steps.

- Wouzer for his getting the started done.

- DJMuggs for his bro mak gab dude !

- Laagje for his years of bot testing core.

- Wiebel for finding bugs

- serkoon for his karma ratelimiter

- snore for his nagios-udp notification script, wisdom plugin and freebsd
  port work

- ArcAngel for his solaris testing

- ]V[ for his collective and fleet/relay testing

- Rexodus for his many exceptions reporting

- Snuf for his jabber testing

- Netfreak for his jail hosting and being the BOFH

- Nomad for his bot testing and gozerbot.cron file

- Habbie for his support and sqlite research

- qirtaiba for his debian help

- trbs for his markov plugin, persistconfig and thinking with me

- themaze for his many code contributions and brainwave brother

- bsod for his forever being there

I MISS THE FOLLOWING PEOPLE:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* Andre Drijver
* Harm Oerlemans
* Rinaldo Sikking
* pacopablo
* anarcat
* snore !!
* Rexodus
