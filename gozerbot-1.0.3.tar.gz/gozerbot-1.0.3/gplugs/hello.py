# plugs/hello.py
#
#

""" say hello. """

__status__ = "seen"

## gozerbot command

from gozerbot.commands import cmnds
from gozerbot.examples import examples
from gozerbot.plughelp import plughelp
from gozerbot.tests import tests

## plughelp

plughelp.add('hello', 'hello world like plugin (used as example)')

## hello command

def handle_hello(bot, ievent):
    """ say hello nickname """
    ievent.reply('hello ' + ievent.nick)

cmnds.add('hello', handle_hello, 'USER')
examples.add('hello', "hello 'world' example", 'hello')
tests.add('hello', 'hello')

#### BHJTW 22-01-2012
