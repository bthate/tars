# gplugs/echo.py
#
#

""" simple echo command """

__status__ = "seen"

## gozerbot imports

from gozerbot.tests import tests
from gozerbot.commands import cmnds
from gozerbot.examples import examples
from gozerbot.plughelp import plughelp

## plughelp

plughelp.add('echo', 'simply write back what you tell it')

## echo command

def handle_echo(bot, ievent):
    """ say back what is being said """
    ievent.reply(ievent.rest)

cmnds.add('echo', handle_echo, 'USER')
examples.add('echo', "echo Hello World!", 'echo')
tests.add('echo booo', 'booo')

#### BHJTW 22-01-2012
