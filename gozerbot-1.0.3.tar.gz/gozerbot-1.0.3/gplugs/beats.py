# gozerplugs/beats.py
#
#

""" internet time .beats """

__status__ = "seen"

## gozerbot imports

from gozerbot.commands import cmnds
from gozerbot.examples import examples
from gozerbot.plughelp import plughelp
from gozerbot.plughelp import plughelp
from gozerbot.tests import tests

## basic imports

import time
import math

## plughelp

plughelp.add('beats', 'show internet time')

## beats command

def handle_beats(bot, ievent):
    """ beats .. show current internet time """
    beats = ((time.time() + 3600) % 86400) / 86.4
    beats = int(math.floor(beats))
    ievent.reply('@' + str(beats))

cmnds.add('beats', handle_beats, 'USER')
examples.add('beats', 'show current internet time', 'beats')
tests.add('beats' , '@')

#### BHJTW 22-01-2012
