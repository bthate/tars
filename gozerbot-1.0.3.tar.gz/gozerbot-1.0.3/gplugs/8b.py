# gplugs/8b.py
#
#
#

""" eight ball """

__status__ = "seen"

## gozerbot imports

from gozerbot.generic import handle_exception
from gozerbot.commands import cmnds
from gozerbot.examples import examples
from gozerbot.plughelp import plughelp
from gozerbot.tests import tests

## basic imports

import re, random

## plughelp

plughelp.add('8b', 'Ask the magic 8 ball')

## defines

balltxt=[
    "Signs point to yes.",
    "Yes.",
    "Most likely.",
    "Without a doubt.",
    "Yes - definitely.",
    "As I see it, yes.",
    "You may rely on it.",
    "Outlook good.",
    "It is certain.",
    "It is decidedly so.",
    "Reply hazy, try again.",
    "Better not tell you now.",
    "Ask again later.",
    "Concentrate and ask again.",
    "Cannot predict now.",
    "My sources say no.",
    "Very doubtful.",
    "My reply is no.",
    "Outlook not so good.",
    "Don't count on it."
    ]

## 8b command

def handle_8b(bot, ievent):
    ievent.reply(random.choice(balltxt))

cmnds.add('8b', handle_8b, 'USER')
examples.add('8b', 'show what the magic 8 ball has to say', '8b')
tests.add('8b')

#### BHJTW 22-01-2012
