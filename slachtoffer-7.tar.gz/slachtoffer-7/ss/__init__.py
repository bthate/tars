# ss/__init__.py
#
#

""" ss package. """

__version__ = 7
