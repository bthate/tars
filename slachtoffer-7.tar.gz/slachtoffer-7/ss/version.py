# ss/version.py
#
#

""" version. """

## IMPORTS

from rechter.main import main

## version command

def version(event):
    import ss
    event.reply("STATUS SLACHTOFFER #%s" % ss.__version__)

main.register("version", version)
