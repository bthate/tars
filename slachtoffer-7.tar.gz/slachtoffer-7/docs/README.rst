README
======

status slachtoffer.