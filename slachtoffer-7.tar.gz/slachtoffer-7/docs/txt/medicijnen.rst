MEDICIJNEN
==========

* ziek
* pillen
* geen controle op werking pillen
* ingeval van nood geen contact 
* geen vertrouwen in behandeling
* alleen thuis
* dagelijkse suicide dreiging


Je bent ziek en de arts schrijft je medicijnen voor waarvan 
hij de werking niet controleert. Je moet zelf melden als je te ziek word, en 
als je dan belt is er niemand aanwezig. Daarna geen vertrouwen meer in 
de behandeling zorgt dat je alleen thuis komt te zitten, waarna suicidice 
dreiging continue aanwezig is.

Het gehalte van het medicijn moet in je bloed binnen een bepaalde 
bandbreedte zijn, maar is niet eens te meten.

Een verantwoorde behandeling met deze zware medicijnen kan alleen als je het
gehalte ervan in het bloed goed kan meten