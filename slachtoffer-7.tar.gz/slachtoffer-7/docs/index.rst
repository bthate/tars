###########
SLACHTOFFER
###########

De patient moet zelf in het weekend via 112 de crisis dienst van de GGZ zien te bereiken. Voor een patient met 
een Ernstige Psychiatrische Aandoening kompleet onmogelijk om te doen. In acute psychische nood kan men NIET terecht 
bij een crisisdienst.

MEDICIJNEN
==========

.. toctree::
    :glob:

    txt/medicijnen

CONTACT
=======

email: bthate@dds.nl

STATUS
======

.. image:: jpg/20141028_004.jpg
.. image:: jpg/20141106_001.jpg 
.. image:: jpg/20141114_002.jpg
.. image:: jpg/20141115_001.jpg
.. image:: jpg/20141116_001.jpg
.. image:: jpg/20141117_001.jpg
.. image:: jpg/20141118_003.jpg
.. image:: jpg/20141119_003.jpg
.. image:: jpg/20141120_001.jpg
.. image:: jpg/20141120_002.jpg
.. image:: jpg/20141120_004.jpg
.. image:: jpg/20141120_005.jpg
.. image:: jpg/20141120_006.jpg
.. image:: jpg/20141120_007.jpg
.. image:: jpg/20141121_001.jpg
.. image:: jpg/20141125_002.jpg
